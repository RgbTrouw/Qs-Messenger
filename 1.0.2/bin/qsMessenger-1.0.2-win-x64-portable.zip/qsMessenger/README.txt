

	1. Please adjust the server address configuration within the enclosed "hostname" file. 
           Configuration format: "address:port"  (no spaces or new lines);
	
	2. Start Program.
	

