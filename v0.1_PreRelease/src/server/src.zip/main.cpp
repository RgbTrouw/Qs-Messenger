
#include <QtCore/QCoreApplication>
#include "QsMessengerServer.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    quint16 port = 443;
    QsMessengerServer server(port);


    Q_UNUSED(server);

    return a.exec();
}

