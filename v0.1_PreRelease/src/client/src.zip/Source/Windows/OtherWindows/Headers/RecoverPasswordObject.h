#include <QWidget>

namespace Ui {
class RecoverPasswordObject;
}

class RecoverPasswordObject : public QWidget
{
    Q_OBJECT

public:
    explicit RecoverPasswordObject(QWidget *parent = nullptr);
    ~RecoverPasswordObject();

signals:
    void server_request(QString request);


public slots:
    void server_feedback(QString message);
    void closeEvent(QCloseEvent *event);


private slots:
    //void on_pushButton_clicked();

    void sendResetCode();
    void resetPassword();

    void nextPage();
    void previousPage();

private:
    Ui::RecoverPasswordObject *ui;
};

