#include "Headers/SmileysObject.h"
#include "ui_SmileysObject.h"


SmileysObject::SmileysObject(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SmileysObject)
{
    ui->setupUi(this);
}

SmileysObject::~SmileysObject()
{
    delete ui;
}

void SmileysObject::on_pushButton_clicked()
{
    emit smiley(":)");
}

void SmileysObject::on_pushButton_5_clicked()
{
    emit smiley(":))");
}

void SmileysObject::on_pushButton_3_clicked()
{
    emit smiley(":shy:");
}

void SmileysObject::on_pushButton_6_clicked()
{
    emit smiley(":X");
}

void SmileysObject::on_pushButton_10_clicked()
{
    emit smiley(":|");
}

void SmileysObject::on_pushButton_4_clicked()
{
    emit smiley(":D");
}

void SmileysObject::on_pushButton_2_clicked()
{
    emit smiley(":D");
}

void SmileysObject::on_pushButton_8_clicked()
{
    emit smiley("X|");
}

void SmileysObject::on_pushButton_9_clicked()
{
    emit smiley(":((");
}

void SmileysObject::on_pushButton_7_clicked()
{
    emit smiley(":O");
}
