#ifndef IM_H
#define IM_H

#include <QWidget>
#include <QVBoxLayout>
#include <QResizeEvent>
#include "MessageWidget.h"

namespace Ui {
class IM_WindowObject;
}

class IM_WindowObject : public QWidget
{
    Q_OBJECT

public:
    explicit IM_WindowObject(QWidget *parent = nullptr);
    ~IM_WindowObject();
    QString myUsername;
    QString myEmail;
    QString peer_name;
    QString email;
    QString conversationBuffer;

    QWidget *scrollAreaContent = new QWidget();
    QVBoxLayout *vLayout = new QVBoxLayout(scrollAreaContent);

    int list_index;

    QString LoremIpsum = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam vel nibh lacus. Nulla sit amet consectetur augue. Duis pharetra tempus urna. Vestibulum eleifend mauris et auctor volutpat. Integer id lorem risus. Nunc massa mauris, vehicula sit amet congue eget, ornare nec eros. Nullam viverra, lectus in mollis elementum, dolor sapien suscipit sapien, eget cursus turpis nisl quis ligula.";

    QList<QString> conversationList;
    QList<int> smileysList;



public slots:

    void deelay();
    void setMyAvatar();
    void setPeerAvatar();
    void append_message(QString message, QString time);
    void prepend_message(QString msgFrom, QString msgTo, QString message, QString time);
    void closeEvent(QCloseEvent *event);
     void showHideNotice(bool value);


private slots:
    void sendMsg();
    void sendBuzz();
    //void sendFile();
    void loadPreviousMessages();
    void showSmileys();
    void appendSmiley(QString characters);
    void resizeEvent(QResizeEvent* event);
    void playSmileys();


signals:
    void send_message(QString peer, QString message);
    void get_prev_messages(QString peer, QString index);
    void have_read(QString peer);


private:
    Ui::IM_WindowObject *ui;
    int previousMsgIndex = 0;
    bool alternate = false;
    //QList<MessageWidget *>
};

#endif // IM_H
