#ifndef SMILEYS_H
#define SMILEYS_H

#include <QWidget>

namespace Ui {
class SmileysObject;
}

class SmileysObject : public QWidget
{
    Q_OBJECT

public:
    explicit SmileysObject(QWidget *parent = nullptr);
    ~SmileysObject();

signals:
    void smiley(QString smiley);

private slots:
    void on_pushButton_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_6_clicked();

    void on_pushButton_10_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_8_clicked();

    void on_pushButton_9_clicked();

    void on_pushButton_7_clicked();

private:
    Ui::SmileysObject *ui;
};

#endif // SMILEYS_H
