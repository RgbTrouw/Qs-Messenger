#include "Headers/NoticeLabelObject.h"
#include "ui_NoticeLabelObject.h"
#include "../../../MainWindow.h"

#include <QTimer>

NoticeLabelObject::NoticeLabelObject(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::NoticeLabelObject)
{
    ui->setupUi(this);

    emit createNotice();

    QTimer::singleShot(3000, this, [=](){

     emit closeNotice();
     this->close();

    });

}

NoticeLabelObject::~NoticeLabelObject()
{
    delete ui;
}


void NoticeLabelObject::setLabel(QString label){

    ui->label->setText(label);

}

void NoticeLabelObject::setIcon(int value){

    if(value == 0){
        ui->img->setPixmap(QPixmap("./Resources/icons/smiley_offline.png"));
    } else {
        ui->img->setPixmap(QPixmap("./Resources/icons/smiley.png"));

    }

}
