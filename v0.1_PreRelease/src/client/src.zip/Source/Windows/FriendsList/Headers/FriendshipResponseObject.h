
#include <QWidget>
#include <QTimer>

namespace Ui {
class FriendshipResponseObject;
}

class FriendshipResponseObject : public QWidget
{
    Q_OBJECT


public:
    explicit FriendshipResponseObject(QWidget *parent = nullptr);
    ~FriendshipResponseObject();

public slots:
    void from(QString email);
    void closeEvent(QCloseEvent *event);


private slots:

    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
    void feedback();

signals:
    void respond_fr(QString email, QString response);

private:
    Ui::FriendshipResponseObject *ui;
    QTimer *st = new QTimer();
};


