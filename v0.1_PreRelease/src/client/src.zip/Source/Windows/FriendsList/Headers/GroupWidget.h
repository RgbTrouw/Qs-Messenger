#ifndef GROUPWIDGET_H
#define GROUPWIDGET_H

#include <QWidget>
#include "GroupHeaderWidget.h"
#include "PeerWidget.h"
#include <QIcon>
#include <QEvent>

namespace Ui {
class GroupWidget;
}

class GroupWidget : public QWidget
{
    Q_OBJECT

public:
    explicit GroupWidget(QWidget *parent = nullptr);
    ~GroupWidget();


    QString plain_group_data;
    QList < PeerWidget *> peers;
    QString group_name;

    GroupHeaderWidget *groupHeader = new GroupHeaderWidget();

    int group_list_position_index;

    int peers_online;
    int peers_total;

    QString virtualDirection = "up";

    QIcon item_icon;

public slots:


    void set_group_name(QString name);
    void set_plain_data(QString data);

    void clearPeersDisplay();
    void changePeersDisplay(QString currentType);

    void updateUsersOnline();


    QString get_group_name();
    int usersOnlineCount();

    void addNewUser();
    void addNewGroup();
    void removeGroup();

    void appendLastPeer();


    void hover(bool value);
    bool eventFilter(QObject *object, QEvent *event);

signals:

    void addToGroupSignal(QString groupName);
    void addNewGroupSignal();
    void removeGroupSignal(QString groupName);

private:
    Ui::GroupWidget *ui;
    PeerWidget *pw = new PeerWidget();



};

#endif // GROUPWIDGET_H
