#ifndef NOTIFICATIONSWIDGET_H
#define NOTIFICATIONSWIDGET_H

#include "NoticeLabelObject.h"
#include <QWidget>
#include <QList>
#include <QTimer>
#include <QSpacerItem>

namespace Ui {
class NotificationsWidget;
}

class NotificationsWidget : public QWidget
{
    Q_OBJECT

public:
    explicit NotificationsWidget(QWidget *parent = nullptr);
    ~NotificationsWidget();

    QList<NoticeLabelObject *> noticesList;

public slots:
    void newNotification(QString availability, QString username);
    void closeNotice();
    void createNotice();

private:
    Ui::NotificationsWidget *ui;

     QSpacerItem *verticalSpacer = new QSpacerItem(0,1000, QSizePolicy::Expanding, QSizePolicy::Expanding);
};

#endif // NOTIFICATIONSWIDGET_H
