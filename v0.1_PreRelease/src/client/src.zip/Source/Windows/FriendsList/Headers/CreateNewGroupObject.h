
#include <QWidget>

namespace Ui {
class CreateNewGroupObject;
}

class CreateNewGroupObject : public QWidget
{
    Q_OBJECT

public:
    explicit CreateNewGroupObject(QWidget *parent = nullptr);
    ~CreateNewGroupObject();

public slots:
    void resetInput();
    void addNewGroup();
    void feedback(QString message);

signals:

    void addNewGroupSignal(QString groupName);

private:
    Ui::CreateNewGroupObject *ui;
};

