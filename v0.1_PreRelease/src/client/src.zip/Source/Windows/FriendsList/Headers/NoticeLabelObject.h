#ifndef NOTICE_LABEL_H
#define NOTICE_LABEL_H

#include <QWidget>


namespace Ui {
class NoticeLabelObject;
}

class NoticeLabelObject : public QWidget
{
    Q_OBJECT

public:
    explicit NoticeLabelObject(QWidget *parent = nullptr);
    ~NoticeLabelObject();

public slots:

    void setLabel(QString label);
    void setIcon(int value);

signals:

    void createNotice();
    void closeNotice();

private:
    Ui::NoticeLabelObject *ui;

};

#endif // NOTICE_LABEL_H
