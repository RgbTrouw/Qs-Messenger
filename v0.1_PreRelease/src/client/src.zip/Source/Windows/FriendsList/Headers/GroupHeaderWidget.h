#ifndef GROUPHEADERWIDGET_H
#define GROUPHEADERWIDGET_H

#include <QWidget>
#include <QEvent>
#include <QMouseEvent>
#include <QMenu>


namespace Ui {
class GroupHeaderWidget;
}

class GroupHeaderWidget : public QWidget
{
    Q_OBJECT



public:
    explicit GroupHeaderWidget(QWidget *parent = nullptr);
    ~GroupHeaderWidget();

    QString GroupName;

    QString counter;
    QString iconLabel;
    QString currentType = "all";

    QMenu *contextMenu = new QMenu();
    QAction *addNewUserAction = new QAction();
    QAction *addNewGroupAction = new QAction();
    QAction *removeGroupAction = new QAction();

    QFont contextMenuFont;

public slots:

    void setName(QString name);
    void setCounterLabel(QString data);


    void hover(bool value);
    bool eventFilter(QObject *object, QEvent *event);
    void customContextMenu(QPoint positionPoint);
    void setIconMode(QString mode);

signals:

    void changePeersDisplay(QString type);

private:
    Ui::GroupHeaderWidget *ui;

    void mousePressEvent(QMouseEvent * event);

};

#endif // GROUPHEADERWIDGET_H
