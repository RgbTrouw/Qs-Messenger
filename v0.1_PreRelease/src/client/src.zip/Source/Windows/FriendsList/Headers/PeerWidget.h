#ifndef PEERWIDGET_H
#define PEERWIDGET_H

#include <QWidget>
#include <QEvent>
#include <QIcon>
#include <QMenu>
#include "../../IMWindows/Headers/IM_WindowObject.h"

namespace Ui {
class PeerWidget;
}

class PeerWidget : public QWidget
{
    Q_OBJECT

public:
    explicit PeerWidget(QWidget *parent = nullptr);
    ~PeerWidget();

    IM_WindowObject *imWidget = new IM_WindowObject();

    QString plain_data;
    QStringList peer_data;

    QString name;
    QString email;
    QString status_message;
    QString availability;
    int availability_int;

    QIcon list_icon;
    QPixmap avatar;

    QString spacer = "";
    QString separator = "  -  ";

    QMenu *contextMenu = new QMenu();
    QAction *moveToGroupUpAction = new QAction();
    QAction *moveToGroupDownAction = new QAction();
    QAction *removeUserAction = new QAction();

    QFont contextMenuFont;



public slots:
    void hover(bool value);
    bool eventFilter(QObject *object, QEvent *event);

    void set_plain_data(QString plain_peer_data);
    void customContextMenu(QPoint positionPoint);

    void removeUser();

    void moveToGroupUp();
    void moveToGroupDown();

signals:

    void removeUserSignal(QString thisEmail);
    void refreshPeerAvatar(QString email);

    void moveToGroupUpSignal(QString thisEmail);
    void moveToGroupDownSignal(QString thisEmail);


private:
    Ui::PeerWidget *ui;




};

#endif // PEERWIDGET_H
