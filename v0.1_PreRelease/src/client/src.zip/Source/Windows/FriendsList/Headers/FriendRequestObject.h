#include <QWidget>
#include <QTimer>

namespace Ui {
class FriendRequestObject;
}

class FriendRequestObject : public QWidget
{
    Q_OBJECT

public:
    explicit FriendRequestObject(QWidget *parent = nullptr);
    ~FriendRequestObject();

    QString email;
    QString groupName;

private slots:
    void add();
    void close_window();


public slots:
    void feedback(QString message);
    void closeEvent(QCloseEvent *event);


signals:
    void addNewUser();


private:
    Ui::FriendRequestObject *ui;

    QTimer *st = new QTimer();
};

