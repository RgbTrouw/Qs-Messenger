#ifndef FRIENDSLISTWIDGET_H
#define FRIENDSLISTWIDGET_H

#include <QWidget>
#include <QList>
#include "GroupWidget.h"
#include "NotificationsWidget.h"
#include <QVBoxLayout>
#include <QMessageBox>

namespace Ui {
class FriendsListWidget;
}

class FriendsListWidget : public QWidget
{
    Q_OBJECT

public:
    explicit FriendsListWidget(QWidget *parent = nullptr);
    ~FriendsListWidget();

    QWidget *scrollAreaContent = new QWidget();
    QVBoxLayout *vLayout = new QVBoxLayout(scrollAreaContent);

    QString data;
    QList< GroupWidget *> groups;

     QSpacerItem *verticalSpacer = new QSpacerItem(0,1000, QSizePolicy::Expanding, QSizePolicy::Expanding);

    int nr_of_groups;

public slots:

    void set_data(QString data);
    void clearWidget();

    void removeGroup(QString groupName);
    void addNewGroup(QString groupName);


    //GroupWidget* newGroup();

private:
    Ui::FriendsListWidget *ui;



};

#endif // FRIENDSLISTWIDGET_H
