#include "Headers/FriendsListWidget.h"
#include "ui_FriendsListWidget.h"
#include <QSpacerItem>
#include <QDebug>


FriendsListWidget::FriendsListWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FriendsListWidget)
{
    ui->setupUi(this);

    this->setAttribute(Qt::WA_StyledBackground, true);
    this->setAttribute(Qt::WA_Hover, true);
    ui->scrollArea->setWidget(scrollAreaContent);
    vLayout->setContentsMargins(0,0,0,0);
    vLayout->setSpacing(0);


}

FriendsListWidget::~FriendsListWidget()
{
    this->disconnect();
    delete ui;
}


void FriendsListWidget::set_data(QString plain_data){

    for (int i = 0; i< groups.count(); i++){ui->verticalLayout->removeWidget(groups.at(i));

    }
    groups.clear();

    data = plain_data;
    QStringList plain_groups = data.split("|");

    plain_groups.removeFirst();
    nr_of_groups = plain_groups.count();

    QStringList buffer;

    for (int i=0; i < nr_of_groups; i++){

        buffer.append(plain_groups.at(i).split("/").at(0));
    }

    for (int i=0; i < nr_of_groups; i++){

        GroupWidget *buffer_group = new GroupWidget();
        buffer_group->set_group_name(buffer.at(i));
        groups.append(buffer_group);

        vLayout->addWidget(groups.last());


        }


    vLayout->addItem(verticalSpacer);

    for (int i=0; i < groups.count(); i++){
        groups.at(i)->set_plain_data(plain_groups.at(i));

        //qInfo() << "Group " + groups.at(i)->get_group_name() + " - Group Data: " + groups.at(i)->plain_group_data;
    }

//    int position = 0;

//    for (int i =0; i < groups.count(); i++){

//        if ( i == 0 ){ groups.at(i)->group_list_position_index = position; }
//        else {
//            position = position + 1 + groups.at(i - 1)->peers.count();
//            groups.at(i)->group_list_position_index = position;
//        }
//        //qInfo() << groups.at(i)->peers.count();


//        for (int a = 0; a< groups.at(i)->peers.count(); a++){
//            groups.at(i)->peers.at(a)->peer_list_position_index = position + a + 1;
//            //qInfo() << groups.at(i)->peers.at(a)->peer_list_position_index;
//        }

//    }





}


void FriendsListWidget::clearWidget(){

    for (int i=0; i<groups.count(); i++){

        ui->verticalLayout->removeWidget(groups.at(i));

    }
    groups.clear();

}

void FriendsListWidget::removeGroup(QString groupName){

    for(int i=0; i<groups.count(); i++){
    if(groups.at(i)->group_name == groupName){
        vLayout->removeWidget(groups.at(i));

        delete groups.at(i);
        groups.removeAt(i);

    }
    }
}

void FriendsListWidget::addNewGroup(QString groupName){
    //qInfo() << vLayout->count();

  //  qInfo() << "add new group...";

    vLayout->removeItem(verticalSpacer);
    groups.append(new GroupWidget());
    groups.last()->set_group_name(groupName);
    groups.last()->set_plain_data(groupName + "|");
    vLayout->addWidget(groups.last());
    groups.last()->setVisible(true);
    vLayout->addItem(verticalSpacer);

}
