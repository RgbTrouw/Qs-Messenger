#include "Headers/NotificationsWidget.h"
#include "ui_NotificationsWidget.h"
#include <QDebug>

NotificationsWidget::NotificationsWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::NotificationsWidget)
{

    ui->setupUi(this);


    this->setGeometry(this->geometry().x(), 800, 200,0);


}

NotificationsWidget::~NotificationsWidget()
{
    delete ui;
}

void NotificationsWidget::newNotification(QString availability, QString username){

    noticesList.prepend(new NoticeLabelObject());

    connect(noticesList.last(), SIGNAL(createNotice()), this, SLOT(createNotice()));
    connect(noticesList.last(), SIGNAL(closeNotice()), this, SLOT(closeNotice()));

    if (availability == "0"){
        noticesList.first()->setLabel(username + " went offline...");
        noticesList.first()->setIcon(0);
    }
    else if (availability == "1") {
        noticesList.first()->setLabel(username + " went online...");
        noticesList.first()->setIcon(1);
    }



    for(int i =0; i< noticesList.count(); i++){
        ui->verticalLayout->removeItem(ui->verticalLayout->takeAt(i));
    }

    ui->verticalLayout->removeItem(verticalSpacer);

    for(int i =0; i< noticesList.count(); i++){
        ui->verticalLayout->addWidget(noticesList.at(i));
    }

    ui->verticalLayout->addItem(verticalSpacer);


}



void NotificationsWidget::createNotice(){

    this->setGeometry(this->geometry().x(), (this->geometry().y() - 20), 200, (this->geometry().height() + 20));

}

void NotificationsWidget::closeNotice(){

    this->setGeometry(this->geometry().x(), (this->geometry().y() + 20), 200, (this->geometry().height() - 20));

    if (noticesList.count() == 0) {this->close();}

}
