#ifndef GROUP_H
#define GROUP_H

#include "Peer.h"
#include <QDebug>
#include <QList>
#include <QString>
#include <QStandardItem>
#include <QFont>
#include <QIcon>

class GroupObject : public QObject
{
    Q_OBJECT

public:
    explicit GroupObject(QObject *parent = nullptr);

    QString plain_group_data;
    QList < PeerObject *> peers;
    QString group_name;

    int group_list_position_index;

    int peers_online;
    int peers_total;

    QIcon item_icon;

    QStandardItem *item_model;
    QFont item_font;
    QColor item_color;

public slots:

    void set_group_name(QString name);
    void set_plain_data(QString data);


    QString get_group_name();
    int group_peers_count();
    int group_peers_online_count();

    QStandardItem* get_item_model_item();
    PeerObject* get_user_at(int index);

};

#endif // GROUP_H
