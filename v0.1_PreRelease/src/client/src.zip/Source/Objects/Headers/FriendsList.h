#ifndef FRIENDS_LIST_H
#define FRIENDS_LIST_H

#include <QObject>
#include "FriendsGroup.h"
#include "Peer.h"
#include "../../Windows/IMWindows/Headers/IM_WindowObject.h"

class FriendsListObject : public QObject
{
    Q_OBJECT
public:
    explicit FriendsListObject(QObject *parent = nullptr);

    QString data;
    QList< GroupObject *> groups;

    int nr_of_groups;

public slots:
    void set_data(QString data);

    GroupObject* group_at(int index);
    GroupObject* newGroup();
    IM_WindowObject* get_im_at(int index);

    void clear();

signals:

};

#endif // FRIENDS_LIST_H
