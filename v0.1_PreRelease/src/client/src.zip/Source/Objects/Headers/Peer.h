#ifndef PEER_H
#define PEER_H

#include "../../Windows/IMWindows/Headers/IM_WindowObject.h"
#include <QDebug>
#include <QString>
#include <QStringList>
#include <QStandardItemModel>
#include <QFont>
#include <QColor>
#include <QMenu>

class PeerObject : public QObject
{
    Q_OBJECT

public:
    explicit PeerObject(QObject *parent = nullptr);

    QString plain_data;
    QStringList peer_data;

    QString name;
    QString email;
    QString status_message;
    QString availability;
    int availability_int;

    IM_WindowObject *im_window = new IM_WindowObject();
    int peer_list_position_index;

    QIcon list_icon;
    QPixmap avatar;

    QString spacer = "";
    QString separator = "  -  ";

    QStandardItem *item_model;
    QFont item_font;
    QColor item_color;


public slots:
    void set_plain_data(QString plain_peer_data);
    QStandardItem* get_item_model_item();
    IM_WindowObject* get_im_window();
};

#endif // PEER_H
