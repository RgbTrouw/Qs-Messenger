/*   QsMessenger v 1.0.1 Instant Messaging Application
     Copyright (C) 2025  Radu G. Balaban G.

     This program is free software: you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation, either version 3 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program.  If not, see <https://www.gnu.org/licenses/>. */


#include <QtCore/QCoreApplication>

#include "MainWindow.h"
#include "ui_MainWindow.h"

#include <QObject>
#include <QSharedMemory>


int main(int argc, char *argv[])
{
    QApplication app(argc, argv); app.setOrganizationDomain("portal.cloudns.ph"); app.setOrganizationName(QLatin1String("Rgb Trust")); app.setApplicationName(QLatin1String("Qs Messenger"));

//    QSharedMemory shared("62d60669-bb94-4a94-88bb-b964890a7e04");
//    if( !shared.create( 512, QSharedMemory::ReadWrite) )
//    {
//    qWarning() << "Can't start more than one instance of the application.";
//    exit(0);
//    }
//    else {
//    qDebug() << "Application started successfully.";
//    }


    MainWindow mw; int x=1652; int y=0; mw.setGeometry(x,y,274,980); mw.show();


    return app.exec();
}

void exit(){

}
