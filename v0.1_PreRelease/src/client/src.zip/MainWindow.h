/*   QsMessenger v 0.0.1 PreRelease Instant Messaging Application
     Copyright (C) 2025  Radu G. Balaban G.

     This program is free software: you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation, either version 3 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program.  If not, see <https://www.gnu.org/licenses/>. */


#include "Source/Windows/IMWindows/Headers/IM_WindowObject.h"

#include "Source/Windows/OtherWindows/Headers/RecoverPasswordObject.h"
#include "Source/Windows/OtherWindows/Headers/RegisterNewUserObject.h"
#include "Source/Windows/OtherWindows/Headers/About.h"
#include "Source/Objects/Headers/FriendsList.h"
#include "Source/Windows/FriendsList/Headers/FriendsListWidget.h"
#include "Source/Windows/FriendsList/Headers/FriendRequestObject.h"
#include "Source/Windows/FriendsList/Headers/FriendshipResponseObject.h"
#include "Source/Windows/FriendsList/Headers/CreateNewGroupObject.h"
#include "Source/Windows/FriendsList/Headers/NoticeLabelObject.h"
#include "Source/Windows/FriendsList/Headers/NotificationsWidget.h"


#include "ui_MainWindow.h"
#include <QApplication>
#include <QWidget>
#include <QtCore/QObject>
#include <QtWebSockets/QWebSocket>
#include <QtNetwork/QSslError>
#include <QtCore/QList>
#include <QtCore/QString>
#include <QtCore/QUrl>
#include <QHash>
#include <QMainWindow>
#include <QObject>
#include <QSettings>
#include <QTimer>
#include <QStandardItemModel>
#include <QStandardItem>
#include <QMap>
#include <QMovie>
#include <QSystemTrayIcon>
#include <QDesktopWidget>



namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:

    ////////////////////////////////////////////////////////////////////////////////////////////// Main Window

    void onWindowsStartup();
    void closeEvent (QCloseEvent *event);

    /////////////////////////////////////////////////////////////////////////////////////////////// Main Window Menus

    void closeApplication();
    void showHideMainWindow();

    /////////////////////////////////////////////////////////////////////////////////////////////// Socket

    void onConnected();
    void onDisconnected();

    void reconnect();

    void onTextMessageReceived(QString message);
    void processBinaryMessage(QByteArray message);
    void onSslErrors(const QList<QSslError> &errors);

    void updateHostAddress(QString address);

    /////////////////////////////////////////////////////////////////////////////////////////////// Network

    void signIn();
    void signOut();
    void autologin();


    ////////////////////////// Pre Login //////////////////////////////////////

    void registerNewUserMenu();
    void registrationRequest(QString request);

    void recoverPasswordMenu();
    void recoverPasswordRequest(QString request);


    ////////////////////////// Post Login //////////////////////////////////////


    /// ** Status

    void changeAvatar();
    void changeAvailability(int index);
    void updateStatusMessage();

    void lastLoginCounter(QString time, int counter);

    /// ** Friends List

    //void onFriendsListItemDoubleClicked(const QModelIndex &index);
    //void friendsListContextMenu(const QPoint &point);

    void addToGroup(QString groupName);
    void addNewGroup();
    void addNewGroupConfirmation(QString groupName);

    void removeGroup(QString groupName);

    void removeUser(QString email);
    //void addNewGroup();

    void moveToGroupDown(QString email);
    void moveToGroupUp(QString email);

    /// ** Friend Request

    void respondFriendRequest(QString email, QString response);
    //void sendFriendRequest(QString email);

    /// ** Instant Messages

    void retrieve_avatar();
    void refreshPeerAvatar(QString email);
    void send_im(QString peerEmail, QString message);
    void have_read(QString peerEmail);
    void get_prev_messages(QString peerEmail, QString index);


    ////////////////////////////////////////////////////////////////////////////////////////////////// Other

    void delay(int seconds);


signals:
    void server_response(QString);

private:
    Ui::MainWindow *ui;
    QSystemTrayIcon *trayIcon = new QSystemTrayIcon(QIcon("/usr/local/share/QsMessenger/Resources/icons/smiley_offline.png"));

    QMenu *trayMenu = new QMenu();
    QMovie *movie = new QMovie("loading.gif");

    QSettings *savedSettings = new QSettings();
    QTimer *autoLoginTimer = new QTimer();

    QString hostAddress = "";

    QAction *hostnameAction = new QAction();

    QAction *showHideAction = new QAction();
    QAction *signInAction = new QAction();
    QAction *closeAppAction = new QAction();

    FriendsListWidget *friendsWidget = new FriendsListWidget();

    NotificationsWidget *notifications = new NotificationsWidget();

    CreateNewGroupObject *addNewGroupWindow = new CreateNewGroupObject();
    FriendRequestObject *addNewUserWindow = new FriendRequestObject();
    FriendshipResponseObject *friendshipResponseWindow = new FriendshipResponseObject();

    RegisterNewUserObject *registerNewUserWindow = new RegisterNewUserObject();
    RecoverPasswordObject *recoverPasswordWindow = new RecoverPasswordObject();


    About *aboutWindow = new About();

    QWebSocket m_webSocket;
    QString searchPattern;

    QString myUsername;
    QString myEmail;

    QString session_id;
    QString previousMsgBuffer;


    QStandardItemModel *itemsModel = new QStandardItemModel();
    //FriendsListObject *peerList = new FriendsListObject();
    QList<QStandardItem *> friendsListItemsModel;
    QList<IM_WindowObject *> imList;
    QFont contextMenuFont;
    QFont notificationFont;


    bool ticker = true;


};


