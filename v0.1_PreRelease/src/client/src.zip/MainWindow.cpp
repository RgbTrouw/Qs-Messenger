/*   QsMessenger v 0.0.1 PreRelease Instant Messaging Application
     Copyright (C) 2025  Radu G. Balaban G.

     This program is free software: you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation, either version 3 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program.  If not, see <https://www.gnu.org/licenses/>. */


#ifdef Q_OS_WIN //this is Windows specific code, not portable
    QWindowsWindowFunctions::setWindowActivationBehavior(QWindowsWindowFunctions::AlwaysActivateWindow);
#endif

#include "MainWindow.h"
#include "ui_MainWindow.h"

#include <QApplication>
#include <QWidget>
#include <QObject>
#include <QDebug>
#include <QCryptographicHash>
#include <QSettings>
#include <QFileDialog>
#include <QFile>
#include <QProcess>
#include <QByteArray>
#include <QFont>
#include <QRegularExpression>
#include <QRegularExpressionMatch>
#include <QSystemTrayIcon>
#include <QCloseEvent>
#include <QDesktopWidget>



MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    //qInfo() << 1;
    this->setFixedSize(this->width(),this->height());

    friendsWidget->setAttribute(Qt::WA_StyledBackground, true);
    friendsWidget->setAttribute(Qt::WA_Hover, true);


    this->setWindowTitle("Qs Messenger");
    this->setWindowIcon(QIcon("./Resources/icons/smiley.png"));



    QDir dir("./Resources/users/");
    if (!dir.exists()){
        QDir().mkdir("./Resources/users/");
    }

    showHideAction->setText("Hide");
    signInAction->setText("Sign In");
    closeAppAction->setText("Close");

    contextMenuFont.setPointSize(10);

    ui->availabilityDropDownMenu->setItemIcon(0,QIcon("./Resources/icons/smiley.png"));
    ui->availabilityDropDownMenu->setItemIcon(1,QIcon("./Resources/icons/smiley_busy.png"));
    ui->availabilityDropDownMenu->setItemIcon(2,QIcon("./Resources/icons/smiley_offline.png"));

    //friendsWidget->setSizePolicy(Qt:)
    ui->listLayout->addWidget(friendsWidget);
    ui->listLayout->setSpacing(0);
    ui->listLayout->setMargin(0);

    notificationFont.setPointSize(8);
    ui->statusbar->setFont(notificationFont);

    ui->bannerLabel->setPixmap(QPixmap("./Resources/banner2.png"));
    ui->bannerLabel->hide();
    ui->MainAvatar->setIcon(QPixmap("./Resources/icons/avatarIcon.png"));

    QDesktopWidget dWidget;
    int screenWidth = dWidget.screen()->width();
    int screenHeight = dWidget.screen()->height();

    notifications->setGeometry(screenWidth - 200, screenHeight - 80, 200, 0);
    notifications->setWindowFlag( Qt::FramelessWindowHint, Qt::FramelessWindowHint|Qt::WindowStaysOnTopHint );



    // *** CONNECT

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  socket


    connect(&m_webSocket, &QWebSocket::connected, this, &MainWindow::onConnected);
    connect(&m_webSocket, &QWebSocket::disconnected, this, &MainWindow::onDisconnected);

    connect(&m_webSocket, QOverload<QAbstractSocket::SocketError>::of(&QWebSocket::error), this, [=](QAbstractSocket::SocketError error){ qInfo() << error;});

    connect(&m_webSocket, QOverload<const QList<QSslError>&>::of(&QWebSocket::sslErrors), this, &MainWindow::onSslErrors);


    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////  user interface

    connect(closeAppAction, SIGNAL(triggered()), this, SLOT(closeApplication()));
    connect(signInAction, SIGNAL(triggered()), this, SLOT(signIn()));
    connect(showHideAction, SIGNAL(triggered()), this, SLOT(showHideMainWindow()));

    connect(ui->actionAbout, &QAction::triggered, this, [=](){aboutWindow->show();});

    connect(ui->signInButton, SIGNAL(clicked()), this, SLOT(signIn()));

    connect(ui->MainAvatar, SIGNAL(clicked()), this, SLOT(changeAvatar()));
    connect(ui->availabilityDropDownMenu, SIGNAL(currentIndexChanged(int)), this, SLOT(changeAvailability(int)));
    connect(ui->statusMessageLineEdit, SIGNAL(editingFinished()), this, SLOT(updateStatusMessage()));


    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// pre login

    connect(ui->registerNewUserButton, SIGNAL(clicked()), this, SLOT(registerNewUserMenu()));
    connect(registerNewUserWindow, SIGNAL(server_request(QString)), this, SLOT(registrationRequest(QString)));

    connect(ui->resetPasswordButton, SIGNAL(clicked()), this, SLOT(recoverPasswordMenu()));
    connect(recoverPasswordWindow, SIGNAL(server_request(QString)), this, SLOT(recoverPasswordRequest(QString))); //?



    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// other windows

    QFile inputFile("hostname");
    if (inputFile.open(QIODevice::ReadOnly))
    {
       QTextStream in(&inputFile);
       while (!in.atEnd())
       {
          QString line = in.readLine();
          hostAddress = line.split(" ").at(0);
       }
       inputFile.close();
    }

    //qInfo() << hostAddress;
    reconnect();



    trayIcon->setContextMenu(trayMenu);
    trayIcon->setVisible(true);

    trayMenu->addAction(showHideAction);
    trayMenu->addAction(signInAction);
    trayMenu->addAction(closeAppAction);


    //hostnameAction->setText("Hostname");
    //ui->menuMessenger->addAction(hostnameAction);



    if (savedSettings->value("remember_credentials").toBool() ) {

        ui->usernamePrompt->setText(savedSettings->value("username").toString());
        ui->passwordPrompt->setText(savedSettings->value("password").toString());
        ui->autologinPrompt->setChecked(savedSettings->value("autologin").toBool());
        ui->invisible_Prompt->setChecked(savedSettings->value("invisible").toBool());

        ui->rememberPrompt->setChecked(savedSettings->value("remember_credentials").toBool());

    }

    if (savedSettings->value("autologin").toBool()){


        autoLoginTimer->singleShot(700, this, SLOT(autologin()));
    }

    onWindowsStartup();
    ui->stackedWidget->setCurrentIndex(0);

    ui->smiley_label->setMovie(movie);
    movie->jumpToNextFrame();


    this->statusBar()->showMessage("Disconnected");
    this->statusBar()->setStyleSheet("color: rgb(28, 113, 216);"); // green: rgb(60, 150, 0); red: rgb(224, 27, 36); yellow: rgb(246, 211, 45); blue: rgb(28, 113, 216);


}

void MainWindow::onWindowsStartup() {

    QSettings registeryKey("HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", QSettings::NativeFormat);   // Windows Startup Registery Key

    QString value = QCoreApplication::applicationFilePath(); //get absolute path of running exe
    QString apostroph = "\"";

    value.replace("/","\\");
    value = apostroph + value + apostroph ;

    registeryKey.setValue("Qs Messenger", value);

}

MainWindow::~MainWindow() { delete ui; }


void MainWindow::updateHostAddress(QString hostAddressValue){

    savedSettings->setValue("hostAddress", hostAddressValue);
    m_webSocket.disconnect();
    reconnect();

    //qInfo() << savedSettings->value("hostAddress").toString();
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////  *** SOCKET ***  ///////////////////////////////////////////////////////////////////////////////////////////////////////

void MainWindow::onConnected()
{
    this->statusBar()->showMessage("Connected");
    this->statusBar()->setStyleSheet("color: rgb(60, 150, 0);"); // green: rgb(60, 150, 0); red: rgb(224, 27, 36);

    qDebug() << "Socket Connected";
    connect(&m_webSocket, &QWebSocket::textMessageReceived,
            this, &MainWindow::onTextMessageReceived);

    connect(&m_webSocket, &QWebSocket::binaryMessageReceived,
            this, &MainWindow::processBinaryMessage);
    //hostnameAction->disconnect();
    m_webSocket.sendTextMessage(QStringLiteral("session_id"));

}

void MainWindow::onDisconnected(){



    trayIcon->setIcon(QIcon("./Resources/icons/smiley_offline.png"));
    signOut();

    this->statusBar()->showMessage("Disconnected");
    this->statusBar()->setStyleSheet("color: rgb(224, 27, 36);"); // green: rgb(60, 150, 0); red: rgb(224, 27, 36);

    this->statusBar()->showMessage("Connecting");
    this->statusBar()->setStyleSheet("color: rgb(28, 113, 216);"); // green: rgb(60, 150, 0); red: rgb(224, 27, 36); yellow: rgb(246, 211, 45); blue: rgb(28, 113, 216);

   reconnect();

}

void MainWindow::reconnect(){


    qInfo() << hostAddress;
    qInfo() << m_webSocket.state();
    qInfo() << m_webSocket.errorString();


    if (hostAddress.size() > 5 && m_webSocket.state() != QAbstractSocket::ConnectedState ){

        m_webSocket.disconnect();
        this->statusBar()->showMessage("Connecting...");
        m_webSocket.open(QUrl("wss://" + hostAddress));

        QTimer::singleShot(4000, this, SLOT(reconnect()));


    }

}

void MainWindow::onSslErrors(const QList<QSslError> &errors) {
    qInfo() << errors;
    m_webSocket.ignoreSslErrors();
}

void MainWindow::onTextMessageReceived(QString message)
{

    if (message != previousMsgBuffer){

    if (message.left(12) != "friends_list"){
        qInfo() << message;
    }

    if ( message.indexOf("session_id:") == 0){
        session_id = message.split(":").at(1);
        //qInfo() << session_id;
    }

    if(message=="Could not login..."){
        this->statusBar()->showMessage(message);
        this->statusBar()->setStyleSheet("color: rgb(224, 27, 36);"); // green: rgb(60, 150, 0); red: rgb(224, 27, 36);
    }

    if (message.indexOf("login was successful... :") == 0){

        signInAction->setText("Sign Out");
        disconnect(signInAction, SIGNAL(triggered()), this, SLOT(signIn()));
        connect(signInAction, SIGNAL(triggered()), this, SLOT(signOut()));

       // ui->menuMessenger->removeAction(hostnameAction);

        ui->stackedWidget->setCurrentIndex(1);
        ui->MainAvatar->setIcon(QPixmap("./Resources/icons/avatarIcon.png"));

        m_webSocket.sendTextMessage("getlist:" + session_id);
        m_webSocket.sendTextMessage("getMyInfo:" + session_id);

        signInAction->setText("Sign Out");

        ui->actionReset_Password->setVisible(false);
        ui->actionActivate_New_User->setVisible(false);
        ui->actionToggle_List_View->setVisible(true);


        ui->actionFriend_Request->setVisible(true);

        retrieve_avatar();

        //ui->statusEdit->close();

        movie->jumpToFrame(0);
        movie->stop();

        QTimer::singleShot(1000, this, [=](){
            if(ui->availabilityDropDownMenu->currentIndex() != 2){
                trayIcon->setIcon(QIcon("./Resources/icons/smiley.png"));
            } else {
                trayIcon->setIcon(QIcon("./Resources/icons/smiley_offline.png"));
            }

        });


        if (message.split(":").at(1) != "0"){
        QDateTime *dt = new QDateTime();

        this->statusBar()->showMessage("  Last Login: " + dt->fromMSecsSinceEpoch(message.split(":").at(1).toLongLong()).toString("h:m ap dd.MMMM.yy"));
       // this->statusBar()->setFont(contextMenuFont);
        this->statusBar()->setStyleSheet("color: rgb(28, 113, 216);");

        lastLoginCounter(message.split(":").at(1), 30);

        } else {this->statusBar()->showMessage("  Welcome to Qs Messenger...");

            QTimer::singleShot(10000, this, [=](){this->statusBar()->clearMessage();});
        }
    }


    if ( message.indexOf("friends_list:|") == 0){



        for(int i=0; i< friendsWidget->groups.count(); i++){
            disconnect(friendsWidget->groups.at(i));
            for (int a=0; a< friendsWidget->groups.at(i)->peers.count(); a++){
                disconnect(friendsWidget->groups.at(i)->peers.at(a));
                disconnect(friendsWidget->groups.at(i)->peers.at(a)->imWidget);
                 delete friendsWidget->groups.at(i)->peers.at(a)->imWidget;
                 delete friendsWidget->groups.at(i)->peers.at(a);
                 friendsWidget->groups.at(i)->peers.clear();
                //friendsWidget->groups.at(i)->peers.at(a)->imWidget->close();
                //friendsWidget->groups.at(i)->peers.removeAt(a);

            }
            delete friendsWidget->groups.at(i);
            friendsWidget->groups.clear();

        }

        friendsWidget->groups.clear();
        friendsWidget->clearWidget();

        ui->listLayout->removeWidget(friendsWidget);


        friendsWidget = new FriendsListWidget();
        friendsWidget->set_data(message);
        ui->listLayout->addWidget(friendsWidget);
\

        for (int i =0; i < friendsWidget->groups.count(); i++){

            connect(friendsWidget->groups.at(i), SIGNAL(addToGroupSignal(QString)), this, SLOT(addToGroup(QString)));
            connect(friendsWidget->groups.at(i), SIGNAL(addNewGroupSignal()), this, SLOT(addNewGroup()));
            connect(friendsWidget->groups.at(i), SIGNAL(removeGroupSignal(QString)), this, SLOT(removeGroup(QString)));


            for (int a =0; a < friendsWidget->groups.at(i)->peers.count(); a++){
                connect(friendsWidget->groups.at(i)->peers.at(a)->imWidget, SIGNAL(send_message(QString, QString)), this, SLOT(send_im(QString, QString)));
                connect(friendsWidget->groups.at(i)->peers.at(a)->imWidget, SIGNAL(get_prev_messages(QString, QString)), this, SLOT(get_prev_messages(QString, QString)));
                connect(friendsWidget->groups.at(i)->peers.at(a)->imWidget, SIGNAL(have_read(QString)), this, SLOT(have_read(QString)));

                connect(friendsWidget->groups.at(i)->peers.at(a), SIGNAL(refreshPeerAvatar(QString)), this, SLOT(refreshPeerAvatar(QString)));
                connect(friendsWidget->groups.at(i)->peers.at(a), SIGNAL(removeUserSignal(QString)), this, SLOT(removeUser(QString)) );

                connect(friendsWidget->groups.at(i)->peers.at(a), SIGNAL(moveToGroupDownSignal(QString)), this, SLOT(moveToGroupDown(QString)) );
                connect(friendsWidget->groups.at(i)->peers.at(a), SIGNAL(moveToGroupUpSignal(QString)), this, SLOT(moveToGroupUp(QString)) );

                friendsWidget->groups.at(i)->peers.at(a)->imWidget->setWindowTitle(friendsWidget->groups.at(i)->peers.at(a)->name);
                if (ui->availabilityDropDownMenu->currentIndex() == 2) {
                    friendsWidget->groups.at(i)->peers.at(a)->imWidget->showHideNotice(false);
                } else {
                    friendsWidget->groups.at(i)->peers.at(a)->imWidget->showHideNotice(true);

                }



                friendsWidget->groups.at(i)->peers.at(a)->imWidget->myUsername = myUsername;
                friendsWidget->groups.at(i)->peers.at(a)->imWidget->myEmail = myEmail;

                QString server_request="peer_avatar:" + friendsWidget->groups.at(i)->peers.at(a)->email + ":" + session_id;
                m_webSocket.sendTextMessage(server_request.toUtf8());

            }
        }


    }

    searchPattern = "updateUser:*/*/*/*/*";

    if (QRegularExpression(QRegularExpression::wildcardToRegularExpression(searchPattern)).match(message).hasMatch()){

        QStringList parameters;
        parameters = message.split(":").at(1).split("/");

        //qInfo() << parameters;
        QString newAvailability = parameters.at(1);
        QString previousAvailability;

        for (int i=0; i<friendsWidget->groups.count(); i++){
            for (int a=0; a<friendsWidget->groups.at(i)->peers.count(); a++){
                if (friendsWidget->groups.at(i)->peers.at(a)->email == parameters.at(4)){

                    previousAvailability = QString::number(friendsWidget->groups.at(i)->peers.at(a)->availability_int);

                    friendsWidget->groups.at(i)->peers.at(a)->set_plain_data(parameters.at(0) + "/" + parameters.at(1) + "/" + parameters.at(2) + "/" + parameters.at(3) + "/" + parameters.at(4));
                    friendsWidget->groups.at(i)->updateUsersOnline();

                   break;
                }

            }

        }


        if( (previousAvailability == "0" || previousAvailability == "1") && newAvailability == "2"){
            qInfo() << "user went offline...";
            notifications->newNotification("0", parameters.at(0));
            //notifications->show();
            notifications->activateWindow();
        }
        else if( (newAvailability == "0" || newAvailability == "1") && previousAvailability == "2"){
            qInfo() << "user went online...";
            notifications->newNotification("1", parameters.at(0));
            //notifications->show();
            notifications->activateWindow();
        }


    }

    searchPattern = "addUserToGroup:*/*/*/*/*:*";

    if (QRegularExpression(QRegularExpression::wildcardToRegularExpression(searchPattern)).match(message).hasMatch()){

        QStringList parameters;
        parameters = message.split(":");
        qInfo() << "add User: " + parameters.at(1) + " to Group: " + parameters.at(2);

        m_webSocket.sendTextMessage("getlist:" + session_id);




    }

    searchPattern = "userInfo:*:*:*:*";

    if (QRegularExpression(QRegularExpression::wildcardToRegularExpression(searchPattern)).match(message).hasMatch()){


        QStringList parameters;
        parameters = message.split(":");

        //qInfo() << parameters;

        ui->usernameLabel->setText( " " + parameters.at(1));
        myUsername = parameters.at(1);
        myEmail = parameters.at(4);

        QDir dir("./Resources/users/" + myEmail);
        if (!dir.exists()){
            QDir().mkdir("./Resources/users/" + myEmail);
            QDir().mkdir("./Resources/users/" + myEmail + "/avatars/");
        }

        ui->statusMessageLineEdit->setText(parameters.at(2).toUtf8());
        ui->availabilityDropDownMenu->setCurrentIndex(parameters.at(3).toInt());

        for (int i = 0 ; i < friendsWidget->groups.count(); i++){
            for (int a = 0; a< friendsWidget->groups.at(i)->peers.count(); a++){
                friendsWidget->groups.at(i)->peers.at(a)->imWidget->myUsername = myUsername;
                friendsWidget->groups.at(i)->peers.at(a)->imWidget->myEmail = myEmail;
            }
        }
        //qInfo() << parameters.at(4); // last login;
    }


    searchPattern = "im:*:*:*";

    if (QRegularExpression(QRegularExpression::wildcardToRegularExpression(searchPattern)).match(message).hasMatch()){

        qInfo() << "new message received...";
        qInfo() << message;
        QStringList parameters = message.split(":");

        for(int i =0; i< friendsWidget->groups.count(); i++){

            for (int a = 0; a< friendsWidget->groups.at(i)->peers.count(); a++){
            if( friendsWidget->groups.at(i)->peers.at(a)->email == parameters.at(1)){

                //qInfo() << friendsWidget->groups.at(i)->peers.at(a)->imWidget;
                //qInfo() << friendsWidget->groups.at(i)->peers.at(a)->imWidget;
                friendsWidget->groups.at(i)->peers.at(a)->imWidget->show();
                friendsWidget->groups.at(i)->peers.at(a)->imWidget->setMyAvatar();
                friendsWidget->groups.at(i)->peers.at(a)->imWidget->setPeerAvatar();
                friendsWidget->groups.at(i)->peers.at(a)->imWidget->setWindowTitle(friendsWidget->groups.at(i)->peers.at(a)->name);
                QByteArray byteArray = QByteArray::fromHex(parameters.at(2).toUtf8());
                QString message = byteArray.data();
                friendsWidget->groups.at(i)->peers.at(a)->imWidget->append_message(message,  parameters.at(3));
                friendsWidget->groups.at(i)->peers.at(a)->imWidget->myUsername = myUsername;
                break;
                }
            }
        }

    }


    searchPattern = "pm:*:*:*:*";

    if (QRegularExpression(QRegularExpression::wildcardToRegularExpression(searchPattern)).match(message).hasMatch()){

        qInfo() << "archived message received...";
        QStringList parameters = message.split(":");

        qInfo() << parameters;
        QString msgFrom = parameters.at(1);
        QString msgTo = parameters.at(2);
        QString msg = parameters.at(3);
        QString time = parameters.at(4);
        for(int i =0; i< friendsWidget->groups.count(); i++){

            for (int a = 0; a< friendsWidget->groups.at(i)->peers.count(); a++){
            if( (friendsWidget->groups.at(i)->peers.at(a)->imWidget->email == msgFrom && msgTo == myEmail) || (friendsWidget->groups.at(i)->peers.at(a)->imWidget->email == msgTo && msgFrom == myEmail)){

                friendsWidget->groups.at(i)->peers.at(a)->imWidget->show();
                friendsWidget->groups.at(i)->peers.at(a)->imWidget->setMyAvatar();
                friendsWidget->groups.at(i)->peers.at(a)->imWidget->setPeerAvatar();
                friendsWidget->groups.at(i)->peers.at(a)->imWidget->setWindowTitle(friendsWidget->groups.at(i)->peers.at(a)->name);
                QByteArray byteArray = QByteArray::fromHex(msg.toUtf8());
                QString message = byteArray.data();
                friendsWidget->groups.at(i)->peers.at(a)->imWidget->prepend_message(msgFrom, msgTo, message, time);
                friendsWidget->groups.at(i)->peers.at(a)->imWidget->myUsername = myUsername;

            }
        }
        }

    }

    searchPattern = "newfriendshiprequest:*";

    if (QRegularExpression(QRegularExpression::wildcardToRegularExpression(searchPattern)).match(message).hasMatch()){

        QStringList parameters = message.split(":");
        friendshipResponseWindow->from(parameters.at(1));

        connect(friendshipResponseWindow, SIGNAL(respond_fr(QString, QString)), this, SLOT(respondFriendRequest(QString, QString)));
        friendshipResponseWindow->show();

    }

    searchPattern = "userRemovedFromList:*";

    if (QRegularExpression(QRegularExpression::wildcardToRegularExpression(searchPattern)).match(message).hasMatch()){

        QStringList parameters = message.split(":");
        QString email = parameters.at(1);

        for (int i=0; i< friendsWidget->groups.count(); i++){
            for (int a=0; a< friendsWidget->groups.at(i)->peers.count(); a++ ){
                if (friendsWidget->groups.at(i)->peers.at(a)->email == email){
                    friendsWidget->groups.at(i)->peers.at(a)->imWidget->close();
                    friendsWidget->groups.at(i)->peers.at(a)->imWidget->disconnect();
                    friendsWidget->groups.at(i)->peers.at(a)->imWidget->deleteLater();
                    friendsWidget->groups.at(i)->peers.at(a)->disconnect();
                    friendsWidget->groups.at(i)->peers.at(a)->deleteLater();
                    delete friendsWidget->groups.at(i)->peers.at(a);
                    friendsWidget->groups.at(i)->peers.removeAt(a);
                }
            }
        }

        m_webSocket.sendTextMessage("getlist:" + session_id);

    }

    searchPattern = "Group already exists:*";

    if (QRegularExpression(QRegularExpression::wildcardToRegularExpression(searchPattern)).match(message).hasMatch()){
        QString groupName = message.split(":").at(1);

        addNewGroupWindow->feedback("Group already exists...");

    }

    searchPattern = "New Group Created:*";

    if (QRegularExpression(QRegularExpression::wildcardToRegularExpression(searchPattern)).match(message).hasMatch()){

        m_webSocket.sendTextMessage("getlist:" + session_id);

        QString groupName = message.split(":").at(1);

        addNewGroupWindow->feedback("New group created...");

    }

    searchPattern = "Group Deleted:*";

    if (QRegularExpression(QRegularExpression::wildcardToRegularExpression(searchPattern)).match(message).hasMatch()){

        QString groupName = message.split(":").at(1);
        friendsWidget->removeGroup(groupName);

        m_webSocket.sendTextMessage("getlist:" + session_id);


    }

    searchPattern = "userMovedToGroup:*:*";

    if (QRegularExpression(QRegularExpression::wildcardToRegularExpression(searchPattern)).match(message).hasMatch()){

        m_webSocket.sendTextMessage("getlist:" + session_id);

    }

    if (message == "Friendship request has been sent..." || message == "Request allready sent..." || message == "Email is not registered..." || message == "You are allready friends..."){

        addNewUserWindow->feedback("  " + message);
        qInfo() << message;
    }

    if (message == "Email already in use or not activated..." || message == "Registration success... Please activate your account..." || "Activation success..." || message == "Activation failed..."  || message == "Activation code resent..." || message == "Email not registered or already activated..." ){

        registerNewUserWindow->server_feedback("  " + message);

    }

    if (message == "Reset code sent..." || message == "Email is not registered or activated..." || message == "Password changed..." || message == "Reset code not validated..." || message == "Password must not be null..." ) {

        recoverPasswordWindow->server_feedback("  " + message);
    }

    previousMsgBuffer = message;

   }

}

void MainWindow::processBinaryMessage(QByteArray data){

    if (data.left(12) == "your_avatar:"){

        QString path = "./Resources/users/" + myEmail + "/" + myUsername;
        QFile avatar(path);
        avatar.open(QIODevice::ReadWrite);
        avatar.write(data.right(data.size() - 12));

        ui->MainAvatar->setIcon(QPixmap(path));

    }


    QStringList header = QString(data.left(50)).split(":");


    if(header.at(0) == "peer_avatar"){

        QString peerEmail = header.at(1);

        QByteArray buffer = data.right(data.size() - 11 - peerEmail.size() - 2);

        QString path = "./Resources/users/" + myEmail + "/avatars/" + peerEmail;
        QFile avatar(path);
        avatar.open(QIODevice::WriteOnly);
        avatar.write(buffer);

    }

}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////  *** MAIN WINDOW ***  //////////////////////////////////////////////////////////////////////////////////////////////////////

void MainWindow::lastLoginCounter(QString time, int counter){


    if(ticker){
    if (counter > 0){

        QDateTime *dt = new QDateTime();

        this->statusBar()->showMessage("  Last Login: " + dt->fromMSecsSinceEpoch(time.toLongLong()).toString("dd.MMMM.yy hh:mm") + " (" + QString::number(counter) + "s)");
        this->statusBar()->setStyleSheet("color: rgb(28, 113, 216);"); // green: rgb(60, 150, 0); red: rgb(224, 27, 36);

        counter = counter - 1;

        QTimer::singleShot(1000, this, [=](){lastLoginCounter(time, counter);});
    } else {this->statusBar()->clearMessage();

    }
    }
}

void MainWindow::retrieve_avatar(){ m_webSocket.sendTextMessage("retrieve_avatar:" + session_id); }

void MainWindow::refreshPeerAvatar(QString email){  m_webSocket.sendTextMessage("peer_avatar:" + email + ":" + session_id); }

void MainWindow::addToGroup(QString groupName){


    addNewUserWindow = new FriendRequestObject();
    addNewUserWindow->setWindowTitle("Add To Group: " + groupName);
    addNewUserWindow->show();

    connect(addNewUserWindow, &FriendRequestObject::addNewUser, this, [=](){ m_webSocket.sendTextMessage("addNewUser:" + addNewUserWindow->email + ":" + groupName + ":" + session_id) ;});

}



void MainWindow::addNewGroup(){

    addNewGroupWindow->resetInput();
    addNewGroupWindow->show();
    connect(addNewGroupWindow, SIGNAL(addNewGroupSignal(QString)), this, SLOT(addNewGroupConfirmation(QString)));
}

void MainWindow::addNewGroupConfirmation(QString groupName){

    m_webSocket.sendTextMessage("addNewGroup:" + groupName + ":" + session_id);
}

void MainWindow::removeGroup(QString groupName){

    //qInfo() << "remove group " + groupName + "...";
    QMessageBox msgBox;
    msgBox.setWindowTitle("Remove Group");
    msgBox.setText("Are you sure you want to remove the '" + groupName + "' group with all underlaying users?");
    msgBox.setFont(contextMenuFont);
    msgBox.setStandardButtons(QMessageBox::Yes);
    msgBox.addButton(QMessageBox::No);
    msgBox.setDefaultButton(QMessageBox::No);
    if(msgBox.exec() == QMessageBox::Yes){
      m_webSocket.sendTextMessage("removeGroup:" + groupName + ":" + session_id);
    }else {
     // qInfo() << "no";
    }

}

void MainWindow::removeUser(QString email){

    QString username;

    for (int i =0; i < friendsWidget->groups.count(); i++){
        for (int a=0; a< friendsWidget->groups.at(i)->peers.count(); a++){
            if (friendsWidget->groups.at(i)->peers.at(a)->email == email){

                username = friendsWidget->groups.at(i)->peers.at(a)->name;
            }
        }
    }

    QMessageBox msgBox;
    msgBox.setWindowTitle("Remove User");
    msgBox.setText("Are you sure you want to remove the user '" + username + "' from group?");
    msgBox.setFont(contextMenuFont);
    msgBox.setStandardButtons(QMessageBox::Yes);
    msgBox.addButton(QMessageBox::No);
    msgBox.setDefaultButton(QMessageBox::No);

    if(msgBox.exec() == QMessageBox::Yes){

       m_webSocket.sendTextMessage("removeUser:" + email + ":" + session_id);

    }else {

    }

}

void MainWindow::moveToGroupDown(QString email){

    QString targetGroupName;

    for(int i=0; i< friendsWidget->groups.count(); i++){

        for (int a=0; a< friendsWidget->groups.at(i)->peers.count(); a++){

            if (friendsWidget->groups.at(i)->peers.at(a)->email == email){


                if(i != friendsWidget->groups.count() - 1){
                    targetGroupName = friendsWidget->groups.at(i + 1)->group_name;
                } else {targetGroupName = friendsWidget->groups.at(0)->group_name;}


                a=friendsWidget->groups.at(i)->peers.count();
                i=friendsWidget->groups.count();

                break;
            }
        }

    }

     m_webSocket.sendTextMessage("moveToGroup:" + email + ":" + targetGroupName + ":" + session_id);

}

void MainWindow::moveToGroupUp(QString email){

    QString targetGroupName;

    for(int i=0; i< friendsWidget->groups.count(); i++){

        for (int a=0; a< friendsWidget->groups.at(i)->peers.count(); a++){

            if (friendsWidget->groups.at(i)->peers.at(a)->email == email){

                if(i != 0 ){
                    targetGroupName = friendsWidget->groups.at(i - 1)->group_name;
                } else {targetGroupName = friendsWidget->groups.last()->group_name;}


                a=friendsWidget->groups.at(i)->peers.count();
                i=friendsWidget->groups.count();

                break;
            }
        }

    }

    qInfo() << "move up " + email + " to group " + targetGroupName;
    m_webSocket.sendTextMessage("moveToGroup:" + email + ":" + targetGroupName + ":" + session_id);

}

void MainWindow::respondFriendRequest(QString email, QString response ){

    m_webSocket.sendTextMessage("respondAddNewUserRequest:" + email + ":" + response + ":" + session_id );

}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// tray menus


void MainWindow::changeAvatar()
{
    QFileDialog dialog(nullptr,  "Images (*.png)");

    dialog.setNameFilter("*.png");
    dialog.exec();

    QByteArray picByteArray;
    QStringList path = dialog.selectedFiles();

    if(path.at(0).left(path.at(0).size()).right(4) == ".png" || path.at(0).left(path.at(0).size()).right(4) == ".PNG" ){

    QFile pic(path.at(0));
    if (pic.open(QIODevice::ReadOnly)){;
        picByteArray = pic.readAll();


        picByteArray.prepend("myAvatar:");

        ui->MainAvatar->setIcon(QPixmap(path.at(0)));
        //m_webSocket.sendTextMessage("upload_avatar:" + session_id);
        m_webSocket.sendBinaryMessage(picByteArray + session_id.toUtf8());
        QString path2 = "./Resources/users/" + myEmail + "/";

        path2.append(myUsername);
        QFile::remove(path2);
        QFile::copy(path.at(0), path2);

    }
    }
}

void MainWindow::autologin(){ this->signIn();}

void MainWindow::signIn() {

    //movie->start();

    QString username = ui->usernamePrompt->text();
    QString password = ui->passwordPrompt->text();

    QByteArray hash = password.toUtf8();
    password = QCryptographicHash::hash(hash, QCryptographicHash::Sha256).toHex();


    if (ui->rememberPrompt){


        savedSettings->setValue("username", ui->usernamePrompt->text());
        savedSettings->setValue("password", password);
        savedSettings->setValue("autologin", ui->autologinPrompt->isChecked() );
        savedSettings->setValue("invisible", ui->invisible_Prompt->isChecked() );
        savedSettings->setValue("remember_credentials", ui->rememberPrompt->isChecked());

    }


    if (ui->rememberPrompt->checkState()){

        savedSettings->setValue("remember_credentials", true);
        savedSettings->setValue("username", ui->usernamePrompt->text());
        savedSettings->setValue("password", ui->passwordPrompt->text());
        savedSettings->setValue("autologin", ui->autologinPrompt->checkState());
        savedSettings->setValue("invisible", ui->invisible_Prompt->checkState());

    }

    QString request =  "login:" + username + ":" + password + ":" ;
    QString visibility;

    if (ui->invisible_Prompt->isChecked()){visibility = "2";}
    else if (!ui->invisible_Prompt->isChecked()) {visibility = "0";}

    request.append(visibility);
    m_webSocket.sendTextMessage(request + ":" + session_id);

    registerNewUserWindow->close();
    recoverPasswordWindow->close();

    ticker=true;
}

void MainWindow::signOut()
{
    //ui->menuMessenger->addAction(hostnameAction);
    signInAction->setText("Sign In");
    disconnect(signInAction, SIGNAL(triggered()), this, SLOT(signOut()));
    connect(signInAction, SIGNAL(triggered()), this, SLOT(signIn()));

    ui->statusMessageLineEdit->setText("");
    m_webSocket.sendTextMessage("sign_out:" + session_id);

    addNewUserWindow->close();
    addNewGroupWindow->close();
    friendshipResponseWindow->close();



    for(int i=0; i<friendsWidget->groups.count(); i++){
        for(int a=0; a<friendsWidget->groups.at(i)->peers.count(); a++){
            friendsWidget->groups.at(i)->peers.at(a)->imWidget->close();
        }
    }
     friendsWidget->groups.clear();

     friendsWidget->close();
    ui->stackedWidget->setCurrentIndex(0);

    signInAction->setText("Sign In");
    ui->actionToggle_List_View->setVisible(false);
    ui->actionActivate_New_User->setVisible(true);
    ui->actionReset_Password->setVisible(true);
    ui->actionFriend_Request->setVisible(false);

    if (!ui->rememberPrompt->isChecked()){
        ui->usernamePrompt->setText("");
        ui->passwordPrompt->setText("");
        ui->rememberPrompt->setCheckState(Qt::Unchecked);
        ui->autologinPrompt->setCheckState(Qt::Unchecked);
        ui->invisible_Prompt->setCheckState(Qt::Unchecked);

    }

    QString username = "";

    movie->jumpToFrame(0);

    trayIcon->setIcon(QIcon("./Resources/icons/smiley_offline.png"));

    this->statusBar()->clearMessage();
    this->statusBar()->showMessage("Connected");
    this->statusBar()->setStyleSheet("color: rgb(60, 150, 0);"); // green: rgb(60, 150, 0); red: rgb(224, 27, 36);

    ticker=false;

}

void MainWindow::changeAvailability(int index)
{

    QString param="set_availability:";
    param.append(QString::number(index));
    m_webSocket.sendTextMessage(param + ":" + session_id);

    updateStatusMessage();

    if (ui->availabilityDropDownMenu->currentIndex() == 2){
        trayIcon->setIcon(QIcon("./Resources/icons/smiley_offline.png"));
    } else if (ui->availabilityDropDownMenu->currentIndex() == 0){
        trayIcon->setIcon(QIcon("./Resources/icons/smiley.png"));
    }  else if (ui->availabilityDropDownMenu->currentIndex() == 1){
        trayIcon->setIcon(QIcon("./Resources/icons/smiley_busy.png"));
    }

    for (int i=0; i < friendsWidget->groups.count(); i++){
        for (int a=0; a< friendsWidget->groups.at(i)->peers.count(); a++){
            if (ui->availabilityDropDownMenu->currentIndex() == 2){
                friendsWidget->groups.at(i)->peers.at(a)->imWidget->showHideNotice(false);
            } else {
                friendsWidget->groups.at(i)->peers.at(a)->imWidget->showHideNotice(true);

            }
        }
    }

}


void MainWindow::closeEvent (QCloseEvent *event) { event->ignore(); this->hide(); showHideAction->setText("Show"); }
void MainWindow::showHideMainWindow() { if (this->isVisible()){ this->hide(); showHideAction->setText("Show"); } else if (!this->isVisible()){ int x=1650; int y=0; this->setGeometry(x,y,280,900); this->show(); this->activateWindow(); showHideAction->setText("Hide"); } }
void MainWindow::closeApplication() {

    QMessageBox msgBox;
    msgBox.setWindowTitle("Close QsMessenger");
    msgBox.setText("Are you sure you want to exit?");
    msgBox.setFont(contextMenuFont);
    msgBox.setStandardButtons(QMessageBox::Yes);
    msgBox.addButton(QMessageBox::No);
    msgBox.setDefaultButton(QMessageBox::No);
    if(msgBox.exec() == QMessageBox::Yes){
       this->close(); QCoreApplication::exit(0);
    }else {
     // qInfo() << "no";
    }


}

void MainWindow::updateStatusMessage() { QString qr="set_status:";
                                         QString statusMessage = ui->statusMessageLineEdit->text();
                                         QByteArray byteArray = statusMessage.toUtf8();
                                         qr.append(byteArray.toHex() + ":" + session_id); m_webSocket.sendTextMessage(qr); }


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////  *** AFTER LOGIN ***  //////////////////////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// messages

void MainWindow::send_im(QString peerEmail, QString message){

    QString request = "im:";
    request.append(peerEmail);
    request.append(":");
    QByteArray byteArray = message.toUtf8();
    request.append(byteArray.toHex());
    m_webSocket.sendTextMessage(request + ":" + session_id);

}

void MainWindow::get_prev_messages(QString peerEmail, QString index){

    QString request = "previous:";
    request.append(peerEmail);
    request.append(":");
    request.append(index);
    m_webSocket.sendTextMessage(request + ":" + session_id);

}

void MainWindow::have_read(QString peerEmail){
    qInfo() << "have_read:" + peerEmail;
    m_webSocket.sendTextMessage("have_read:" + peerEmail + ":" + session_id);
}



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////  *** PRE LOGIN ***  //////////////////////////////////////////////////////////////////////////////////////////////////


void MainWindow::recoverPasswordMenu() { recoverPasswordWindow->close(); recoverPasswordWindow = new RecoverPasswordObject(); recoverPasswordWindow->show();
                                         connect(recoverPasswordWindow, SIGNAL(server_request(QString)), this, SLOT(recoverPasswordRequest(QString))); }

void MainWindow::recoverPasswordRequest(QString request){  m_webSocket.sendTextMessage(request.toUtf8() + ":" + session_id); }


void MainWindow::registerNewUserMenu() { registerNewUserWindow->close(); registerNewUserWindow = new RegisterNewUserObject(); registerNewUserWindow->show();
                                         connect(registerNewUserWindow, SIGNAL(server_request(QString)), this, SLOT(registrationRequest(QString))); }

void MainWindow::registrationRequest(QString request) {  m_webSocket.sendTextMessage(request + ":" + session_id); }




//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////  *** OTHER *** /////////////////////////////////////////////////////////////////////////////////////////////////////


void MainWindow::delay(int seconds) { QTime theTime= QTime::currentTime().addSecs(seconds); while (QTime::currentTime() < theTime){ QCoreApplication::processEvents(QEventLoop::AllEvents, 100); } }



////////////////////////////////////////////////////////////////////////////////////  THE END  ///////////////////////////////////////////////////////////////////////////////////////////////////////
