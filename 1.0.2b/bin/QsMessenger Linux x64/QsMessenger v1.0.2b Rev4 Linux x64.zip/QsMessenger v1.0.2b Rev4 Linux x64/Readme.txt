

Note: Linux builds require "libqt" libraries installed ( multimedia, websockets, network, sql);  

Client configuration:

Host address and port has to be assigned within the messenger settings menu.
