
#include <QtCore/QCoreApplication>
#include "QsMessengerServer.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    QsMessengerServer server(7080);


    Q_UNUSED(server);

    return a.exec();
}

