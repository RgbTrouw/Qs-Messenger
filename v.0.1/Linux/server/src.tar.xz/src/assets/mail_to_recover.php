// Pear Mail Library
<?php
require_once "Mail.php";

$from = '<(replace data)>';
$to = $argv[1];
$subject = 'QsMessenger Server (replace data) Password Reset';
$body = "Hello,\n";
$body .= "\n";
$body .= "Your QsMessenger password reset code is: \n";
$body .= $argv[2];
$body .= " \n";
$body .= " \n";
$body .= "Please use it to reset your password...\n";
$body .= "\n";
$body .= "\n";
$body .= "Kind Regards,\n";
$body .= "The QsMessenger Team Server: (replace data)";


$headers = array(
    'From' => $from,
    'To' => $to,
    'Subject' => $subject
);

$smtp = Mail::factory('smtp', array(
        'host' => 'ssl://smtp.gmail.com',
        'port' => '465',
        'auth' => true,
        'username' => '(replace data)',
        'password' => '(replace data)'
    ));

$mail = $smtp->send($to, $headers, $body);

if (PEAR::isError($mail)) {
    echo('<p>' . $mail->getMessage() . '</p>');
} else {
    echo('<p>Message successfully sent!</p>');
}
?>
