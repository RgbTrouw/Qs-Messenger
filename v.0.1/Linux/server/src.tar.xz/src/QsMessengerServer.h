#ifndef SSLMESSENGERSERVER_H
#define SSLMESSENGERSERVER_H

#include <QtCore/QObject>
#include <QtCore/QList>
#include <QtCore/QByteArray>
#include <QtNetwork/QSslError>
#include <QSqlQuery>
#include <QMap>
#include <QTimer>
#include <QFileSystemWatcher>
#include <QFile>
#include <QList>
#include <client.h>

QT_FORWARD_DECLARE_CLASS(QWebSocketServer)
QT_FORWARD_DECLARE_CLASS(QWebSocket)

class QsMessengerServer : public QObject
{
    Q_OBJECT
public:
    explicit QsMessengerServer(quint16 port, QObject *parent = nullptr);
    ~QsMessengerServer() override;

private Q_SLOTS:
    void onNewConnection();
    void onSslErrors(const QList<QSslError> &errors);
    void dateTime();

    void close_client(QString session_id);

    void logData(QString data);



private:


    int clients_id = 0;
    //QFile log_file(QStringLiteral("log.txt"));

    QWebSocketServer *m_pWebSocketServer;

    QList<client *> clients;

    ////// --------------------------------------------------------------------------------

    QList<QWebSocket *> m_clients;

    QString response;
    QMap<QString, QString> response_hash;

    QTimer *tmr= new QTimer();
    QMap<QString, QTimer *> tmr_hash;
    QTimer *ss = new QTimer();
    QMap<QString, QTimer *> ss_hash;

    bool list_type=false;
    QMap<QString, bool> list_type_hash;
    QString previous_list;

    QString session_id_request="session_id";


    bool compact_list;
    bool reset = true;


    QString logPath;


};

#endif //SSLMESSENGERSERVER_H

