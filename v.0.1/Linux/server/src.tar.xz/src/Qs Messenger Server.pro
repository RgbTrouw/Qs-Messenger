QT = websockets sql

TARGET = 'Qs Messenger Server'
CONFIG   += console
CONFIG   -= app_bundle

TEMPLATE = app

SOURCES += \
    QsMessengerServer.cpp \
    client.cpp \
    main.cpp

HEADERS += \
    QsMessengerServer.h \
    client.h

RESOURCES += QsMessengerServer.qrc

INSTALLS += target

