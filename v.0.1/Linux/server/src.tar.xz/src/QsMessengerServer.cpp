#include "QsMessengerServer.h"
#include "QtWebSockets/QWebSocketServer"
#include "QtWebSockets/QWebSocket"
#include <QtCore/QDebug>
#include <QtCore/QFile>
#include <QtNetwork/QSslCertificate>
#include <QtNetwork/QSslKey>
#include <QRegularExpression>
#include <QRegularExpressionMatch>
#include <QRegExp>
#include <QFileSystemWatcher>
#include <QTimer>
#include <QProcess>
#include <client.h>

QT_USE_NAMESPACE

//! [constructor]
QsMessengerServer::QsMessengerServer(quint16 port, QObject *parent) :
    QObject(parent),
    m_pWebSocketServer(nullptr)
{


    m_pWebSocketServer = new QWebSocketServer(QStringLiteral("SSL Messenger Server"), QWebSocketServer::SecureMode, this);
    QSslConfiguration sslConfiguration;
    QFile certFile(QStringLiteral("/etc/QsMessengerServer/crt/certificate.crt"));
    QFile keyFile(QStringLiteral("/etc/QsMessengerServer/crt/private.key"));
    certFile.open(QIODevice::ReadOnly);
    keyFile.open(QIODevice::ReadOnly);
    QSslCertificate certificate(&certFile, QSsl::Pem);
    QSslKey sslKey(&keyFile, QSsl::Rsa, QSsl::Pem);
    certFile.close();
    keyFile.close();
    sslConfiguration.setPeerVerifyMode(QSslSocket::VerifyNone);
    sslConfiguration.setLocalCertificate(certificate);
    sslConfiguration.setPrivateKey(sslKey);
    m_pWebSocketServer->setSslConfiguration(sslConfiguration);

    if (m_pWebSocketServer->listen(QHostAddress::Any, port))
    {
        qInfo().noquote() << "Qs Messenger Server listening on port SSL:" << QString::number(port);
        connect(m_pWebSocketServer, &QWebSocketServer::newConnection, this, &QsMessengerServer::onNewConnection);
        connect(m_pWebSocketServer, &QWebSocketServer::sslErrors, this, &QsMessengerServer::onSslErrors);
    }

//    QDir dir("/var/log/QsMessengerServer");
//    if (!dir.exists()){
//        QDir().mkpath("./Resources/logs/");
//    }

    qint64 logName = QDateTime::currentMSecsSinceEpoch();

    logPath = "/var/log/QsMessengerServer/";
    logPath += QString::number(logName);
    logPath += ".log";

    QFile logFile(logPath);
    if(logFile.open(QIODevice::WriteOnly | QIODevice::Append)){
    logFile.write("Log Start: \n");
    logFile.close();
    }

}
//! [constructor]

QsMessengerServer::~QsMessengerServer()
{
    m_pWebSocketServer->close();
    qDeleteAll(m_clients.begin(), m_clients.end());
}

//! [onNewConnection]
void QsMessengerServer::onNewConnection()
{
    QWebSocket *pSocket = m_pWebSocketServer->nextPendingConnection();

    m_clients << pSocket;

    QProcess process;
    process.start("openssl rand -hex 24");
    process.waitForFinished(-1);
    QString session_id_code=process.readAllStandardOutput();
    session_id_code = session_id_code.trimmed();


    clients_id += 1;
    clients.append(new client(pSocket->peerAddress(), pSocket->peerPort(), session_id_code, clients_id));



    connect(pSocket, &QWebSocket::textMessageReceived, clients.last(), &client::process_text_message);
    connect(pSocket, &QWebSocket::binaryMessageReceived, clients.last(), &client::process_binary_message);
    connect(pSocket, &QWebSocket::disconnected, clients.last(), &client::socket_disconnected);
    connect(clients.last(), SIGNAL(emit_close(QString)), this, SLOT(close_client(QString)) );
    connect(clients.last(), SIGNAL(emit_logData(QString)), this, SLOT(logData(QString)));


    dateTime();
}
//! [onNewConnection]


void QsMessengerServer::onSslErrors(const QList<QSslError> &)
{
    qDebug() << "Ssl errors occurred";
}
//! [socketDisconnected]


void QsMessengerServer::logData(QString data){

    QByteArray wData = (data + "\n").toUtf8();

    QFile logFile(logPath);
    if(logFile.open(QIODevice::WriteOnly | QIODevice::Append)){
    logFile.write(wData);
    logFile.close();
    }

}




void QsMessengerServer::dateTime(){
    QTimer::singleShot(1000, this, [=](){dateTime();});
}

void QsMessengerServer::close_client(QString session_id){
        for (int i = 0; i< clients.count(); i++ ){
            if (clients.at(i)->session_id == session_id){
                clients.removeAt(i);

            }
        }
}
