#ifndef CLIENT_H
#define CLIENT_H

#include <QObject>
#include <QHostAddress>
#include <QSqlDatabase>
#include <QFileSystemWatcher>
#include <QTimer>
#include <QWebSocket>
#include <QDir>
#include <QFile>


class client : public QObject

{
     Q_OBJECT

public:
    QString session_id;
    client(QHostAddress ip_address, quint16 remote_port, QString session_id_code, int clients_id);

public slots:
    void process_text_message(QString message);
    void process_binary_message(QByteArray data);
    void socket_disconnected();

    void getNewMessages();
    void get_list();

signals:
    void emit_text_msg(QString message);
    void emit_binary_data(QByteArray data);
    void emit_close(QString session_id);

    void emit_logData(QString data);


private:

    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
    QWebSocket *pClient = qobject_cast<QWebSocket *>(sender());

    int client_id;

    QHostAddress IPaddress;
    qint16 remotePort;
    QString RemotePortString;

    QString logPath;

    QTimer *ss = new QTimer();
    QTimer *tmr= new QTimer();

    QList<QString> peersList;
    QList<QString> peersListCompare;
    QList<QString> peersListBuffer;

    QString session_id_request="session_id";
    //QString sql_request="sql:*:*:*";
    QString loginRequest="login:*:*:[0,2]:*";
    QString infoRequest="getMyInfo:*";
    QString uploadAvatarRequest="upload_avatar:*";
    QString retrieveAvatarRequest="retrieve_avatar:*";
    QString getPeerAvatarRequest="peer_avatar:*:*";
    QString imRequest="im:*:*:*";
    QString haveReadRequest="have_read:*:*";
    QString loadPreviousRequest="previous:*:*:*";
    QString registerNewUserRequest="register:*:*:*:*:*:*:*:true:*";
    QString addNewUserRequest="addNewUser:*:*:*";
    QString removeUserRequest="removeUser:*:*";
    QString removeGroupRequest="removeGroup:*:*";
    QString addNewGroupRequest="addNewGroup:*:*";
    QString moveToGroupRequest="moveToGroup:*:*:*";

    QString respondAddNewUserRequest="respondAddNewUserRequest:*:*:*";

    QString setAvailabilityRequest="set_availability:*:*";
    QString setStatusRequest="set_status:*:*";
    QString signOutRequest="sign_out:*";
    QString getListRequest="getlist:*";
    QString toggleListRequest="toggle_list:*";
    QString activateNewUserRequest="activate_user_account:*:*";
    QString resendActivationCodeRequest="resendActivationCode:*:*"; // !
    QString recoverPasswordRequest="recoverPassword:*:*";
    QString resetPasswordRequest="resetPassword:*:*:*";

    QString getPeerGroupNameRequest="getPeerGroupName:*";

    bool reset = true;
    bool compact_list;
    bool list_type=false;
    QString pending_binary = "none";
    QString wpath;
    QString sp;
    QString uname;
    QString userid = "unsigned";
    QString previous_list;
    QString response;
    QString previousRequestBuffer;



};

#endif // CLIENT_H
