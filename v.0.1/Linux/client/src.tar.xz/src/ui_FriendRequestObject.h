/********************************************************************************
** Form generated from reading UI file 'FriendRequestObject.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FRIENDREQUESTOBJECT_H
#define UI_FRIENDREQUESTOBJECT_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_FriendRequestObject
{
public:
    QGridLayout *gridLayout;
    QLabel *serverMessageLabel;
    QPushButton *addButton;
    QLineEdit *lineEdit;
    QLabel *label_2;

    void setupUi(QWidget *FriendRequestObject)
    {
        if (FriendRequestObject->objectName().isEmpty())
            FriendRequestObject->setObjectName(QString::fromUtf8("FriendRequestObject"));
        FriendRequestObject->resize(380, 81);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(FriendRequestObject->sizePolicy().hasHeightForWidth());
        FriendRequestObject->setSizePolicy(sizePolicy);
        FriendRequestObject->setMinimumSize(QSize(380, 81));
        FriendRequestObject->setMaximumSize(QSize(380, 81));
        QFont font;
        font.setPointSize(10);
        FriendRequestObject->setFont(font);
        gridLayout = new QGridLayout(FriendRequestObject);
        gridLayout->setSpacing(4);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(4, 4, 4, 4);
        serverMessageLabel = new QLabel(FriendRequestObject);
        serverMessageLabel->setObjectName(QString::fromUtf8("serverMessageLabel"));
        serverMessageLabel->setMinimumSize(QSize(362, 20));
        serverMessageLabel->setMaximumSize(QSize(362, 20));
        QFont font1;
        font1.setPointSize(9);
        serverMessageLabel->setFont(font1);
        serverMessageLabel->setStyleSheet(QString::fromUtf8("color: rgb(60, 150, 0);"));

        gridLayout->addWidget(serverMessageLabel, 2, 0, 1, 2);

        addButton = new QPushButton(FriendRequestObject);
        addButton->setObjectName(QString::fromUtf8("addButton"));
        addButton->setMinimumSize(QSize(80, 25));
        addButton->setMaximumSize(QSize(80, 25));
        addButton->setFont(font);
        QIcon icon;
        icon.addFile(QString::fromUtf8("../../../../Resources/icons/addUser.png"), QSize(), QIcon::Normal, QIcon::On);
        addButton->setIcon(icon);
        addButton->setIconSize(QSize(16, 16));

        gridLayout->addWidget(addButton, 1, 1, 1, 1);

        lineEdit = new QLineEdit(FriendRequestObject);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setMinimumSize(QSize(0, 25));
        lineEdit->setMaximumSize(QSize(16777215, 25));
        lineEdit->setFont(font);

        gridLayout->addWidget(lineEdit, 1, 0, 1, 1);

        label_2 = new QLabel(FriendRequestObject);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setMinimumSize(QSize(0, 20));
        label_2->setMaximumSize(QSize(16777215, 20));
        label_2->setFont(font);
        label_2->setStyleSheet(QString::fromUtf8("color: rgb(32, 74, 135);"));

        gridLayout->addWidget(label_2, 0, 0, 1, 1);


        retranslateUi(FriendRequestObject);

        QMetaObject::connectSlotsByName(FriendRequestObject);
    } // setupUi

    void retranslateUi(QWidget *FriendRequestObject)
    {
        FriendRequestObject->setWindowTitle(QCoreApplication::translate("FriendRequestObject", "Add To Group", nullptr));
        serverMessageLabel->setText(QCoreApplication::translate("FriendRequestObject", "  ...", nullptr));
        addButton->setText(QCoreApplication::translate("FriendRequestObject", "Add", nullptr));
        lineEdit->setPlaceholderText(QCoreApplication::translate("FriendRequestObject", "Email", nullptr));
        label_2->setText(QCoreApplication::translate("FriendRequestObject", "Please insert peer email...", nullptr));
    } // retranslateUi

};

namespace Ui {
    class FriendRequestObject: public Ui_FriendRequestObject {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FRIENDREQUESTOBJECT_H
