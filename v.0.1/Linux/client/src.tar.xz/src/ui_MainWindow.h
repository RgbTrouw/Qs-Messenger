/********************************************************************************
** Form generated from reading UI file 'MainWindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionActivate_New_User;
    QAction *actionReset_Password;
    QAction *actionToggle_List_View;
    QAction *actionAbout;
    QAction *actionFriend_Request;
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout;
    QStackedWidget *stackedWidget;
    QWidget *page;
    QGridLayout *gridLayout_2;
    QVBoxLayout *verticalLayout_2;
    QSpacerItem *verticalSpacer_7;
    QHBoxLayout *horizontalLayout_3;
    QWidget *widget;
    QLabel *smiley_label;
    QWidget *widget_2;
    QSpacerItem *verticalSpacer_2;
    QLabel *label;
    QLineEdit *usernamePrompt;
    QLabel *label_2;
    QLineEdit *passwordPrompt;
    QSpacerItem *verticalSpacer_5;
    QPushButton *registerNewUserButton;
    QSpacerItem *verticalSpacer_3;
    QCheckBox *rememberPrompt;
    QCheckBox *autologinPrompt;
    QCheckBox *invisible_Prompt;
    QSpacerItem *verticalSpacer_4;
    QHBoxLayout *horizontalLayout;
    QPushButton *signInButton;
    QSpacerItem *verticalSpacer;
    QPushButton *resetPasswordButton;
    QWidget *page_2;
    QGridLayout *gridLayout_3;
    QFrame *line;
    QSpacerItem *verticalSpacer_8;
    QLabel *bannerLabel;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *MainAvatar;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout_5;
    QLabel *usernameLabel;
    QComboBox *availabilityDropDownMenu;
    QLineEdit *statusMessageLineEdit;
    QVBoxLayout *listLayout;
    QSpacerItem *verticalSpacer_9;
    QFrame *line_3;
    QMenuBar *menubar;
    QMenu *menuMessenger;
    QMenu *menuHelp;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(275, 962);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MainWindow->sizePolicy().hasHeightForWidth());
        MainWindow->setSizePolicy(sizePolicy);
        MainWindow->setMinimumSize(QSize(275, 962));
        MainWindow->setMaximumSize(QSize(275, 962));
        MainWindow->setStyleSheet(QString::fromUtf8(""));
        actionActivate_New_User = new QAction(MainWindow);
        actionActivate_New_User->setObjectName(QString::fromUtf8("actionActivate_New_User"));
        QFont font;
        font.setPointSize(10);
        actionActivate_New_User->setFont(font);
        actionReset_Password = new QAction(MainWindow);
        actionReset_Password->setObjectName(QString::fromUtf8("actionReset_Password"));
        actionReset_Password->setFont(font);
        actionToggle_List_View = new QAction(MainWindow);
        actionToggle_List_View->setObjectName(QString::fromUtf8("actionToggle_List_View"));
        actionToggle_List_View->setFont(font);
        actionAbout = new QAction(MainWindow);
        actionAbout->setObjectName(QString::fromUtf8("actionAbout"));
        actionAbout->setFont(font);
        actionFriend_Request = new QAction(MainWindow);
        actionFriend_Request->setObjectName(QString::fromUtf8("actionFriend_Request"));
        actionFriend_Request->setFont(font);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        verticalLayout = new QVBoxLayout(centralwidget);
        verticalLayout->setSpacing(2);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(4, 4, 4, 0);
        stackedWidget = new QStackedWidget(centralwidget);
        stackedWidget->setObjectName(QString::fromUtf8("stackedWidget"));
        stackedWidget->setMinimumSize(QSize(0, 900));
        stackedWidget->setMaximumSize(QSize(275, 980));
        QFont font1;
        font1.setPointSize(9);
        stackedWidget->setFont(font1);
        page = new QWidget();
        page->setObjectName(QString::fromUtf8("page"));
        gridLayout_2 = new QGridLayout(page);
        gridLayout_2->setSpacing(4);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout_2->setContentsMargins(8, 4, 8, 4);
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(3);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(10, -1, 10, -1);
        verticalSpacer_7 = new QSpacerItem(20, 120, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_2->addItem(verticalSpacer_7);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(-1, -1, -1, 0);
        widget = new QWidget(page);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setMinimumSize(QSize(200, 140));
        widget->setMaximumSize(QSize(140, 140));
        smiley_label = new QLabel(widget);
        smiley_label->setObjectName(QString::fromUtf8("smiley_label"));
        smiley_label->setGeometry(QRect(30, 0, 140, 140));
        smiley_label->setMinimumSize(QSize(140, 140));
        smiley_label->setMaximumSize(QSize(140, 140));
        smiley_label->setStyleSheet(QString::fromUtf8("color: rgba(0 , 0, 0,2);"));
        smiley_label->setPixmap(QPixmap(QString::fromUtf8(":/icons/icons/loading.png")));
        widget_2 = new QWidget(widget);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        widget_2->setGeometry(QRect(20, -1, 161, 141));
        widget_2->setStyleSheet(QString::fromUtf8("background-color: rgba(ef,ef,ef,20)"));

        horizontalLayout_3->addWidget(widget);


        verticalLayout_2->addLayout(horizontalLayout_3);

        verticalSpacer_2 = new QSpacerItem(20, 80, QSizePolicy::Minimum, QSizePolicy::Minimum);

        verticalLayout_2->addItem(verticalSpacer_2);

        label = new QLabel(page);
        label->setObjectName(QString::fromUtf8("label"));
        label->setFont(font1);

        verticalLayout_2->addWidget(label);

        usernamePrompt = new QLineEdit(page);
        usernamePrompt->setObjectName(QString::fromUtf8("usernamePrompt"));
        usernamePrompt->setFont(font1);

        verticalLayout_2->addWidget(usernamePrompt);

        label_2 = new QLabel(page);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setFont(font1);

        verticalLayout_2->addWidget(label_2);

        passwordPrompt = new QLineEdit(page);
        passwordPrompt->setObjectName(QString::fromUtf8("passwordPrompt"));
        passwordPrompt->setFont(font1);
        passwordPrompt->setEchoMode(QLineEdit::Password);

        verticalLayout_2->addWidget(passwordPrompt);

        verticalSpacer_5 = new QSpacerItem(20, 13, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_2->addItem(verticalSpacer_5);

        registerNewUserButton = new QPushButton(page);
        registerNewUserButton->setObjectName(QString::fromUtf8("registerNewUserButton"));
        registerNewUserButton->setFont(font1);
        registerNewUserButton->setStyleSheet(QString::fromUtf8("color: rgb(52, 101, 164);"));
        registerNewUserButton->setFlat(true);

        verticalLayout_2->addWidget(registerNewUserButton);

        verticalSpacer_3 = new QSpacerItem(20, 13, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_2->addItem(verticalSpacer_3);

        rememberPrompt = new QCheckBox(page);
        rememberPrompt->setObjectName(QString::fromUtf8("rememberPrompt"));
        rememberPrompt->setMinimumSize(QSize(0, 17));
        rememberPrompt->setMaximumSize(QSize(16777215, 14));
        rememberPrompt->setFont(font1);

        verticalLayout_2->addWidget(rememberPrompt);

        autologinPrompt = new QCheckBox(page);
        autologinPrompt->setObjectName(QString::fromUtf8("autologinPrompt"));
        autologinPrompt->setMinimumSize(QSize(0, 17));
        autologinPrompt->setMaximumSize(QSize(16777215, 14));
        autologinPrompt->setFont(font1);

        verticalLayout_2->addWidget(autologinPrompt);

        invisible_Prompt = new QCheckBox(page);
        invisible_Prompt->setObjectName(QString::fromUtf8("invisible_Prompt"));
        invisible_Prompt->setMinimumSize(QSize(0, 17));
        invisible_Prompt->setMaximumSize(QSize(16777215, 14));
        invisible_Prompt->setFont(font1);

        verticalLayout_2->addWidget(invisible_Prompt);

        verticalSpacer_4 = new QSpacerItem(20, 13, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_2->addItem(verticalSpacer_4);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(-1, 5, -1, -1);
        signInButton = new QPushButton(page);
        signInButton->setObjectName(QString::fromUtf8("signInButton"));
        signInButton->setMaximumSize(QSize(97, 200));
        signInButton->setFont(font1);
        signInButton->setStyleSheet(QString::fromUtf8("background-color: rgb(232, 232, 232);"));

        horizontalLayout->addWidget(signInButton);


        verticalLayout_2->addLayout(horizontalLayout);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer);

        resetPasswordButton = new QPushButton(page);
        resetPasswordButton->setObjectName(QString::fromUtf8("resetPasswordButton"));
        resetPasswordButton->setFont(font1);
        resetPasswordButton->setStyleSheet(QString::fromUtf8("color: rgb(52, 101, 164);"));
        resetPasswordButton->setFlat(true);

        verticalLayout_2->addWidget(resetPasswordButton);


        gridLayout_2->addLayout(verticalLayout_2, 0, 0, 1, 1);

        stackedWidget->addWidget(page);
        page_2 = new QWidget();
        page_2->setObjectName(QString::fromUtf8("page_2"));
        gridLayout_3 = new QGridLayout(page_2);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        gridLayout_3->setHorizontalSpacing(0);
        gridLayout_3->setVerticalSpacing(2);
        gridLayout_3->setContentsMargins(4, 4, 4, 4);
        line = new QFrame(page_2);
        line->setObjectName(QString::fromUtf8("line"));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        gridLayout_3->addWidget(line, 3, 0, 1, 1);

        verticalSpacer_8 = new QSpacerItem(20, 4, QSizePolicy::Minimum, QSizePolicy::Fixed);

        gridLayout_3->addItem(verticalSpacer_8, 2, 0, 1, 1);

        bannerLabel = new QLabel(page_2);
        bannerLabel->setObjectName(QString::fromUtf8("bannerLabel"));
        bannerLabel->setMinimumSize(QSize(257, 80));
        bannerLabel->setMaximumSize(QSize(257, 80));
        bannerLabel->setScaledContents(true);

        gridLayout_3->addWidget(bannerLabel, 6, 0, 1, 1);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(4);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        MainAvatar = new QPushButton(page_2);
        MainAvatar->setObjectName(QString::fromUtf8("MainAvatar"));
        MainAvatar->setMinimumSize(QSize(70, 70));
        MainAvatar->setMaximumSize(QSize(70, 70));
        QIcon icon;
        icon.addFile(QString::fromUtf8("Resources/icons/avatarIcon.png"), QSize(), QIcon::Normal, QIcon::On);
        MainAvatar->setIcon(icon);
        MainAvatar->setIconSize(QSize(70, 70));
        MainAvatar->setFlat(true);

        horizontalLayout_2->addWidget(MainAvatar);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setSpacing(2);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(-1, -1, -1, 0);
        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(2);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(-1, 0, -1, -1);
        usernameLabel = new QLabel(page_2);
        usernameLabel->setObjectName(QString::fromUtf8("usernameLabel"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(usernameLabel->sizePolicy().hasHeightForWidth());
        usernameLabel->setSizePolicy(sizePolicy1);
        usernameLabel->setMaximumSize(QSize(200, 22));
        usernameLabel->setFont(font1);
        usernameLabel->setStyleSheet(QString::fromUtf8("color: rgb(52, 101, 164);\n"
"\n"
""));

        horizontalLayout_5->addWidget(usernameLabel);


        verticalLayout_3->addLayout(horizontalLayout_5);

        availabilityDropDownMenu = new QComboBox(page_2);
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/icons/icons/smiley.png"), QSize(), QIcon::Normal, QIcon::On);
        availabilityDropDownMenu->addItem(icon1, QString());
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/icons/icons/smiley_busy.png"), QSize(), QIcon::Normal, QIcon::On);
        availabilityDropDownMenu->addItem(icon2, QString());
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/icons/icons/smiley_invisible.png"), QSize(), QIcon::Normal, QIcon::On);
        availabilityDropDownMenu->addItem(icon3, QString());
        availabilityDropDownMenu->setObjectName(QString::fromUtf8("availabilityDropDownMenu"));
        availabilityDropDownMenu->setFont(font1);
        availabilityDropDownMenu->setStyleSheet(QString::fromUtf8(""));

        verticalLayout_3->addWidget(availabilityDropDownMenu);

        statusMessageLineEdit = new QLineEdit(page_2);
        statusMessageLineEdit->setObjectName(QString::fromUtf8("statusMessageLineEdit"));
        statusMessageLineEdit->setFont(font1);
        statusMessageLineEdit->setStyleSheet(QString::fromUtf8(""));
        statusMessageLineEdit->setFrame(false);
        statusMessageLineEdit->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        verticalLayout_3->addWidget(statusMessageLineEdit);


        horizontalLayout_2->addLayout(verticalLayout_3);


        gridLayout_3->addLayout(horizontalLayout_2, 1, 0, 1, 1);

        listLayout = new QVBoxLayout();
        listLayout->setSpacing(0);
        listLayout->setObjectName(QString::fromUtf8("listLayout"));
        listLayout->setSizeConstraint(QLayout::SetNoConstraint);
        listLayout->setContentsMargins(0, -1, -1, -1);

        gridLayout_3->addLayout(listLayout, 4, 0, 1, 1);

        verticalSpacer_9 = new QSpacerItem(20, 1, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_3->addItem(verticalSpacer_9, 5, 0, 1, 1);

        stackedWidget->addWidget(page_2);

        verticalLayout->addWidget(stackedWidget);

        line_3 = new QFrame(centralwidget);
        line_3->setObjectName(QString::fromUtf8("line_3"));
        line_3->setFrameShape(QFrame::HLine);
        line_3->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_3);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 275, 22));
        menuMessenger = new QMenu(menubar);
        menuMessenger->setObjectName(QString::fromUtf8("menuMessenger"));
        menuHelp = new QMenu(menubar);
        menuHelp->setObjectName(QString::fromUtf8("menuHelp"));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        QSizePolicy sizePolicy2(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(statusbar->sizePolicy().hasHeightForWidth());
        statusbar->setSizePolicy(sizePolicy2);
        statusbar->setMinimumSize(QSize(0, 20));
        statusbar->setMaximumSize(QSize(16777215, 20));
        statusbar->setFont(font);
        statusbar->setStyleSheet(QString::fromUtf8("color: rgb(60, 150, 0);"));
        MainWindow->setStatusBar(statusbar);

        menubar->addAction(menuMessenger->menuAction());
        menubar->addAction(menuHelp->menuAction());
        menuHelp->addAction(actionAbout);

        retranslateUi(MainWindow);

        stackedWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "The Messenger", nullptr));
        actionActivate_New_User->setText(QCoreApplication::translate("MainWindow", "Activate New User", nullptr));
#if QT_CONFIG(shortcut)
        actionActivate_New_User->setShortcut(QCoreApplication::translate("MainWindow", "Ctrl+N", nullptr));
#endif // QT_CONFIG(shortcut)
        actionReset_Password->setText(QCoreApplication::translate("MainWindow", "Reset Password", nullptr));
#if QT_CONFIG(shortcut)
        actionReset_Password->setShortcut(QCoreApplication::translate("MainWindow", "Ctrl+R", nullptr));
#endif // QT_CONFIG(shortcut)
        actionToggle_List_View->setText(QCoreApplication::translate("MainWindow", "Toggle List View", nullptr));
#if QT_CONFIG(shortcut)
        actionToggle_List_View->setShortcut(QCoreApplication::translate("MainWindow", "Ctrl+D", nullptr));
#endif // QT_CONFIG(shortcut)
        actionAbout->setText(QCoreApplication::translate("MainWindow", "About", nullptr));
        actionFriend_Request->setText(QCoreApplication::translate("MainWindow", "Friend Request", nullptr));
#if QT_CONFIG(shortcut)
        actionFriend_Request->setShortcut(QCoreApplication::translate("MainWindow", "Ctrl+F", nullptr));
#endif // QT_CONFIG(shortcut)
        smiley_label->setText(QString());
        label->setText(QCoreApplication::translate("MainWindow", "Id:", nullptr));
        usernamePrompt->setText(QString());
        usernamePrompt->setPlaceholderText(QCoreApplication::translate("MainWindow", "email", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "Password:", nullptr));
        passwordPrompt->setText(QString());
        passwordPrompt->setPlaceholderText(QCoreApplication::translate("MainWindow", "password", nullptr));
        registerNewUserButton->setText(QCoreApplication::translate("MainWindow", "Register a new user", nullptr));
        rememberPrompt->setText(QCoreApplication::translate("MainWindow", "Remember my credentials", nullptr));
        autologinPrompt->setText(QCoreApplication::translate("MainWindow", "Sign in automatically", nullptr));
        invisible_Prompt->setText(QCoreApplication::translate("MainWindow", "Sign  in as invisible to everyone", nullptr));
        signInButton->setText(QCoreApplication::translate("MainWindow", "Sign In", nullptr));
        resetPasswordButton->setText(QCoreApplication::translate("MainWindow", "Forgot your password?", nullptr));
        bannerLabel->setText(QString());
        MainAvatar->setText(QString());
        usernameLabel->setText(QString());
        availabilityDropDownMenu->setItemText(0, QCoreApplication::translate("MainWindow", "available", nullptr));
        availabilityDropDownMenu->setItemText(1, QCoreApplication::translate("MainWindow", "busy", nullptr));
        availabilityDropDownMenu->setItemText(2, QCoreApplication::translate("MainWindow", "invisible", nullptr));

        statusMessageLineEdit->setPlaceholderText(QCoreApplication::translate("MainWindow", "status message", nullptr));
        menuMessenger->setTitle(QCoreApplication::translate("MainWindow", "Messenger", nullptr));
        menuHelp->setTitle(QCoreApplication::translate("MainWindow", "Help", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
