/********************************************************************************
** Form generated from reading UI file 'FriendshipResponseObject.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FRIENDSHIPRESPONSEOBJECT_H
#define UI_FRIENDSHIPRESPONSEOBJECT_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_FriendshipResponseObject
{
public:
    QVBoxLayout *verticalLayout;
    QLabel *label_2;
    QLabel *emailLabel;
    QHBoxLayout *horizontalLayout;
    QPushButton *pushButton_2;
    QPushButton *pushButton;
    QLabel *label;

    void setupUi(QWidget *FriendshipResponseObject)
    {
        if (FriendshipResponseObject->objectName().isEmpty())
            FriendshipResponseObject->setObjectName(QString::fromUtf8("FriendshipResponseObject"));
        FriendshipResponseObject->resize(380, 95);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(FriendshipResponseObject->sizePolicy().hasHeightForWidth());
        FriendshipResponseObject->setSizePolicy(sizePolicy);
        FriendshipResponseObject->setMinimumSize(QSize(380, 95));
        FriendshipResponseObject->setMaximumSize(QSize(380, 95));
        QFont font;
        font.setPointSize(10);
        FriendshipResponseObject->setFont(font);
        verticalLayout = new QVBoxLayout(FriendshipResponseObject);
        verticalLayout->setSpacing(4);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(4, 4, 4, 4);
        label_2 = new QLabel(FriendshipResponseObject);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(label_2->sizePolicy().hasHeightForWidth());
        label_2->setSizePolicy(sizePolicy1);
        label_2->setMaximumSize(QSize(380, 16777215));
        label_2->setFont(font);
        label_2->setStyleSheet(QString::fromUtf8("color: rgb(32, 74, 135);"));

        verticalLayout->addWidget(label_2);

        emailLabel = new QLabel(FriendshipResponseObject);
        emailLabel->setObjectName(QString::fromUtf8("emailLabel"));
        sizePolicy1.setHeightForWidth(emailLabel->sizePolicy().hasHeightForWidth());
        emailLabel->setSizePolicy(sizePolicy1);
        emailLabel->setMaximumSize(QSize(380, 16777215));
        emailLabel->setFont(font);
        emailLabel->setStyleSheet(QString::fromUtf8("color: rgb(60, 150, 0);"));
        emailLabel->setIndent(-1);

        verticalLayout->addWidget(emailLabel);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(4);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(-1, 0, -1, -1);
        pushButton_2 = new QPushButton(FriendshipResponseObject);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        QSizePolicy sizePolicy2(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(pushButton_2->sizePolicy().hasHeightForWidth());
        pushButton_2->setSizePolicy(sizePolicy2);
        pushButton_2->setMinimumSize(QSize(0, 25));
        pushButton_2->setMaximumSize(QSize(16777215, 25));
        pushButton_2->setFont(font);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/icons/icons/smiley_busy.png"), QSize(), QIcon::Normal, QIcon::On);
        pushButton_2->setIcon(icon);

        horizontalLayout->addWidget(pushButton_2);

        pushButton = new QPushButton(FriendshipResponseObject);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        sizePolicy2.setHeightForWidth(pushButton->sizePolicy().hasHeightForWidth());
        pushButton->setSizePolicy(sizePolicy2);
        pushButton->setMinimumSize(QSize(0, 25));
        pushButton->setMaximumSize(QSize(16777215, 25));
        pushButton->setFont(font);
        QIcon icon1;
        icon1.addFile(QString::fromUtf8("../../../../../build-Qs Messenger Client-Desktop-Debug/Resources/icons/addUser.png"), QSize(), QIcon::Normal, QIcon::On);
        pushButton->setIcon(icon1);
        pushButton->setIconSize(QSize(20, 20));

        horizontalLayout->addWidget(pushButton);


        verticalLayout->addLayout(horizontalLayout);

        label = new QLabel(FriendshipResponseObject);
        label->setObjectName(QString::fromUtf8("label"));
        label->setMinimumSize(QSize(370, 17));
        label->setMaximumSize(QSize(370, 17));
        label->setFont(font);
        label->setStyleSheet(QString::fromUtf8("color: rgb(60, 150, 0);"));

        verticalLayout->addWidget(label);


        retranslateUi(FriendshipResponseObject);

        QMetaObject::connectSlotsByName(FriendshipResponseObject);
    } // setupUi

    void retranslateUi(QWidget *FriendshipResponseObject)
    {
        FriendshipResponseObject->setWindowTitle(QCoreApplication::translate("FriendshipResponseObject", "Friendship Request", nullptr));
        label_2->setText(QCoreApplication::translate("FriendshipResponseObject", "You have a new friend request from:", nullptr));
        emailLabel->setText(QString());
        pushButton_2->setText(QCoreApplication::translate("FriendshipResponseObject", "   Decline", nullptr));
        pushButton->setText(QCoreApplication::translate("FriendshipResponseObject", "   Accept", nullptr));
        label->setText(QCoreApplication::translate("FriendshipResponseObject", "  ...", nullptr));
    } // retranslateUi

};

namespace Ui {
    class FriendshipResponseObject: public Ui_FriendshipResponseObject {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FRIENDSHIPRESPONSEOBJECT_H
