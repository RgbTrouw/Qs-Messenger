/****************************************************************************
** Meta object code from reading C++ file 'FriendsList.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "Source/Objects/Headers/FriendsList.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'FriendsList.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_FriendsListObject_t {
    QByteArrayData data[11];
    char stringdata0[103];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_FriendsListObject_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_FriendsListObject_t qt_meta_stringdata_FriendsListObject = {
    {
QT_MOC_LITERAL(0, 0, 17), // "FriendsListObject"
QT_MOC_LITERAL(1, 18, 8), // "set_data"
QT_MOC_LITERAL(2, 27, 0), // ""
QT_MOC_LITERAL(3, 28, 4), // "data"
QT_MOC_LITERAL(4, 33, 8), // "group_at"
QT_MOC_LITERAL(5, 42, 12), // "GroupObject*"
QT_MOC_LITERAL(6, 55, 5), // "index"
QT_MOC_LITERAL(7, 61, 8), // "newGroup"
QT_MOC_LITERAL(8, 70, 9), // "get_im_at"
QT_MOC_LITERAL(9, 80, 16), // "IM_WindowObject*"
QT_MOC_LITERAL(10, 97, 5) // "clear"

    },
    "FriendsListObject\0set_data\0\0data\0"
    "group_at\0GroupObject*\0index\0newGroup\0"
    "get_im_at\0IM_WindowObject*\0clear"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_FriendsListObject[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,   39,    2, 0x0a /* Public */,
       4,    1,   42,    2, 0x0a /* Public */,
       7,    0,   45,    2, 0x0a /* Public */,
       8,    1,   46,    2, 0x0a /* Public */,
      10,    0,   49,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,    3,
    0x80000000 | 5, QMetaType::Int,    6,
    0x80000000 | 5,
    0x80000000 | 9, QMetaType::Int,    6,
    QMetaType::Void,

       0        // eod
};

void FriendsListObject::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<FriendsListObject *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->set_data((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: { GroupObject* _r = _t->group_at((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< GroupObject**>(_a[0]) = std::move(_r); }  break;
        case 2: { GroupObject* _r = _t->newGroup();
            if (_a[0]) *reinterpret_cast< GroupObject**>(_a[0]) = std::move(_r); }  break;
        case 3: { IM_WindowObject* _r = _t->get_im_at((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< IM_WindowObject**>(_a[0]) = std::move(_r); }  break;
        case 4: _t->clear(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject FriendsListObject::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_FriendsListObject.data,
    qt_meta_data_FriendsListObject,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *FriendsListObject::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *FriendsListObject::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_FriendsListObject.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int FriendsListObject::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 5)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 5;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
