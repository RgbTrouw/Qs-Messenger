/****************************************************************************
** Meta object code from reading C++ file 'MainWindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "MainWindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'MainWindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[54];
    char stringdata0[705];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 15), // "server_response"
QT_MOC_LITERAL(2, 27, 0), // ""
QT_MOC_LITERAL(3, 28, 16), // "onWindowsStartup"
QT_MOC_LITERAL(4, 45, 10), // "closeEvent"
QT_MOC_LITERAL(5, 56, 12), // "QCloseEvent*"
QT_MOC_LITERAL(6, 69, 5), // "event"
QT_MOC_LITERAL(7, 75, 16), // "closeApplication"
QT_MOC_LITERAL(8, 92, 18), // "showHideMainWindow"
QT_MOC_LITERAL(9, 111, 11), // "onConnected"
QT_MOC_LITERAL(10, 123, 14), // "onDisconnected"
QT_MOC_LITERAL(11, 138, 9), // "reconnect"
QT_MOC_LITERAL(12, 148, 21), // "onTextMessageReceived"
QT_MOC_LITERAL(13, 170, 7), // "message"
QT_MOC_LITERAL(14, 178, 20), // "processBinaryMessage"
QT_MOC_LITERAL(15, 199, 11), // "onSslErrors"
QT_MOC_LITERAL(16, 211, 16), // "QList<QSslError>"
QT_MOC_LITERAL(17, 228, 6), // "errors"
QT_MOC_LITERAL(18, 235, 17), // "updateHostAddress"
QT_MOC_LITERAL(19, 253, 7), // "address"
QT_MOC_LITERAL(20, 261, 6), // "signIn"
QT_MOC_LITERAL(21, 268, 7), // "signOut"
QT_MOC_LITERAL(22, 276, 9), // "autologin"
QT_MOC_LITERAL(23, 286, 19), // "registerNewUserMenu"
QT_MOC_LITERAL(24, 306, 19), // "registrationRequest"
QT_MOC_LITERAL(25, 326, 7), // "request"
QT_MOC_LITERAL(26, 334, 19), // "recoverPasswordMenu"
QT_MOC_LITERAL(27, 354, 22), // "recoverPasswordRequest"
QT_MOC_LITERAL(28, 377, 12), // "changeAvatar"
QT_MOC_LITERAL(29, 390, 18), // "changeAvailability"
QT_MOC_LITERAL(30, 409, 5), // "index"
QT_MOC_LITERAL(31, 415, 19), // "updateStatusMessage"
QT_MOC_LITERAL(32, 435, 16), // "lastLoginCounter"
QT_MOC_LITERAL(33, 452, 4), // "time"
QT_MOC_LITERAL(34, 457, 7), // "counter"
QT_MOC_LITERAL(35, 465, 10), // "addToGroup"
QT_MOC_LITERAL(36, 476, 9), // "groupName"
QT_MOC_LITERAL(37, 486, 11), // "addNewGroup"
QT_MOC_LITERAL(38, 498, 23), // "addNewGroupConfirmation"
QT_MOC_LITERAL(39, 522, 11), // "removeGroup"
QT_MOC_LITERAL(40, 534, 10), // "removeUser"
QT_MOC_LITERAL(41, 545, 5), // "email"
QT_MOC_LITERAL(42, 551, 15), // "moveToGroupDown"
QT_MOC_LITERAL(43, 567, 13), // "moveToGroupUp"
QT_MOC_LITERAL(44, 581, 20), // "respondFriendRequest"
QT_MOC_LITERAL(45, 602, 8), // "response"
QT_MOC_LITERAL(46, 611, 15), // "retrieve_avatar"
QT_MOC_LITERAL(47, 627, 17), // "refreshPeerAvatar"
QT_MOC_LITERAL(48, 645, 7), // "send_im"
QT_MOC_LITERAL(49, 653, 9), // "peerEmail"
QT_MOC_LITERAL(50, 663, 9), // "have_read"
QT_MOC_LITERAL(51, 673, 17), // "get_prev_messages"
QT_MOC_LITERAL(52, 691, 5), // "delay"
QT_MOC_LITERAL(53, 697, 7) // "seconds"

    },
    "MainWindow\0server_response\0\0"
    "onWindowsStartup\0closeEvent\0QCloseEvent*\0"
    "event\0closeApplication\0showHideMainWindow\0"
    "onConnected\0onDisconnected\0reconnect\0"
    "onTextMessageReceived\0message\0"
    "processBinaryMessage\0onSslErrors\0"
    "QList<QSslError>\0errors\0updateHostAddress\0"
    "address\0signIn\0signOut\0autologin\0"
    "registerNewUserMenu\0registrationRequest\0"
    "request\0recoverPasswordMenu\0"
    "recoverPasswordRequest\0changeAvatar\0"
    "changeAvailability\0index\0updateStatusMessage\0"
    "lastLoginCounter\0time\0counter\0addToGroup\0"
    "groupName\0addNewGroup\0addNewGroupConfirmation\0"
    "removeGroup\0removeUser\0email\0"
    "moveToGroupDown\0moveToGroupUp\0"
    "respondFriendRequest\0response\0"
    "retrieve_avatar\0refreshPeerAvatar\0"
    "send_im\0peerEmail\0have_read\0"
    "get_prev_messages\0delay\0seconds"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      37,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  199,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       3,    0,  202,    2, 0x08 /* Private */,
       4,    1,  203,    2, 0x08 /* Private */,
       7,    0,  206,    2, 0x08 /* Private */,
       8,    0,  207,    2, 0x08 /* Private */,
       9,    0,  208,    2, 0x08 /* Private */,
      10,    0,  209,    2, 0x08 /* Private */,
      11,    0,  210,    2, 0x08 /* Private */,
      12,    1,  211,    2, 0x08 /* Private */,
      14,    1,  214,    2, 0x08 /* Private */,
      15,    1,  217,    2, 0x08 /* Private */,
      18,    1,  220,    2, 0x08 /* Private */,
      20,    0,  223,    2, 0x08 /* Private */,
      21,    0,  224,    2, 0x08 /* Private */,
      22,    0,  225,    2, 0x08 /* Private */,
      23,    0,  226,    2, 0x08 /* Private */,
      24,    1,  227,    2, 0x08 /* Private */,
      26,    0,  230,    2, 0x08 /* Private */,
      27,    1,  231,    2, 0x08 /* Private */,
      28,    0,  234,    2, 0x08 /* Private */,
      29,    1,  235,    2, 0x08 /* Private */,
      31,    0,  238,    2, 0x08 /* Private */,
      32,    2,  239,    2, 0x08 /* Private */,
      35,    1,  244,    2, 0x08 /* Private */,
      37,    0,  247,    2, 0x08 /* Private */,
      38,    1,  248,    2, 0x08 /* Private */,
      39,    1,  251,    2, 0x08 /* Private */,
      40,    1,  254,    2, 0x08 /* Private */,
      42,    1,  257,    2, 0x08 /* Private */,
      43,    1,  260,    2, 0x08 /* Private */,
      44,    2,  263,    2, 0x08 /* Private */,
      46,    0,  268,    2, 0x08 /* Private */,
      47,    1,  269,    2, 0x08 /* Private */,
      48,    2,  272,    2, 0x08 /* Private */,
      50,    1,  277,    2, 0x08 /* Private */,
      51,    2,  280,    2, 0x08 /* Private */,
      52,    1,  285,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    2,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 5,    6,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   13,
    QMetaType::Void, QMetaType::QByteArray,   13,
    QMetaType::Void, 0x80000000 | 16,   17,
    QMetaType::Void, QMetaType::QString,   19,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   25,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   25,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   30,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,   33,   34,
    QMetaType::Void, QMetaType::QString,   36,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   36,
    QMetaType::Void, QMetaType::QString,   36,
    QMetaType::Void, QMetaType::QString,   41,
    QMetaType::Void, QMetaType::QString,   41,
    QMetaType::Void, QMetaType::QString,   41,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   41,   45,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   41,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   49,   13,
    QMetaType::Void, QMetaType::QString,   49,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   49,   30,
    QMetaType::Void, QMetaType::Int,   53,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->server_response((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->onWindowsStartup(); break;
        case 2: _t->closeEvent((*reinterpret_cast< QCloseEvent*(*)>(_a[1]))); break;
        case 3: _t->closeApplication(); break;
        case 4: _t->showHideMainWindow(); break;
        case 5: _t->onConnected(); break;
        case 6: _t->onDisconnected(); break;
        case 7: _t->reconnect(); break;
        case 8: _t->onTextMessageReceived((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 9: _t->processBinaryMessage((*reinterpret_cast< QByteArray(*)>(_a[1]))); break;
        case 10: _t->onSslErrors((*reinterpret_cast< const QList<QSslError>(*)>(_a[1]))); break;
        case 11: _t->updateHostAddress((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 12: _t->signIn(); break;
        case 13: _t->signOut(); break;
        case 14: _t->autologin(); break;
        case 15: _t->registerNewUserMenu(); break;
        case 16: _t->registrationRequest((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 17: _t->recoverPasswordMenu(); break;
        case 18: _t->recoverPasswordRequest((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 19: _t->changeAvatar(); break;
        case 20: _t->changeAvailability((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 21: _t->updateStatusMessage(); break;
        case 22: _t->lastLoginCounter((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 23: _t->addToGroup((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 24: _t->addNewGroup(); break;
        case 25: _t->addNewGroupConfirmation((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 26: _t->removeGroup((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 27: _t->removeUser((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 28: _t->moveToGroupDown((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 29: _t->moveToGroupUp((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 30: _t->respondFriendRequest((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 31: _t->retrieve_avatar(); break;
        case 32: _t->refreshPeerAvatar((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 33: _t->send_im((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 34: _t->have_read((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 35: _t->get_prev_messages((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 36: _t->delay((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 10:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QList<QSslError> >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (MainWindow::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::server_response)) {
                *result = 0;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 37)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 37;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 37)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 37;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::server_response(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
