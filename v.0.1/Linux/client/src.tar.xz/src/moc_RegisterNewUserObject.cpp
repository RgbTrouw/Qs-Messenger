/****************************************************************************
** Meta object code from reading C++ file 'RegisterNewUserObject.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "Source/Windows/OtherWindows/Headers/RegisterNewUserObject.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'RegisterNewUserObject.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_RegisterNewUserObject_t {
    QByteArrayData data[14];
    char stringdata0[200];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_RegisterNewUserObject_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_RegisterNewUserObject_t qt_meta_stringdata_RegisterNewUserObject = {
    {
QT_MOC_LITERAL(0, 0, 21), // "RegisterNewUserObject"
QT_MOC_LITERAL(1, 22, 14), // "server_request"
QT_MOC_LITERAL(2, 37, 0), // ""
QT_MOC_LITERAL(3, 38, 7), // "request"
QT_MOC_LITERAL(4, 46, 15), // "server_feedback"
QT_MOC_LITERAL(5, 62, 14), // "validate_input"
QT_MOC_LITERAL(6, 77, 30), // "on_registration_Button_clicked"
QT_MOC_LITERAL(7, 108, 8), // "nextPage"
QT_MOC_LITERAL(8, 117, 12), // "previousPage"
QT_MOC_LITERAL(9, 130, 18), // "activateNewAccount"
QT_MOC_LITERAL(10, 149, 20), // "resendActivationCode"
QT_MOC_LITERAL(11, 170, 10), // "closeEvent"
QT_MOC_LITERAL(12, 181, 12), // "QCloseEvent*"
QT_MOC_LITERAL(13, 194, 5) // "event"

    },
    "RegisterNewUserObject\0server_request\0"
    "\0request\0server_feedback\0validate_input\0"
    "on_registration_Button_clicked\0nextPage\0"
    "previousPage\0activateNewAccount\0"
    "resendActivationCode\0closeEvent\0"
    "QCloseEvent*\0event"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_RegisterNewUserObject[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   59,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       4,    1,   62,    2, 0x0a /* Public */,
       5,    0,   65,    2, 0x08 /* Private */,
       6,    0,   66,    2, 0x08 /* Private */,
       7,    0,   67,    2, 0x08 /* Private */,
       8,    0,   68,    2, 0x08 /* Private */,
       9,    0,   69,    2, 0x08 /* Private */,
      10,    0,   70,    2, 0x08 /* Private */,
      11,    1,   71,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 12,   13,

       0        // eod
};

void RegisterNewUserObject::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<RegisterNewUserObject *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->server_request((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->server_feedback((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 2: _t->validate_input(); break;
        case 3: _t->on_registration_Button_clicked(); break;
        case 4: _t->nextPage(); break;
        case 5: _t->previousPage(); break;
        case 6: _t->activateNewAccount(); break;
        case 7: _t->resendActivationCode(); break;
        case 8: _t->closeEvent((*reinterpret_cast< QCloseEvent*(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (RegisterNewUserObject::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RegisterNewUserObject::server_request)) {
                *result = 0;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject RegisterNewUserObject::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_RegisterNewUserObject.data,
    qt_meta_data_RegisterNewUserObject,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *RegisterNewUserObject::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *RegisterNewUserObject::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_RegisterNewUserObject.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int RegisterNewUserObject::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 9;
    }
    return _id;
}

// SIGNAL 0
void RegisterNewUserObject::server_request(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
