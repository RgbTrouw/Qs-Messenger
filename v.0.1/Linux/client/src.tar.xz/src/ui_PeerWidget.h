/********************************************************************************
** Form generated from reading UI file 'PeerWidget.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PEERWIDGET_H
#define UI_PEERWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_PeerWidget
{
public:
    QHBoxLayout *horizontalLayout;
    QLabel *Icon;
    QLabel *label;
    QLabel *statusLabel;

    void setupUi(QWidget *PeerWidget)
    {
        if (PeerWidget->objectName().isEmpty())
            PeerWidget->setObjectName(QString::fromUtf8("PeerWidget"));
        PeerWidget->resize(358, 20);
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(PeerWidget->sizePolicy().hasHeightForWidth());
        PeerWidget->setSizePolicy(sizePolicy);
        PeerWidget->setMinimumSize(QSize(0, 20));
        PeerWidget->setMaximumSize(QSize(16777215, 20));
        PeerWidget->setAutoFillBackground(true);
        PeerWidget->setStyleSheet(QString::fromUtf8(""));
        horizontalLayout = new QHBoxLayout(PeerWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(14, 0, 0, 0);
        Icon = new QLabel(PeerWidget);
        Icon->setObjectName(QString::fromUtf8("Icon"));
        QSizePolicy sizePolicy1(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(Icon->sizePolicy().hasHeightForWidth());
        Icon->setSizePolicy(sizePolicy1);
        Icon->setMaximumSize(QSize(16, 16));
        Icon->setAutoFillBackground(false);
        Icon->setPixmap(QPixmap(QString::fromUtf8("../../../Resources/icons/smiley.png")));
        Icon->setScaledContents(true);

        horizontalLayout->addWidget(Icon);

        label = new QLabel(PeerWidget);
        label->setObjectName(QString::fromUtf8("label"));
        QSizePolicy sizePolicy2(QSizePolicy::Minimum, QSizePolicy::Preferred);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy2);
        label->setMaximumSize(QSize(16777215, 20));
        QFont font;
        font.setPointSize(10);
        label->setFont(font);
        label->setLineWidth(0);
        label->setIndent(0);

        horizontalLayout->addWidget(label);

        statusLabel = new QLabel(PeerWidget);
        statusLabel->setObjectName(QString::fromUtf8("statusLabel"));
        QSizePolicy sizePolicy3(QSizePolicy::Expanding, QSizePolicy::Preferred);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(statusLabel->sizePolicy().hasHeightForWidth());
        statusLabel->setSizePolicy(sizePolicy3);
        statusLabel->setFont(font);

        horizontalLayout->addWidget(statusLabel);


        retranslateUi(PeerWidget);

        QMetaObject::connectSlotsByName(PeerWidget);
    } // setupUi

    void retranslateUi(QWidget *PeerWidget)
    {
        PeerWidget->setWindowTitle(QCoreApplication::translate("PeerWidget", "Form", nullptr));
        PeerWidget->setProperty("class", QVariant(QCoreApplication::translate("PeerWidget", "peerValue", nullptr)));
        Icon->setText(QString());
        Icon->setProperty("class", QVariant(QCoreApplication::translate("PeerWidget", "peerValue", nullptr)));
        label->setText(QCoreApplication::translate("PeerWidget", "Peer", nullptr));
        label->setProperty("class", QVariant(QCoreApplication::translate("PeerWidget", "peerValue", nullptr)));
        statusLabel->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class PeerWidget: public Ui_PeerWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PEERWIDGET_H
