/********************************************************************************
** Form generated from reading UI file 'GroupHeaderWidget.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GROUPHEADERWIDGET_H
#define UI_GROUPHEADERWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_GroupHeaderWidget
{
public:
    QHBoxLayout *horizontalLayout;
    QLabel *groupNameLabel;
    QLabel *counterLabel;
    QLabel *expandIcon;
    QSpacerItem *horizontalSpacer;

    void setupUi(QWidget *GroupHeaderWidget)
    {
        if (GroupHeaderWidget->objectName().isEmpty())
            GroupHeaderWidget->setObjectName(QString::fromUtf8("GroupHeaderWidget"));
        GroupHeaderWidget->resize(320, 21);
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(GroupHeaderWidget->sizePolicy().hasHeightForWidth());
        GroupHeaderWidget->setSizePolicy(sizePolicy);
        GroupHeaderWidget->setMinimumSize(QSize(0, 21));
        GroupHeaderWidget->setMaximumSize(QSize(16777215, 21));
        GroupHeaderWidget->setStyleSheet(QString::fromUtf8(""));
        horizontalLayout = new QHBoxLayout(GroupHeaderWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(6, 0, 0, 0);
        groupNameLabel = new QLabel(GroupHeaderWidget);
        groupNameLabel->setObjectName(QString::fromUtf8("groupNameLabel"));
        QSizePolicy sizePolicy1(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(groupNameLabel->sizePolicy().hasHeightForWidth());
        groupNameLabel->setSizePolicy(sizePolicy1);
        groupNameLabel->setMinimumSize(QSize(0, 21));
        groupNameLabel->setMaximumSize(QSize(16777215, 21));
        QFont font;
        font.setPointSize(10);
        groupNameLabel->setFont(font);
        groupNameLabel->setStyleSheet(QString::fromUtf8("color:rgb(52, 101, 164)"));

        horizontalLayout->addWidget(groupNameLabel);

        counterLabel = new QLabel(GroupHeaderWidget);
        counterLabel->setObjectName(QString::fromUtf8("counterLabel"));
        QSizePolicy sizePolicy2(QSizePolicy::Minimum, QSizePolicy::Preferred);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(counterLabel->sizePolicy().hasHeightForWidth());
        counterLabel->setSizePolicy(sizePolicy2);
        counterLabel->setMinimumSize(QSize(0, 21));
        counterLabel->setMaximumSize(QSize(16777215, 21));
        counterLabel->setFont(font);
        counterLabel->setStyleSheet(QString::fromUtf8("color:rgb(52, 101, 164)"));

        horizontalLayout->addWidget(counterLabel);

        expandIcon = new QLabel(GroupHeaderWidget);
        expandIcon->setObjectName(QString::fromUtf8("expandIcon"));
        QSizePolicy sizePolicy3(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(expandIcon->sizePolicy().hasHeightForWidth());
        expandIcon->setSizePolicy(sizePolicy3);
        expandIcon->setMinimumSize(QSize(20, 20));
        expandIcon->setMaximumSize(QSize(20, 20));
        expandIcon->setPixmap(QPixmap(QString::fromUtf8("../../../Resources/icons/indent_triangle.png")));
        expandIcon->setScaledContents(false);

        horizontalLayout->addWidget(expandIcon);

        horizontalSpacer = new QSpacerItem(228, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);


        retranslateUi(GroupHeaderWidget);

        QMetaObject::connectSlotsByName(GroupHeaderWidget);
    } // setupUi

    void retranslateUi(QWidget *GroupHeaderWidget)
    {
        GroupHeaderWidget->setWindowTitle(QCoreApplication::translate("GroupHeaderWidget", "Form", nullptr));
        groupNameLabel->setText(QCoreApplication::translate("GroupHeaderWidget", "Group", nullptr));
        counterLabel->setText(QString());
        expandIcon->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class GroupHeaderWidget: public Ui_GroupHeaderWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GROUPHEADERWIDGET_H
