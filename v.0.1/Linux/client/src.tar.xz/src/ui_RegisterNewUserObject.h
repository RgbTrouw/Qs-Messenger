/********************************************************************************
** Form generated from reading UI file 'RegisterNewUserObject.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_REGISTERNEWUSEROBJECT_H
#define UI_REGISTERNEWUSEROBJECT_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_RegisterNewUserObject
{
public:
    QGridLayout *gridLayout;
    QStackedWidget *stackedWidget;
    QWidget *page;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_2;
    QLabel *create_Label;
    QSpacerItem *verticalSpacer_4;
    QLineEdit *full_name_Prompt;
    QLineEdit *nick_Prompt;
    QLineEdit *date_of_birthPrompt;
    QComboBox *countriesBox;
    QHBoxLayout *horizontalLayout;
    QRadioButton *male_radioButton;
    QRadioButton *female_radioButton;
    QSpacerItem *verticalSpacer_2;
    QLineEdit *email_Prompt;
    QSpacerItem *verticalSpacer_5;
    QLineEdit *password_Prompt;
    QLineEdit *password_2_Prompt;
    QSpacerItem *verticalSpacer_3;
    QTextBrowser *agreement_textBox;
    QCheckBox *agreement_checkBox;
    QHBoxLayout *horizontalLayout_5;
    QPushButton *registration_Button;
    QPushButton *pageButton;
    QLabel *message_Label;
    QWidget *page_2;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_2;
    QLineEdit *activation_code_Prompt;
    QHBoxLayout *horizontalLayout_4;
    QPushButton *resendEmailButton;
    QPushButton *activateButton;
    QPushButton *pageButton2;
    QLabel *message_Label_2;

    void setupUi(QWidget *RegisterNewUserObject)
    {
        if (RegisterNewUserObject->objectName().isEmpty())
            RegisterNewUserObject->setObjectName(QString::fromUtf8("RegisterNewUserObject"));
        RegisterNewUserObject->resize(407, 503);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(RegisterNewUserObject->sizePolicy().hasHeightForWidth());
        RegisterNewUserObject->setSizePolicy(sizePolicy);
        RegisterNewUserObject->setMinimumSize(QSize(407, 503));
        RegisterNewUserObject->setMaximumSize(QSize(407, 503));
        QFont font;
        font.setPointSize(10);
        RegisterNewUserObject->setFont(font);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/icons/icons/2221968.png"), QSize(), QIcon::Normal, QIcon::Off);
        RegisterNewUserObject->setWindowIcon(icon);
        gridLayout = new QGridLayout(RegisterNewUserObject);
        gridLayout->setSpacing(4);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        stackedWidget = new QStackedWidget(RegisterNewUserObject);
        stackedWidget->setObjectName(QString::fromUtf8("stackedWidget"));
        page = new QWidget();
        page->setObjectName(QString::fromUtf8("page"));
        verticalLayout = new QVBoxLayout(page);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(-1, 0, -1, -1);
        create_Label = new QLabel(page);
        create_Label->setObjectName(QString::fromUtf8("create_Label"));
        create_Label->setMinimumSize(QSize(0, 26));
        create_Label->setFont(font);
        create_Label->setStyleSheet(QString::fromUtf8("color: rgb(52, 101, 164);"));

        horizontalLayout_2->addWidget(create_Label);


        verticalLayout->addLayout(horizontalLayout_2);

        verticalSpacer_4 = new QSpacerItem(20, 5, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout->addItem(verticalSpacer_4);

        full_name_Prompt = new QLineEdit(page);
        full_name_Prompt->setObjectName(QString::fromUtf8("full_name_Prompt"));
        full_name_Prompt->setFont(font);
        full_name_Prompt->setLayoutDirection(Qt::RightToLeft);
        full_name_Prompt->setMaxLength(32767);

        verticalLayout->addWidget(full_name_Prompt);

        nick_Prompt = new QLineEdit(page);
        nick_Prompt->setObjectName(QString::fromUtf8("nick_Prompt"));
        nick_Prompt->setFont(font);

        verticalLayout->addWidget(nick_Prompt);

        date_of_birthPrompt = new QLineEdit(page);
        date_of_birthPrompt->setObjectName(QString::fromUtf8("date_of_birthPrompt"));
        date_of_birthPrompt->setFont(font);

        verticalLayout->addWidget(date_of_birthPrompt);

        countriesBox = new QComboBox(page);
        countriesBox->setObjectName(QString::fromUtf8("countriesBox"));
        countriesBox->setFont(font);

        verticalLayout->addWidget(countriesBox);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(-1, 0, -1, -1);
        male_radioButton = new QRadioButton(page);
        male_radioButton->setObjectName(QString::fromUtf8("male_radioButton"));
        male_radioButton->setFont(font);
        male_radioButton->setLayoutDirection(Qt::RightToLeft);
        male_radioButton->setStyleSheet(QString::fromUtf8(""));
        male_radioButton->setChecked(true);

        horizontalLayout->addWidget(male_radioButton);

        female_radioButton = new QRadioButton(page);
        female_radioButton->setObjectName(QString::fromUtf8("female_radioButton"));
        female_radioButton->setFont(font);
        female_radioButton->setLayoutDirection(Qt::RightToLeft);
        female_radioButton->setStyleSheet(QString::fromUtf8(""));

        horizontalLayout->addWidget(female_radioButton);


        verticalLayout->addLayout(horizontalLayout);

        verticalSpacer_2 = new QSpacerItem(20, 4, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout->addItem(verticalSpacer_2);

        email_Prompt = new QLineEdit(page);
        email_Prompt->setObjectName(QString::fromUtf8("email_Prompt"));
        email_Prompt->setFont(font);

        verticalLayout->addWidget(email_Prompt);

        verticalSpacer_5 = new QSpacerItem(20, 4, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout->addItem(verticalSpacer_5);

        password_Prompt = new QLineEdit(page);
        password_Prompt->setObjectName(QString::fromUtf8("password_Prompt"));
        password_Prompt->setFont(font);
        password_Prompt->setEchoMode(QLineEdit::Password);

        verticalLayout->addWidget(password_Prompt);

        password_2_Prompt = new QLineEdit(page);
        password_2_Prompt->setObjectName(QString::fromUtf8("password_2_Prompt"));
        password_2_Prompt->setFont(font);
        password_2_Prompt->setEchoMode(QLineEdit::Password);

        verticalLayout->addWidget(password_2_Prompt);

        verticalSpacer_3 = new QSpacerItem(20, 4, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout->addItem(verticalSpacer_3);

        agreement_textBox = new QTextBrowser(page);
        agreement_textBox->setObjectName(QString::fromUtf8("agreement_textBox"));
        agreement_textBox->setEnabled(true);
        agreement_textBox->setFont(font);

        verticalLayout->addWidget(agreement_textBox);

        agreement_checkBox = new QCheckBox(page);
        agreement_checkBox->setObjectName(QString::fromUtf8("agreement_checkBox"));
        agreement_checkBox->setFont(font);
        agreement_checkBox->setLayoutDirection(Qt::LeftToRight);
        agreement_checkBox->setChecked(false);

        verticalLayout->addWidget(agreement_checkBox);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(4);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(-1, 0, -1, -1);
        registration_Button = new QPushButton(page);
        registration_Button->setObjectName(QString::fromUtf8("registration_Button"));
        registration_Button->setMinimumSize(QSize(0, 25));
        registration_Button->setMaximumSize(QSize(16777215, 25));
        registration_Button->setFont(font);
        QIcon icon1;
        icon1.addFile(QString::fromUtf8("../../../../Resources/icons/registration.png"), QSize(), QIcon::Normal, QIcon::On);
        registration_Button->setIcon(icon1);

        horizontalLayout_5->addWidget(registration_Button);

        pageButton = new QPushButton(page);
        pageButton->setObjectName(QString::fromUtf8("pageButton"));
        sizePolicy.setHeightForWidth(pageButton->sizePolicy().hasHeightForWidth());
        pageButton->setSizePolicy(sizePolicy);
        pageButton->setMinimumSize(QSize(25, 25));
        pageButton->setMaximumSize(QSize(25, 25));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8("../../../../Resources/icons/triangle_right.png"), QSize(), QIcon::Normal, QIcon::On);
        pageButton->setIcon(icon2);

        horizontalLayout_5->addWidget(pageButton);


        verticalLayout->addLayout(horizontalLayout_5);

        message_Label = new QLabel(page);
        message_Label->setObjectName(QString::fromUtf8("message_Label"));
        message_Label->setEnabled(false);
        message_Label->setMinimumSize(QSize(0, 17));
        message_Label->setMaximumSize(QSize(407, 17));
        QFont font1;
        font1.setPointSize(9);
        message_Label->setFont(font1);
        message_Label->setLayoutDirection(Qt::LeftToRight);
        message_Label->setStyleSheet(QString::fromUtf8("color: rgb(60, 150, 0);"));
        message_Label->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        verticalLayout->addWidget(message_Label);

        stackedWidget->addWidget(page);
        page_2 = new QWidget();
        page_2->setObjectName(QString::fromUtf8("page_2"));
        verticalLayout_2 = new QVBoxLayout(page_2);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_2 = new QLabel(page_2);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(label_2->sizePolicy().hasHeightForWidth());
        label_2->setSizePolicy(sizePolicy1);
        label_2->setFont(font);
        label_2->setStyleSheet(QString::fromUtf8("color: rgb(52, 101, 164);"));

        horizontalLayout_3->addWidget(label_2);


        verticalLayout_2->addLayout(horizontalLayout_3);

        activation_code_Prompt = new QLineEdit(page_2);
        activation_code_Prompt->setObjectName(QString::fromUtf8("activation_code_Prompt"));
        QSizePolicy sizePolicy2(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(20);
        sizePolicy2.setHeightForWidth(activation_code_Prompt->sizePolicy().hasHeightForWidth());
        activation_code_Prompt->setSizePolicy(sizePolicy2);
        activation_code_Prompt->setMinimumSize(QSize(0, 25));
        activation_code_Prompt->setMaximumSize(QSize(16777215, 25));
        activation_code_Prompt->setFont(font);

        verticalLayout_2->addWidget(activation_code_Prompt);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(4);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        resendEmailButton = new QPushButton(page_2);
        resendEmailButton->setObjectName(QString::fromUtf8("resendEmailButton"));
        sizePolicy.setHeightForWidth(resendEmailButton->sizePolicy().hasHeightForWidth());
        resendEmailButton->setSizePolicy(sizePolicy);
        resendEmailButton->setMinimumSize(QSize(80, 25));
        resendEmailButton->setMaximumSize(QSize(80, 25));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8("../../../../Resources/icons/sendEmail.png"), QSize(), QIcon::Normal, QIcon::On);
        resendEmailButton->setIcon(icon3);
        resendEmailButton->setIconSize(QSize(24, 24));

        horizontalLayout_4->addWidget(resendEmailButton);

        activateButton = new QPushButton(page_2);
        activateButton->setObjectName(QString::fromUtf8("activateButton"));
        activateButton->setMinimumSize(QSize(0, 25));
        activateButton->setMaximumSize(QSize(16777215, 25));
        activateButton->setFont(font);
        QIcon icon4;
        icon4.addFile(QString::fromUtf8("../../../../Resources/icons/2221968.png"), QSize(), QIcon::Normal, QIcon::On);
        activateButton->setIcon(icon4);

        horizontalLayout_4->addWidget(activateButton);

        pageButton2 = new QPushButton(page_2);
        pageButton2->setObjectName(QString::fromUtf8("pageButton2"));
        sizePolicy.setHeightForWidth(pageButton2->sizePolicy().hasHeightForWidth());
        pageButton2->setSizePolicy(sizePolicy);
        pageButton2->setMinimumSize(QSize(25, 25));
        pageButton2->setMaximumSize(QSize(25, 25));
        QIcon icon5;
        icon5.addFile(QString::fromUtf8("../../../../Resources/icons/triangle_left.png"), QSize(), QIcon::Normal, QIcon::On);
        pageButton2->setIcon(icon5);

        horizontalLayout_4->addWidget(pageButton2);


        verticalLayout_2->addLayout(horizontalLayout_4);

        message_Label_2 = new QLabel(page_2);
        message_Label_2->setObjectName(QString::fromUtf8("message_Label_2"));
        message_Label_2->setEnabled(false);
        message_Label_2->setMinimumSize(QSize(0, 17));
        message_Label_2->setMaximumSize(QSize(407, 17));
        message_Label_2->setFont(font1);
        message_Label_2->setLayoutDirection(Qt::LeftToRight);
        message_Label_2->setStyleSheet(QString::fromUtf8("color: rgb(60, 150, 0);"));
        message_Label_2->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        verticalLayout_2->addWidget(message_Label_2);

        stackedWidget->addWidget(page_2);

        gridLayout->addWidget(stackedWidget, 1, 1, 1, 1);


        retranslateUi(RegisterNewUserObject);

        stackedWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(RegisterNewUserObject);
    } // setupUi

    void retranslateUi(QWidget *RegisterNewUserObject)
    {
        RegisterNewUserObject->setWindowTitle(QCoreApplication::translate("RegisterNewUserObject", "Form", nullptr));
        create_Label->setText(QCoreApplication::translate("RegisterNewUserObject", "Create a new user account...", nullptr));
#if QT_CONFIG(tooltip)
        full_name_Prompt->setToolTip(QCoreApplication::translate("RegisterNewUserObject", "allowed format: [A-Z][a-z] space \"van\", \"of\", \"de la\";", nullptr));
#endif // QT_CONFIG(tooltip)
        full_name_Prompt->setInputMask(QString());
        full_name_Prompt->setText(QString());
        full_name_Prompt->setPlaceholderText(QCoreApplication::translate("RegisterNewUserObject", "Full Name", nullptr));
#if QT_CONFIG(tooltip)
        nick_Prompt->setToolTip(QCoreApplication::translate("RegisterNewUserObject", "allowed format: a-Z 0-9 and underscore", nullptr));
#endif // QT_CONFIG(tooltip)
        nick_Prompt->setText(QString());
        nick_Prompt->setPlaceholderText(QCoreApplication::translate("RegisterNewUserObject", "Nickname", nullptr));
        date_of_birthPrompt->setPlaceholderText(QCoreApplication::translate("RegisterNewUserObject", "Date of Birth: dd/mm/yyyy", nullptr));
        male_radioButton->setText(QCoreApplication::translate("RegisterNewUserObject", "male", nullptr));
        female_radioButton->setText(QCoreApplication::translate("RegisterNewUserObject", "female", nullptr));
#if QT_CONFIG(tooltip)
        email_Prompt->setToolTip(QCoreApplication::translate("RegisterNewUserObject", "standard email format", nullptr));
#endif // QT_CONFIG(tooltip)
        email_Prompt->setText(QString());
        email_Prompt->setPlaceholderText(QCoreApplication::translate("RegisterNewUserObject", "Email", nullptr));
#if QT_CONFIG(tooltip)
        password_Prompt->setToolTip(QCoreApplication::translate("RegisterNewUserObject", "allowed characters: a-Z 0-9 underscore, dot, minus, plus, equals", nullptr));
#endif // QT_CONFIG(tooltip)
        password_Prompt->setText(QString());
        password_Prompt->setPlaceholderText(QCoreApplication::translate("RegisterNewUserObject", "Password: min. 8, max. 24 characters", nullptr));
#if QT_CONFIG(tooltip)
        password_2_Prompt->setToolTip(QCoreApplication::translate("RegisterNewUserObject", "allowed characters: a-Z 0-9 underscore, dot, minus, plus, equals", nullptr));
#endif // QT_CONFIG(tooltip)
        password_2_Prompt->setText(QString());
        password_2_Prompt->setPlaceholderText(QCoreApplication::translate("RegisterNewUserObject", "Password: min. 8, max. 24 characters", nullptr));
        agreement_textBox->setHtml(QCoreApplication::translate("RegisterNewUserObject", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">User Agreement</p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:9pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:9pt;\">This User Agreement (the &quot;Agreement&quot;) is applied upon clicking the &quot;Submit&quot; button, by and between:</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left"
                        ":0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:9pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:9pt;\">The  Above Registered Person</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:9pt;\">&amp;</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:9pt;\">QsMessenger Headmaster</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:"
                        "0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:9pt;\"><br /></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:9pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:9pt;\">1. Acceptance of Terms</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:9pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:9pt;\">By accessing or using QsMessenger (the &quot;Service&quot;), you agree to comply with and be bound by this Agreement and any additional terms and conditions that may apply to specific features of the S"
                        "ervice.</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:9pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:9pt;\">2. Use of the Service</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:9pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:9pt;\">a) Age Requirement: You must be at least 18 years old to use the Service.</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:9pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:"
                        "0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:9pt;\">b) Registration: You may be required to register for an account to access certain features of the Service. You agree to provide accurate and complete information when registering for an account.</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:9pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:9pt;\">c) Prohibited Activities: You agree not to engage in any of the following prohibited activities:</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:9pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-b"
                        "lock-indent:0; text-indent:0px;\"><span style=\" font-size:9pt;\">- Violating any laws, regulations, or third-party rights.</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:9pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:9pt;\">- Posting or transmitting unauthorized or unsolicited advertising, promotional materials, or spam.</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:9pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:9pt;\">- Impersonating any person or entity or falsely  stating or missrepresenting your affiliation with a person or ent"
                        "ity.</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:9pt;\">- Interfering with or disrupting the Service or servers, or networks connected to the Service.</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:9pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:9pt;\">3. Intellectual Property</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:9pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:9pt;\">All content, trademarks, logos, and other in"
                        "tellectual property rights related to the Service are the property of QsMessenger Headmaster or it's licensors. </span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:9pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:9pt;\">You are granted a limited, non exclusive, non-transferable license to use the Service for personal, non-commercial purposes.</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:9pt;\"><br /></p></body></html>", nullptr));
        agreement_checkBox->setText(QCoreApplication::translate("RegisterNewUserObject", "I have read and agree to the licence agreement   ", nullptr));
        registration_Button->setText(QCoreApplication::translate("RegisterNewUserObject", "Submit", nullptr));
#if QT_CONFIG(tooltip)
        pageButton->setToolTip(QCoreApplication::translate("RegisterNewUserObject", "next", nullptr));
#endif // QT_CONFIG(tooltip)
        pageButton->setText(QString());
        message_Label->setText(QCoreApplication::translate("RegisterNewUserObject", "  ...", nullptr));
        label_2->setText(QCoreApplication::translate("RegisterNewUserObject", "Activate new user account...", nullptr));
        activation_code_Prompt->setText(QString());
        activation_code_Prompt->setPlaceholderText(QCoreApplication::translate("RegisterNewUserObject", "Activation Code", nullptr));
        resendEmailButton->setText(QCoreApplication::translate("RegisterNewUserObject", "Resend", nullptr));
        activateButton->setText(QCoreApplication::translate("RegisterNewUserObject", "Activate", nullptr));
#if QT_CONFIG(tooltip)
        pageButton2->setToolTip(QCoreApplication::translate("RegisterNewUserObject", "back", nullptr));
#endif // QT_CONFIG(tooltip)
        pageButton2->setText(QString());
        message_Label_2->setText(QCoreApplication::translate("RegisterNewUserObject", "  ...", nullptr));
    } // retranslateUi

};

namespace Ui {
    class RegisterNewUserObject: public Ui_RegisterNewUserObject {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_REGISTERNEWUSEROBJECT_H
