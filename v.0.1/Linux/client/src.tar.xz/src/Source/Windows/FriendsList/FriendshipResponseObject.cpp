#include "Headers/FriendshipResponseObject.h"
#include "ui_FriendshipResponseObject.h"
#include <QTimer>

FriendshipResponseObject::FriendshipResponseObject(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FriendshipResponseObject)
{
    ui->setupUi(this);
    ui->pushButton->setIcon(QIcon("/usr/local/share/QsMessenger/Resources/icons/addUser.png"));

}

FriendshipResponseObject::~FriendshipResponseObject()
{
    delete ui;
}

void FriendshipResponseObject::on_pushButton_clicked()
{

    QString rsp = "yes";

    ui->label->setText("  Friendship accepted...");

    st->singleShot(2000, this, SLOT(feedback()));

    emit respond_fr( ui->emailLabel->text(), rsp );
}

void FriendshipResponseObject::on_pushButton_2_clicked()
{
    QString rsp = "no";

    st->singleShot(2000, this, SLOT(feedback()));

    ui->label->setText("  Friendship declined...");
    emit respond_fr(ui->emailLabel->text(), rsp);
}

void FriendshipResponseObject::from(QString email){

    ui->emailLabel->setText(email);
}

void FriendshipResponseObject::feedback(){

    ui->emailLabel->setText("");
    ui->label->setText("");
    this->close();
}

void FriendshipResponseObject::closeEvent (QCloseEvent *event)
{

}
