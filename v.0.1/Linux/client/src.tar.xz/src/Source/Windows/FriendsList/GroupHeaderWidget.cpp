#include "Headers/GroupHeaderWidget.h"
#include "ui_GroupHeaderWidget.h"
#include <QDebug>
#include <QTimer>

GroupHeaderWidget::GroupHeaderWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::GroupHeaderWidget)
{
    ui->setupUi(this);
    ui->expandIcon->setPixmap(QPixmap("/usr/local/share/QsMessenger/Resources/icons/triangle_down.png"));
    this->installEventFilter(this);
    this->setAttribute(Qt::WA_StyledBackground, true);
    this->setAttribute(Qt::WA_Hover, true);

    this->setContextMenuPolicy(Qt::CustomContextMenu);

    contextMenuFont.setPointSize(10);
    contextMenu->setFont(contextMenuFont);

    addNewGroupAction->setText("Add New Group");
    addNewUserAction->setText("Add New User");
    removeGroupAction->setText("Remove Group");

    addNewGroupAction->setFont(contextMenuFont);
    addNewGroupAction->setFont(contextMenuFont);
    removeGroupAction->setFont(contextMenuFont);

    addNewUserAction->setIcon(QIcon("/usr/local/share/QsMessenger/Resources/icons/addUser.png"));
    addNewGroupAction->setIcon(QIcon("/usr/local/share/QsMessenger/Resources/icons/addGroup.png"));
    removeGroupAction->setIcon(QIcon("/usr/local/share/QsMessenger/Resources/icons/trashBinGroups.png"));


    contextMenu->addAction(addNewUserAction);
    contextMenu->addAction(addNewGroupAction);

    connect(this, SIGNAL(customContextMenuRequested(QPoint)), this, SLOT(customContextMenu(QPoint)));

}

GroupHeaderWidget::~GroupHeaderWidget()
{
    this->disconnect();
    delete ui;

}

void GroupHeaderWidget::setName(QString name){

    GroupName = name;

    ui->groupNameLabel->setText(GroupName);

}

void GroupHeaderWidget::setCounterLabel(QString data){

    ui->counterLabel->setText(data);
}

void GroupHeaderWidget::hover(bool value){

    if(value){
        this->setStyleSheet("background-color: rgb(238, 238, 236);");
    } else {
         this->setStyleSheet("background-color:rgb(255, 255, 255);");
    }

}


bool GroupHeaderWidget::eventFilter(QObject *object, QEvent *event)
{
    bool returnValue;

    if (event->type() == QEvent::HoverEnter)
    {

        returnValue = true;
        hover(true);

    }

    if (event->type() == QEvent::HoverLeave)
    {
        returnValue = false;

        hover(false);

    }
    return returnValue;
}

void GroupHeaderWidget::customContextMenu(QPoint positionPoint){

//    qInfo() << positionPoint;

    QTimer::singleShot(1000, this , [=](){hover(false);});
    contextMenu->show();
    contextMenu->move(this->mapToGlobal(positionPoint).x(),this->mapToGlobal(positionPoint).y());

}

void GroupHeaderWidget::mousePressEvent(QMouseEvent *event){

    if(event->type() == QMouseEvent::MouseButtonPress){
        if (event->button() == Qt::LeftButton){
        emit changePeersDisplay(currentType);
        }
    };
}

void GroupHeaderWidget::setIconMode(QString mode){

    if (mode == "up"){ui->expandIcon->setPixmap(QPixmap("/usr/local/share/QsMessenger/Resources/icons/triangle_up.png")); }
    else if (mode == "middle"){ui->expandIcon->setPixmap(QPixmap("/usr/local/share/QsMessenger/Resources/icons/triangle_right.png")); }
    else if (mode == "down"){ui->expandIcon->setPixmap(QPixmap("/usr/local/share/QsMessenger/Resources/icons/triangle_down.png")); }

}
