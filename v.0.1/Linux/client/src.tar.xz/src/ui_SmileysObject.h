/********************************************************************************
** Form generated from reading UI file 'SmileysObject.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SMILEYSOBJECT_H
#define UI_SMILEYSOBJECT_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SmileysObject
{
public:
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_3;
    QPushButton *pushButton;
    QPushButton *pushButton_5;
    QPushButton *pushButton_3;
    QPushButton *pushButton_6;
    QPushButton *pushButton_10;
    QHBoxLayout *horizontalLayout_4;
    QPushButton *pushButton_4;
    QPushButton *pushButton_2;
    QPushButton *pushButton_8;
    QPushButton *pushButton_9;
    QPushButton *pushButton_7;

    void setupUi(QWidget *SmileysObject)
    {
        if (SmileysObject->objectName().isEmpty())
            SmileysObject->setObjectName(QString::fromUtf8("SmileysObject"));
        SmileysObject->resize(136, 56);
        SmileysObject->setMinimumSize(QSize(136, 56));
        SmileysObject->setMaximumSize(QSize(136, 56));
        gridLayout = new QGridLayout(SmileysObject);
        gridLayout->setSpacing(0);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(2);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(-1, 0, -1, -1);
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(2);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        pushButton = new QPushButton(SmileysObject);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setMinimumSize(QSize(24, 24));
        pushButton->setMaximumSize(QSize(24, 24));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/smileys/smileys/pack1/smile.png"), QSize(), QIcon::Normal, QIcon::On);
        pushButton->setIcon(icon);
        pushButton->setIconSize(QSize(24, 24));
        pushButton->setFlat(true);

        horizontalLayout_3->addWidget(pushButton);

        pushButton_5 = new QPushButton(SmileysObject);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setMinimumSize(QSize(24, 24));
        pushButton_5->setMaximumSize(QSize(24, 24));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/smileys/smileys/pack1/laughing.png"), QSize(), QIcon::Normal, QIcon::On);
        pushButton_5->setIcon(icon1);
        pushButton_5->setIconSize(QSize(24, 24));
        pushButton_5->setFlat(true);

        horizontalLayout_3->addWidget(pushButton_5);

        pushButton_3 = new QPushButton(SmileysObject);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setMinimumSize(QSize(24, 24));
        pushButton_3->setMaximumSize(QSize(24, 24));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/smileys/smileys/pack1/shy.png"), QSize(), QIcon::Normal, QIcon::On);
        pushButton_3->setIcon(icon2);
        pushButton_3->setIconSize(QSize(24, 24));
        pushButton_3->setFlat(true);

        horizontalLayout_3->addWidget(pushButton_3);

        pushButton_6 = new QPushButton(SmileysObject);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setMinimumSize(QSize(24, 24));
        pushButton_6->setMaximumSize(QSize(24, 24));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/smileys/smileys/pack1/love.png"), QSize(), QIcon::Normal, QIcon::On);
        pushButton_6->setIcon(icon3);
        pushButton_6->setIconSize(QSize(24, 24));
        pushButton_6->setFlat(true);

        horizontalLayout_3->addWidget(pushButton_6);

        pushButton_10 = new QPushButton(SmileysObject);
        pushButton_10->setObjectName(QString::fromUtf8("pushButton_10"));
        pushButton_10->setMinimumSize(QSize(24, 24));
        pushButton_10->setMaximumSize(QSize(24, 24));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/smileys/smileys/pack1/absent.png"), QSize(), QIcon::Normal, QIcon::On);
        pushButton_10->setIcon(icon4);
        pushButton_10->setIconSize(QSize(24, 24));
        pushButton_10->setFlat(true);

        horizontalLayout_3->addWidget(pushButton_10);


        verticalLayout_2->addLayout(horizontalLayout_3);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(2);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        pushButton_4 = new QPushButton(SmileysObject);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setMinimumSize(QSize(24, 24));
        pushButton_4->setMaximumSize(QSize(24, 24));
        QIcon icon5;
        icon5.addFile(QString::fromUtf8(":/smileys/smileys/pack1/bgrin.png"), QSize(), QIcon::Normal, QIcon::On);
        pushButton_4->setIcon(icon5);
        pushButton_4->setIconSize(QSize(24, 24));
        pushButton_4->setFlat(true);

        horizontalLayout_4->addWidget(pushButton_4);

        pushButton_2 = new QPushButton(SmileysObject);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setMinimumSize(QSize(24, 24));
        pushButton_2->setMaximumSize(QSize(24, 24));
        QIcon icon6;
        icon6.addFile(QString::fromUtf8(":/smileys/smileys/pack1/sad.png"), QSize(), QIcon::Normal, QIcon::On);
        pushButton_2->setIcon(icon6);
        pushButton_2->setIconSize(QSize(24, 24));
        pushButton_2->setFlat(true);

        horizontalLayout_4->addWidget(pushButton_2);

        pushButton_8 = new QPushButton(SmileysObject);
        pushButton_8->setObjectName(QString::fromUtf8("pushButton_8"));
        pushButton_8->setMinimumSize(QSize(24, 24));
        pushButton_8->setMaximumSize(QSize(24, 24));
        QIcon icon7;
        icon7.addFile(QString::fromUtf8(":/smileys/smileys/pack1/upset.png"), QSize(), QIcon::Normal, QIcon::On);
        pushButton_8->setIcon(icon7);
        pushButton_8->setIconSize(QSize(24, 24));
        pushButton_8->setFlat(true);

        horizontalLayout_4->addWidget(pushButton_8);

        pushButton_9 = new QPushButton(SmileysObject);
        pushButton_9->setObjectName(QString::fromUtf8("pushButton_9"));
        pushButton_9->setMinimumSize(QSize(24, 24));
        pushButton_9->setMaximumSize(QSize(24, 24));
        QIcon icon8;
        icon8.addFile(QString::fromUtf8(":/smileys/smileys/pack1/crying.png"), QSize(), QIcon::Normal, QIcon::On);
        pushButton_9->setIcon(icon8);
        pushButton_9->setIconSize(QSize(24, 24));
        pushButton_9->setFlat(true);

        horizontalLayout_4->addWidget(pushButton_9);

        pushButton_7 = new QPushButton(SmileysObject);
        pushButton_7->setObjectName(QString::fromUtf8("pushButton_7"));
        pushButton_7->setMinimumSize(QSize(24, 24));
        pushButton_7->setMaximumSize(QSize(24, 24));
        QIcon icon9;
        icon9.addFile(QString::fromUtf8(":/smileys/smileys/pack1/surprised.png"), QSize(), QIcon::Normal, QIcon::On);
        pushButton_7->setIcon(icon9);
        pushButton_7->setIconSize(QSize(24, 24));
        pushButton_7->setFlat(true);

        horizontalLayout_4->addWidget(pushButton_7);


        verticalLayout_2->addLayout(horizontalLayout_4);


        gridLayout->addLayout(verticalLayout_2, 0, 4, 1, 1);


        retranslateUi(SmileysObject);

        QMetaObject::connectSlotsByName(SmileysObject);
    } // setupUi

    void retranslateUi(QWidget *SmileysObject)
    {
        SmileysObject->setWindowTitle(QCoreApplication::translate("SmileysObject", "Form", nullptr));
        pushButton->setText(QString());
        pushButton_5->setText(QString());
        pushButton_3->setText(QString());
        pushButton_6->setText(QString());
        pushButton_10->setText(QString());
        pushButton_4->setText(QString());
        pushButton_2->setText(QString());
        pushButton_8->setText(QString());
        pushButton_9->setText(QString());
        pushButton_7->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class SmileysObject: public Ui_SmileysObject {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SMILEYSOBJECT_H
