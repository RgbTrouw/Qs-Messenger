/****************************************************************************
** Meta object code from reading C++ file 'FriendsGroup.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "Source/Objects/Headers/FriendsGroup.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'FriendsGroup.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_GroupObject_t {
    QByteArrayData data[14];
    char stringdata0[176];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_GroupObject_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_GroupObject_t qt_meta_stringdata_GroupObject = {
    {
QT_MOC_LITERAL(0, 0, 11), // "GroupObject"
QT_MOC_LITERAL(1, 12, 14), // "set_group_name"
QT_MOC_LITERAL(2, 27, 0), // ""
QT_MOC_LITERAL(3, 28, 4), // "name"
QT_MOC_LITERAL(4, 33, 14), // "set_plain_data"
QT_MOC_LITERAL(5, 48, 4), // "data"
QT_MOC_LITERAL(6, 53, 14), // "get_group_name"
QT_MOC_LITERAL(7, 68, 17), // "group_peers_count"
QT_MOC_LITERAL(8, 86, 24), // "group_peers_online_count"
QT_MOC_LITERAL(9, 111, 19), // "get_item_model_item"
QT_MOC_LITERAL(10, 131, 14), // "QStandardItem*"
QT_MOC_LITERAL(11, 146, 11), // "get_user_at"
QT_MOC_LITERAL(12, 158, 11), // "PeerObject*"
QT_MOC_LITERAL(13, 170, 5) // "index"

    },
    "GroupObject\0set_group_name\0\0name\0"
    "set_plain_data\0data\0get_group_name\0"
    "group_peers_count\0group_peers_online_count\0"
    "get_item_model_item\0QStandardItem*\0"
    "get_user_at\0PeerObject*\0index"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_GroupObject[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,   49,    2, 0x0a /* Public */,
       4,    1,   52,    2, 0x0a /* Public */,
       6,    0,   55,    2, 0x0a /* Public */,
       7,    0,   56,    2, 0x0a /* Public */,
       8,    0,   57,    2, 0x0a /* Public */,
       9,    0,   58,    2, 0x0a /* Public */,
      11,    1,   59,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::QString,
    QMetaType::Int,
    QMetaType::Int,
    0x80000000 | 10,
    0x80000000 | 12, QMetaType::Int,   13,

       0        // eod
};

void GroupObject::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<GroupObject *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->set_group_name((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->set_plain_data((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 2: { QString _r = _t->get_group_name();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 3: { int _r = _t->group_peers_count();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 4: { int _r = _t->group_peers_online_count();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 5: { QStandardItem* _r = _t->get_item_model_item();
            if (_a[0]) *reinterpret_cast< QStandardItem**>(_a[0]) = std::move(_r); }  break;
        case 6: { PeerObject* _r = _t->get_user_at((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< PeerObject**>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject GroupObject::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_GroupObject.data,
    qt_meta_data_GroupObject,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *GroupObject::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *GroupObject::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_GroupObject.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int GroupObject::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 7)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 7;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
