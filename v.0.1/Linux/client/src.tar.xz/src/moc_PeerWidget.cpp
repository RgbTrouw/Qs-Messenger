/****************************************************************************
** Meta object code from reading C++ file 'PeerWidget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "Source/Windows/FriendsList/Headers/PeerWidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'PeerWidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_PeerWidget_t {
    QByteArrayData data[21];
    char stringdata0[254];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_PeerWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_PeerWidget_t qt_meta_stringdata_PeerWidget = {
    {
QT_MOC_LITERAL(0, 0, 10), // "PeerWidget"
QT_MOC_LITERAL(1, 11, 16), // "removeUserSignal"
QT_MOC_LITERAL(2, 28, 0), // ""
QT_MOC_LITERAL(3, 29, 9), // "thisEmail"
QT_MOC_LITERAL(4, 39, 17), // "refreshPeerAvatar"
QT_MOC_LITERAL(5, 57, 5), // "email"
QT_MOC_LITERAL(6, 63, 19), // "moveToGroupUpSignal"
QT_MOC_LITERAL(7, 83, 21), // "moveToGroupDownSignal"
QT_MOC_LITERAL(8, 105, 5), // "hover"
QT_MOC_LITERAL(9, 111, 5), // "value"
QT_MOC_LITERAL(10, 117, 11), // "eventFilter"
QT_MOC_LITERAL(11, 129, 6), // "object"
QT_MOC_LITERAL(12, 136, 7), // "QEvent*"
QT_MOC_LITERAL(13, 144, 5), // "event"
QT_MOC_LITERAL(14, 150, 14), // "set_plain_data"
QT_MOC_LITERAL(15, 165, 15), // "plain_peer_data"
QT_MOC_LITERAL(16, 181, 17), // "customContextMenu"
QT_MOC_LITERAL(17, 199, 13), // "positionPoint"
QT_MOC_LITERAL(18, 213, 10), // "removeUser"
QT_MOC_LITERAL(19, 224, 13), // "moveToGroupUp"
QT_MOC_LITERAL(20, 238, 15) // "moveToGroupDown"

    },
    "PeerWidget\0removeUserSignal\0\0thisEmail\0"
    "refreshPeerAvatar\0email\0moveToGroupUpSignal\0"
    "moveToGroupDownSignal\0hover\0value\0"
    "eventFilter\0object\0QEvent*\0event\0"
    "set_plain_data\0plain_peer_data\0"
    "customContextMenu\0positionPoint\0"
    "removeUser\0moveToGroupUp\0moveToGroupDown"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_PeerWidget[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   69,    2, 0x06 /* Public */,
       4,    1,   72,    2, 0x06 /* Public */,
       6,    1,   75,    2, 0x06 /* Public */,
       7,    1,   78,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       8,    1,   81,    2, 0x0a /* Public */,
      10,    2,   84,    2, 0x0a /* Public */,
      14,    1,   89,    2, 0x0a /* Public */,
      16,    1,   92,    2, 0x0a /* Public */,
      18,    0,   95,    2, 0x0a /* Public */,
      19,    0,   96,    2, 0x0a /* Public */,
      20,    0,   97,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,

 // slots: parameters
    QMetaType::Void, QMetaType::Bool,    9,
    QMetaType::Bool, QMetaType::QObjectStar, 0x80000000 | 12,   11,   13,
    QMetaType::Void, QMetaType::QString,   15,
    QMetaType::Void, QMetaType::QPoint,   17,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void PeerWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<PeerWidget *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->removeUserSignal((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->refreshPeerAvatar((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 2: _t->moveToGroupUpSignal((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->moveToGroupDownSignal((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 4: _t->hover((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 5: { bool _r = _t->eventFilter((*reinterpret_cast< QObject*(*)>(_a[1])),(*reinterpret_cast< QEvent*(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 6: _t->set_plain_data((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 7: _t->customContextMenu((*reinterpret_cast< QPoint(*)>(_a[1]))); break;
        case 8: _t->removeUser(); break;
        case 9: _t->moveToGroupUp(); break;
        case 10: _t->moveToGroupDown(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (PeerWidget::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&PeerWidget::removeUserSignal)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (PeerWidget::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&PeerWidget::refreshPeerAvatar)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (PeerWidget::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&PeerWidget::moveToGroupUpSignal)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (PeerWidget::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&PeerWidget::moveToGroupDownSignal)) {
                *result = 3;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject PeerWidget::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_PeerWidget.data,
    qt_meta_data_PeerWidget,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *PeerWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *PeerWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_PeerWidget.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int PeerWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 11)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 11;
    }
    return _id;
}

// SIGNAL 0
void PeerWidget::removeUserSignal(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void PeerWidget::refreshPeerAvatar(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void PeerWidget::moveToGroupUpSignal(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void PeerWidget::moveToGroupDownSignal(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
