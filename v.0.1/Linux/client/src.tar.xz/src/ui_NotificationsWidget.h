/********************************************************************************
** Form generated from reading UI file 'NotificationsWidget.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NOTIFICATIONSWIDGET_H
#define UI_NOTIFICATIONSWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_NotificationsWidget
{
public:
    QVBoxLayout *verticalLayout;

    void setupUi(QWidget *NotificationsWidget)
    {
        if (NotificationsWidget->objectName().isEmpty())
            NotificationsWidget->setObjectName(QString::fromUtf8("NotificationsWidget"));
        NotificationsWidget->resize(200, 20);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(NotificationsWidget->sizePolicy().hasHeightForWidth());
        NotificationsWidget->setSizePolicy(sizePolicy);
        NotificationsWidget->setMinimumSize(QSize(0, 20));
        NotificationsWidget->setMaximumSize(QSize(200, 1900));
        QFont font;
        font.setPointSize(10);
        NotificationsWidget->setFont(font);
        verticalLayout = new QVBoxLayout(NotificationsWidget);
        verticalLayout->setSpacing(0);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);

        retranslateUi(NotificationsWidget);

        QMetaObject::connectSlotsByName(NotificationsWidget);
    } // setupUi

    void retranslateUi(QWidget *NotificationsWidget)
    {
        NotificationsWidget->setWindowTitle(QCoreApplication::translate("NotificationsWidget", "Notifications", nullptr));
    } // retranslateUi

};

namespace Ui {
    class NotificationsWidget: public Ui_NotificationsWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NOTIFICATIONSWIDGET_H
