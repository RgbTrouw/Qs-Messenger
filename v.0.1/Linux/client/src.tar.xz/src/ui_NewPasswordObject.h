/********************************************************************************
** Form generated from reading UI file 'NewPasswordObject.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NEWPASSWORDOBJECT_H
#define UI_NEWPASSWORDOBJECT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_NewPasswordObject
{
public:
    QGridLayout *gridLayout;
    QPushButton *pushButton;
    QLabel *label;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit_3;
    QSpacerItem *horizontalSpacer;
    QLabel *label_2;

    void setupUi(QWidget *NewPasswordObject)
    {
        if (NewPasswordObject->objectName().isEmpty())
            NewPasswordObject->setObjectName(QString::fromUtf8("NewPasswordObject"));
        NewPasswordObject->resize(407, 170);
        NewPasswordObject->setMinimumSize(QSize(407, 170));
        NewPasswordObject->setMaximumSize(QSize(407, 172));
        gridLayout = new QGridLayout(NewPasswordObject);
        gridLayout->setSpacing(4);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(8, 8, 8, 8);
        pushButton = new QPushButton(NewPasswordObject);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setMinimumSize(QSize(0, 25));
        pushButton->setMaximumSize(QSize(16777215, 25));
        QFont font;
        font.setPointSize(10);
        pushButton->setFont(font);

        gridLayout->addWidget(pushButton, 4, 1, 1, 1);

        label = new QLabel(NewPasswordObject);
        label->setObjectName(QString::fromUtf8("label"));
        label->setMinimumSize(QSize(0, 20));
        label->setMaximumSize(QSize(16777215, 20));
        label->setFont(font);
        label->setStyleSheet(QString::fromUtf8("color:rgb(136, 138, 133)"));

        gridLayout->addWidget(label, 5, 0, 1, 2);

        lineEdit = new QLineEdit(NewPasswordObject);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(25);
        sizePolicy.setHeightForWidth(lineEdit->sizePolicy().hasHeightForWidth());
        lineEdit->setSizePolicy(sizePolicy);
        lineEdit->setMinimumSize(QSize(0, 25));
        lineEdit->setFont(font);

        gridLayout->addWidget(lineEdit, 1, 0, 1, 2);

        lineEdit_2 = new QLineEdit(NewPasswordObject);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        sizePolicy.setHeightForWidth(lineEdit_2->sizePolicy().hasHeightForWidth());
        lineEdit_2->setSizePolicy(sizePolicy);
        lineEdit_2->setMinimumSize(QSize(0, 25));
        lineEdit_2->setFont(font);
        lineEdit_2->setEchoMode(QLineEdit::Password);

        gridLayout->addWidget(lineEdit_2, 2, 0, 1, 2);

        lineEdit_3 = new QLineEdit(NewPasswordObject);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        sizePolicy.setHeightForWidth(lineEdit_3->sizePolicy().hasHeightForWidth());
        lineEdit_3->setSizePolicy(sizePolicy);
        lineEdit_3->setMinimumSize(QSize(0, 25));
        lineEdit_3->setFont(font);
        lineEdit_3->setEchoMode(QLineEdit::Password);

        gridLayout->addWidget(lineEdit_3, 3, 0, 1, 2);

        horizontalSpacer = new QSpacerItem(240, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 4, 0, 1, 1);

        label_2 = new QLabel(NewPasswordObject);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setFont(font);
        label_2->setStyleSheet(QString::fromUtf8("color: rgb(52, 101, 164);"));

        gridLayout->addWidget(label_2, 0, 0, 1, 1);


        retranslateUi(NewPasswordObject);

        QMetaObject::connectSlotsByName(NewPasswordObject);
    } // setupUi

    void retranslateUi(QWidget *NewPasswordObject)
    {
        NewPasswordObject->setWindowTitle(QCoreApplication::translate("NewPasswordObject", "New Password", nullptr));
        pushButton->setText(QCoreApplication::translate("NewPasswordObject", "Reset", nullptr));
        label->setText(QCoreApplication::translate("NewPasswordObject", "...", nullptr));
        lineEdit->setPlaceholderText(QCoreApplication::translate("NewPasswordObject", "Security Code", nullptr));
        lineEdit_2->setPlaceholderText(QCoreApplication::translate("NewPasswordObject", "New Password", nullptr));
        lineEdit_3->setPlaceholderText(QCoreApplication::translate("NewPasswordObject", "Repeat Password", nullptr));
        label_2->setText(QCoreApplication::translate("NewPasswordObject", "Create a new password...", nullptr));
    } // retranslateUi

};

namespace Ui {
    class NewPasswordObject: public Ui_NewPasswordObject {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NEWPASSWORDOBJECT_H
