/********************************************************************************
** Form generated from reading UI file 'ActivateUserAccountObject.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ACTIVATEUSERACCOUNTOBJECT_H
#define UI_ACTIVATEUSERACCOUNTOBJECT_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ActivateUserAccountObject
{
public:
    QGridLayout *gridLayout;
    QLabel *label_2;
    QLineEdit *activation_code_Prompt;
    QPushButton *activate_Button;
    QLabel *message_Label;

    void setupUi(QWidget *ActivateUserAccountObject)
    {
        if (ActivateUserAccountObject->objectName().isEmpty())
            ActivateUserAccountObject->setObjectName(QString::fromUtf8("ActivateUserAccountObject"));
        ActivateUserAccountObject->resize(407, 114);
        ActivateUserAccountObject->setMinimumSize(QSize(407, 110));
        ActivateUserAccountObject->setMaximumSize(QSize(407, 114));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/icons/icons/2221968.png"), QSize(), QIcon::Normal, QIcon::Off);
        ActivateUserAccountObject->setWindowIcon(icon);
        gridLayout = new QGridLayout(ActivateUserAccountObject);
        gridLayout->setSpacing(4);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(8, 8, 8, 8);
        label_2 = new QLabel(ActivateUserAccountObject);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(label_2->sizePolicy().hasHeightForWidth());
        label_2->setSizePolicy(sizePolicy);
        QFont font;
        font.setPointSize(10);
        label_2->setFont(font);
        label_2->setStyleSheet(QString::fromUtf8("color: rgb(52, 101, 164);"));

        gridLayout->addWidget(label_2, 0, 0, 1, 1);

        activation_code_Prompt = new QLineEdit(ActivateUserAccountObject);
        activation_code_Prompt->setObjectName(QString::fromUtf8("activation_code_Prompt"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(20);
        sizePolicy1.setHeightForWidth(activation_code_Prompt->sizePolicy().hasHeightForWidth());
        activation_code_Prompt->setSizePolicy(sizePolicy1);
        activation_code_Prompt->setMinimumSize(QSize(0, 25));
        activation_code_Prompt->setMaximumSize(QSize(16777215, 25));
        activation_code_Prompt->setFont(font);

        gridLayout->addWidget(activation_code_Prompt, 1, 0, 1, 1);

        activate_Button = new QPushButton(ActivateUserAccountObject);
        activate_Button->setObjectName(QString::fromUtf8("activate_Button"));
        activate_Button->setMinimumSize(QSize(0, 25));
        activate_Button->setMaximumSize(QSize(16777215, 25));
        activate_Button->setFont(font);

        gridLayout->addWidget(activate_Button, 2, 0, 1, 1);

        message_Label = new QLabel(ActivateUserAccountObject);
        message_Label->setObjectName(QString::fromUtf8("message_Label"));
        message_Label->setEnabled(false);
        sizePolicy.setHeightForWidth(message_Label->sizePolicy().hasHeightForWidth());
        message_Label->setSizePolicy(sizePolicy);
        message_Label->setMinimumSize(QSize(0, 20));
        message_Label->setMaximumSize(QSize(342, 20));
        message_Label->setFont(font);
        message_Label->setStyleSheet(QString::fromUtf8("color:rgb(136, 138, 133)"));
        message_Label->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        gridLayout->addWidget(message_Label, 3, 0, 1, 1);


        retranslateUi(ActivateUserAccountObject);

        QMetaObject::connectSlotsByName(ActivateUserAccountObject);
    } // setupUi

    void retranslateUi(QWidget *ActivateUserAccountObject)
    {
        ActivateUserAccountObject->setWindowTitle(QCoreApplication::translate("ActivateUserAccountObject", "New User Activation", nullptr));
        label_2->setText(QCoreApplication::translate("ActivateUserAccountObject", "Activate new user account...", nullptr));
        activation_code_Prompt->setText(QString());
        activation_code_Prompt->setPlaceholderText(QCoreApplication::translate("ActivateUserAccountObject", "Activation Code", nullptr));
        activate_Button->setText(QCoreApplication::translate("ActivateUserAccountObject", "Activate", nullptr));
        message_Label->setText(QCoreApplication::translate("ActivateUserAccountObject", "...", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ActivateUserAccountObject: public Ui_ActivateUserAccountObject {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ACTIVATEUSERACCOUNTOBJECT_H
