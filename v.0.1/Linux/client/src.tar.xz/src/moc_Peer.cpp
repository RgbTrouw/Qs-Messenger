/****************************************************************************
** Meta object code from reading C++ file 'Peer.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "Source/Objects/Headers/Peer.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'Peer.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_PeerObject_t {
    QByteArrayData data[8];
    char stringdata0[109];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_PeerObject_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_PeerObject_t qt_meta_stringdata_PeerObject = {
    {
QT_MOC_LITERAL(0, 0, 10), // "PeerObject"
QT_MOC_LITERAL(1, 11, 14), // "set_plain_data"
QT_MOC_LITERAL(2, 26, 0), // ""
QT_MOC_LITERAL(3, 27, 15), // "plain_peer_data"
QT_MOC_LITERAL(4, 43, 19), // "get_item_model_item"
QT_MOC_LITERAL(5, 63, 14), // "QStandardItem*"
QT_MOC_LITERAL(6, 78, 13), // "get_im_window"
QT_MOC_LITERAL(7, 92, 16) // "IM_WindowObject*"

    },
    "PeerObject\0set_plain_data\0\0plain_peer_data\0"
    "get_item_model_item\0QStandardItem*\0"
    "get_im_window\0IM_WindowObject*"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_PeerObject[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,   29,    2, 0x0a /* Public */,
       4,    0,   32,    2, 0x0a /* Public */,
       6,    0,   33,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,    3,
    0x80000000 | 5,
    0x80000000 | 7,

       0        // eod
};

void PeerObject::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<PeerObject *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->set_plain_data((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: { QStandardItem* _r = _t->get_item_model_item();
            if (_a[0]) *reinterpret_cast< QStandardItem**>(_a[0]) = std::move(_r); }  break;
        case 2: { IM_WindowObject* _r = _t->get_im_window();
            if (_a[0]) *reinterpret_cast< IM_WindowObject**>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject PeerObject::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_PeerObject.data,
    qt_meta_data_PeerObject,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *PeerObject::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *PeerObject::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_PeerObject.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int PeerObject::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 3)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 3)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 3;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
