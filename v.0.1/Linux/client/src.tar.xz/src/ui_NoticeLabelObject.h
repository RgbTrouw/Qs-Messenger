/********************************************************************************
** Form generated from reading UI file 'NoticeLabelObject.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NOTICELABELOBJECT_H
#define UI_NOTICELABELOBJECT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_NoticeLabelObject
{
public:
    QFormLayout *formLayout;
    QLabel *img;
    QLabel *label;

    void setupUi(QWidget *NoticeLabelObject)
    {
        if (NoticeLabelObject->objectName().isEmpty())
            NoticeLabelObject->setObjectName(QString::fromUtf8("NoticeLabelObject"));
        NoticeLabelObject->resize(200, 20);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(NoticeLabelObject->sizePolicy().hasHeightForWidth());
        NoticeLabelObject->setSizePolicy(sizePolicy);
        NoticeLabelObject->setMinimumSize(QSize(200, 20));
        NoticeLabelObject->setMaximumSize(QSize(200, 20));
        formLayout = new QFormLayout(NoticeLabelObject);
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        formLayout->setHorizontalSpacing(4);
        formLayout->setVerticalSpacing(0);
        formLayout->setContentsMargins(6, 2, 6, 0);
        img = new QLabel(NoticeLabelObject);
        img->setObjectName(QString::fromUtf8("img"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(img->sizePolicy().hasHeightForWidth());
        img->setSizePolicy(sizePolicy1);
        img->setMinimumSize(QSize(16, 16));
        img->setMaximumSize(QSize(16, 16));
        QFont font;
        font.setPointSize(10);
        img->setFont(font);
        img->setPixmap(QPixmap(QString::fromUtf8("../../../../Resources/icons/smiley.png")));
        img->setScaledContents(true);

        formLayout->setWidget(0, QFormLayout::LabelRole, img);

        label = new QLabel(NoticeLabelObject);
        label->setObjectName(QString::fromUtf8("label"));
        QSizePolicy sizePolicy2(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy2);
        label->setMinimumSize(QSize(100, 18));
        label->setMaximumSize(QSize(16777215, 18));
        label->setFont(font);
        label->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        formLayout->setWidget(0, QFormLayout::FieldRole, label);


        retranslateUi(NoticeLabelObject);

        QMetaObject::connectSlotsByName(NoticeLabelObject);
    } // setupUi

    void retranslateUi(QWidget *NoticeLabelObject)
    {
        NoticeLabelObject->setWindowTitle(QCoreApplication::translate("NoticeLabelObject", "Form", nullptr));
        img->setText(QString());
        label->setText(QCoreApplication::translate("NoticeLabelObject", "went online...", nullptr));
    } // retranslateUi

};

namespace Ui {
    class NoticeLabelObject: public Ui_NoticeLabelObject {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NOTICELABELOBJECT_H
