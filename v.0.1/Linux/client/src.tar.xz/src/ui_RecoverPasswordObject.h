/********************************************************************************
** Form generated from reading UI file 'RecoverPasswordObject.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RECOVERPASSWORDOBJECT_H
#define UI_RECOVERPASSWORDOBJECT_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_RecoverPasswordObject
{
public:
    QVBoxLayout *verticalLayout;
    QStackedWidget *stackedWidget;
    QWidget *page;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_2;
    QHBoxLayout *horizontalLayout;
    QLineEdit *emailPrompt;
    QPushButton *sendButton;
    QPushButton *pageButton;
    QWidget *page_2;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_3;
    QLineEdit *securityCodePrompt;
    QLineEdit *passwordPrompt;
    QLineEdit *passwordConfirmPrompt;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label;
    QPushButton *resetButton;
    QPushButton *pageButton2;
    QLabel *feedbackLabel;

    void setupUi(QWidget *RecoverPasswordObject)
    {
        if (RecoverPasswordObject->objectName().isEmpty())
            RecoverPasswordObject->setObjectName(QString::fromUtf8("RecoverPasswordObject"));
        RecoverPasswordObject->resize(407, 198);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(RecoverPasswordObject->sizePolicy().hasHeightForWidth());
        RecoverPasswordObject->setSizePolicy(sizePolicy);
        RecoverPasswordObject->setMinimumSize(QSize(407, 100));
        RecoverPasswordObject->setMaximumSize(QSize(407, 198));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/icons/icons/178b4356af2fde572124f034b490934c.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        RecoverPasswordObject->setWindowIcon(icon);
        verticalLayout = new QVBoxLayout(RecoverPasswordObject);
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(6, 6, 6, 6);
        stackedWidget = new QStackedWidget(RecoverPasswordObject);
        stackedWidget->setObjectName(QString::fromUtf8("stackedWidget"));
        sizePolicy.setHeightForWidth(stackedWidget->sizePolicy().hasHeightForWidth());
        stackedWidget->setSizePolicy(sizePolicy);
        page = new QWidget();
        page->setObjectName(QString::fromUtf8("page"));
        verticalLayout_2 = new QVBoxLayout(page);
        verticalLayout_2->setSpacing(4);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_2 = new QLabel(page);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(label_2->sizePolicy().hasHeightForWidth());
        label_2->setSizePolicy(sizePolicy1);
        QFont font;
        font.setPointSize(10);
        label_2->setFont(font);
        label_2->setStyleSheet(QString::fromUtf8("color: rgb(52, 101, 164);"));

        horizontalLayout_3->addWidget(label_2);


        verticalLayout_2->addLayout(horizontalLayout_3);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(4);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        emailPrompt = new QLineEdit(page);
        emailPrompt->setObjectName(QString::fromUtf8("emailPrompt"));
        emailPrompt->setMinimumSize(QSize(0, 25));
        emailPrompt->setMaximumSize(QSize(16777215, 25));
        emailPrompt->setFont(font);

        horizontalLayout->addWidget(emailPrompt);

        sendButton = new QPushButton(page);
        sendButton->setObjectName(QString::fromUtf8("sendButton"));
        sendButton->setMinimumSize(QSize(0, 25));
        sendButton->setMaximumSize(QSize(16777215, 25));
        sendButton->setFont(font);
        sendButton->setIconSize(QSize(24, 24));

        horizontalLayout->addWidget(sendButton);

        pageButton = new QPushButton(page);
        pageButton->setObjectName(QString::fromUtf8("pageButton"));
        QSizePolicy sizePolicy2(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(pageButton->sizePolicy().hasHeightForWidth());
        pageButton->setSizePolicy(sizePolicy2);
        pageButton->setMinimumSize(QSize(25, 25));
        pageButton->setMaximumSize(QSize(25, 25));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8("../../../../Resources/icons/triangle_right.png"), QSize(), QIcon::Normal, QIcon::On);
        pageButton->setIcon(icon1);

        horizontalLayout->addWidget(pageButton);


        verticalLayout_2->addLayout(horizontalLayout);

        stackedWidget->addWidget(page);
        page_2 = new QWidget();
        page_2->setObjectName(QString::fromUtf8("page_2"));
        verticalLayout_3 = new QVBoxLayout(page_2);
        verticalLayout_3->setSpacing(4);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        label_3 = new QLabel(page_2);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setFont(font);
        label_3->setStyleSheet(QString::fromUtf8("color: rgb(52, 101, 164);"));

        horizontalLayout_4->addWidget(label_3);


        verticalLayout_3->addLayout(horizontalLayout_4);

        securityCodePrompt = new QLineEdit(page_2);
        securityCodePrompt->setObjectName(QString::fromUtf8("securityCodePrompt"));
        QSizePolicy sizePolicy3(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(25);
        sizePolicy3.setHeightForWidth(securityCodePrompt->sizePolicy().hasHeightForWidth());
        securityCodePrompt->setSizePolicy(sizePolicy3);
        securityCodePrompt->setMinimumSize(QSize(0, 25));
        securityCodePrompt->setFont(font);

        verticalLayout_3->addWidget(securityCodePrompt);

        passwordPrompt = new QLineEdit(page_2);
        passwordPrompt->setObjectName(QString::fromUtf8("passwordPrompt"));
        sizePolicy3.setHeightForWidth(passwordPrompt->sizePolicy().hasHeightForWidth());
        passwordPrompt->setSizePolicy(sizePolicy3);
        passwordPrompt->setMinimumSize(QSize(0, 25));
        passwordPrompt->setFont(font);
        passwordPrompt->setEchoMode(QLineEdit::Password);

        verticalLayout_3->addWidget(passwordPrompt);

        passwordConfirmPrompt = new QLineEdit(page_2);
        passwordConfirmPrompt->setObjectName(QString::fromUtf8("passwordConfirmPrompt"));
        sizePolicy3.setHeightForWidth(passwordConfirmPrompt->sizePolicy().hasHeightForWidth());
        passwordConfirmPrompt->setSizePolicy(sizePolicy3);
        passwordConfirmPrompt->setMinimumSize(QSize(0, 25));
        passwordConfirmPrompt->setFont(font);
        passwordConfirmPrompt->setEchoMode(QLineEdit::Password);

        verticalLayout_3->addWidget(passwordConfirmPrompt);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(4);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label = new QLabel(page_2);
        label->setObjectName(QString::fromUtf8("label"));
        QSizePolicy sizePolicy4(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy4);
        label->setMinimumSize(QSize(0, 23));
        label->setMaximumSize(QSize(16777215, 23));
        label->setFont(font);
        label->setStyleSheet(QString::fromUtf8(""));
        label->setScaledContents(true);

        horizontalLayout_2->addWidget(label);

        resetButton = new QPushButton(page_2);
        resetButton->setObjectName(QString::fromUtf8("resetButton"));
        sizePolicy2.setHeightForWidth(resetButton->sizePolicy().hasHeightForWidth());
        resetButton->setSizePolicy(sizePolicy2);
        resetButton->setMinimumSize(QSize(90, 25));
        resetButton->setMaximumSize(QSize(90, 25));
        resetButton->setFont(font);

        horizontalLayout_2->addWidget(resetButton);

        pageButton2 = new QPushButton(page_2);
        pageButton2->setObjectName(QString::fromUtf8("pageButton2"));
        sizePolicy2.setHeightForWidth(pageButton2->sizePolicy().hasHeightForWidth());
        pageButton2->setSizePolicy(sizePolicy2);
        pageButton2->setMinimumSize(QSize(25, 25));
        pageButton2->setMaximumSize(QSize(25, 25));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8("../../../../Resources/icons/triangle_left.png"), QSize(), QIcon::Normal, QIcon::On);
        pageButton2->setIcon(icon2);

        horizontalLayout_2->addWidget(pageButton2);


        verticalLayout_3->addLayout(horizontalLayout_2);

        stackedWidget->addWidget(page_2);

        verticalLayout->addWidget(stackedWidget);

        feedbackLabel = new QLabel(RecoverPasswordObject);
        feedbackLabel->setObjectName(QString::fromUtf8("feedbackLabel"));
        feedbackLabel->setMinimumSize(QSize(0, 17));
        feedbackLabel->setMaximumSize(QSize(16777215, 17));
        QFont font1;
        font1.setPointSize(9);
        feedbackLabel->setFont(font1);
        feedbackLabel->setStyleSheet(QString::fromUtf8("color: rgb(60, 150, 0);"));

        verticalLayout->addWidget(feedbackLabel);


        retranslateUi(RecoverPasswordObject);

        stackedWidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(RecoverPasswordObject);
    } // setupUi

    void retranslateUi(QWidget *RecoverPasswordObject)
    {
        RecoverPasswordObject->setWindowTitle(QCoreApplication::translate("RecoverPasswordObject", "Recover Password", nullptr));
        label_2->setText(QCoreApplication::translate("RecoverPasswordObject", "Create a password reset code...", nullptr));
        emailPrompt->setPlaceholderText(QCoreApplication::translate("RecoverPasswordObject", "Acount Email", nullptr));
        sendButton->setText(QCoreApplication::translate("RecoverPasswordObject", "Send", nullptr));
#if QT_CONFIG(tooltip)
        pageButton->setToolTip(QCoreApplication::translate("RecoverPasswordObject", "next", nullptr));
#endif // QT_CONFIG(tooltip)
        pageButton->setText(QString());
        label_3->setText(QCoreApplication::translate("RecoverPasswordObject", "Create a new password...", nullptr));
        securityCodePrompt->setPlaceholderText(QCoreApplication::translate("RecoverPasswordObject", "Security Code", nullptr));
        passwordPrompt->setPlaceholderText(QCoreApplication::translate("RecoverPasswordObject", "New Password", nullptr));
        passwordConfirmPrompt->setPlaceholderText(QCoreApplication::translate("RecoverPasswordObject", "Repeat Password", nullptr));
        label->setText(QString());
        resetButton->setText(QCoreApplication::translate("RecoverPasswordObject", "Reset", nullptr));
#if QT_CONFIG(tooltip)
        pageButton2->setToolTip(QCoreApplication::translate("RecoverPasswordObject", "back", nullptr));
#endif // QT_CONFIG(tooltip)
        pageButton2->setText(QString());
        feedbackLabel->setText(QCoreApplication::translate("RecoverPasswordObject", "  ...", nullptr));
    } // retranslateUi

};

namespace Ui {
    class RecoverPasswordObject: public Ui_RecoverPasswordObject {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RECOVERPASSWORDOBJECT_H
