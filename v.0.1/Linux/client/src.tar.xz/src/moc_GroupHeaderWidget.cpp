/****************************************************************************
** Meta object code from reading C++ file 'GroupHeaderWidget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "Source/Windows/FriendsList/Headers/GroupHeaderWidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'GroupHeaderWidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_GroupHeaderWidget_t {
    QByteArrayData data[18];
    char stringdata0[171];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_GroupHeaderWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_GroupHeaderWidget_t qt_meta_stringdata_GroupHeaderWidget = {
    {
QT_MOC_LITERAL(0, 0, 17), // "GroupHeaderWidget"
QT_MOC_LITERAL(1, 18, 18), // "changePeersDisplay"
QT_MOC_LITERAL(2, 37, 0), // ""
QT_MOC_LITERAL(3, 38, 4), // "type"
QT_MOC_LITERAL(4, 43, 7), // "setName"
QT_MOC_LITERAL(5, 51, 4), // "name"
QT_MOC_LITERAL(6, 56, 15), // "setCounterLabel"
QT_MOC_LITERAL(7, 72, 4), // "data"
QT_MOC_LITERAL(8, 77, 5), // "hover"
QT_MOC_LITERAL(9, 83, 5), // "value"
QT_MOC_LITERAL(10, 89, 11), // "eventFilter"
QT_MOC_LITERAL(11, 101, 6), // "object"
QT_MOC_LITERAL(12, 108, 7), // "QEvent*"
QT_MOC_LITERAL(13, 116, 5), // "event"
QT_MOC_LITERAL(14, 122, 17), // "customContextMenu"
QT_MOC_LITERAL(15, 140, 13), // "positionPoint"
QT_MOC_LITERAL(16, 154, 11), // "setIconMode"
QT_MOC_LITERAL(17, 166, 4) // "mode"

    },
    "GroupHeaderWidget\0changePeersDisplay\0"
    "\0type\0setName\0name\0setCounterLabel\0"
    "data\0hover\0value\0eventFilter\0object\0"
    "QEvent*\0event\0customContextMenu\0"
    "positionPoint\0setIconMode\0mode"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_GroupHeaderWidget[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   49,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       4,    1,   52,    2, 0x0a /* Public */,
       6,    1,   55,    2, 0x0a /* Public */,
       8,    1,   58,    2, 0x0a /* Public */,
      10,    2,   61,    2, 0x0a /* Public */,
      14,    1,   66,    2, 0x0a /* Public */,
      16,    1,   69,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::QString,    7,
    QMetaType::Void, QMetaType::Bool,    9,
    QMetaType::Bool, QMetaType::QObjectStar, 0x80000000 | 12,   11,   13,
    QMetaType::Void, QMetaType::QPoint,   15,
    QMetaType::Void, QMetaType::QString,   17,

       0        // eod
};

void GroupHeaderWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<GroupHeaderWidget *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->changePeersDisplay((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->setName((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 2: _t->setCounterLabel((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->hover((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 4: { bool _r = _t->eventFilter((*reinterpret_cast< QObject*(*)>(_a[1])),(*reinterpret_cast< QEvent*(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 5: _t->customContextMenu((*reinterpret_cast< QPoint(*)>(_a[1]))); break;
        case 6: _t->setIconMode((*reinterpret_cast< QString(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (GroupHeaderWidget::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GroupHeaderWidget::changePeersDisplay)) {
                *result = 0;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject GroupHeaderWidget::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_GroupHeaderWidget.data,
    qt_meta_data_GroupHeaderWidget,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *GroupHeaderWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *GroupHeaderWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_GroupHeaderWidget.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int GroupHeaderWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 7)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 7;
    }
    return _id;
}

// SIGNAL 0
void GroupHeaderWidget::changePeersDisplay(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
