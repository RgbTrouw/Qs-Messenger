/****************************************************************************
** Meta object code from reading C++ file 'IM_WindowObject.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "Source/Windows/IMWindows/Headers/IM_WindowObject.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'IM_WindowObject.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_IM_WindowObject_t {
    QByteArrayData data[30];
    char stringdata0[323];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_IM_WindowObject_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_IM_WindowObject_t qt_meta_stringdata_IM_WindowObject = {
    {
QT_MOC_LITERAL(0, 0, 15), // "IM_WindowObject"
QT_MOC_LITERAL(1, 16, 12), // "send_message"
QT_MOC_LITERAL(2, 29, 0), // ""
QT_MOC_LITERAL(3, 30, 4), // "peer"
QT_MOC_LITERAL(4, 35, 7), // "message"
QT_MOC_LITERAL(5, 43, 17), // "get_prev_messages"
QT_MOC_LITERAL(6, 61, 5), // "index"
QT_MOC_LITERAL(7, 67, 9), // "have_read"
QT_MOC_LITERAL(8, 77, 6), // "deelay"
QT_MOC_LITERAL(9, 84, 11), // "setMyAvatar"
QT_MOC_LITERAL(10, 96, 13), // "setPeerAvatar"
QT_MOC_LITERAL(11, 110, 14), // "append_message"
QT_MOC_LITERAL(12, 125, 4), // "time"
QT_MOC_LITERAL(13, 130, 15), // "prepend_message"
QT_MOC_LITERAL(14, 146, 7), // "msgFrom"
QT_MOC_LITERAL(15, 154, 5), // "msgTo"
QT_MOC_LITERAL(16, 160, 10), // "closeEvent"
QT_MOC_LITERAL(17, 171, 12), // "QCloseEvent*"
QT_MOC_LITERAL(18, 184, 5), // "event"
QT_MOC_LITERAL(19, 190, 14), // "showHideNotice"
QT_MOC_LITERAL(20, 205, 5), // "value"
QT_MOC_LITERAL(21, 211, 7), // "sendMsg"
QT_MOC_LITERAL(22, 219, 8), // "sendBuzz"
QT_MOC_LITERAL(23, 228, 20), // "loadPreviousMessages"
QT_MOC_LITERAL(24, 249, 11), // "showSmileys"
QT_MOC_LITERAL(25, 261, 12), // "appendSmiley"
QT_MOC_LITERAL(26, 274, 10), // "characters"
QT_MOC_LITERAL(27, 285, 11), // "resizeEvent"
QT_MOC_LITERAL(28, 297, 13), // "QResizeEvent*"
QT_MOC_LITERAL(29, 311, 11) // "playSmileys"

    },
    "IM_WindowObject\0send_message\0\0peer\0"
    "message\0get_prev_messages\0index\0"
    "have_read\0deelay\0setMyAvatar\0setPeerAvatar\0"
    "append_message\0time\0prepend_message\0"
    "msgFrom\0msgTo\0closeEvent\0QCloseEvent*\0"
    "event\0showHideNotice\0value\0sendMsg\0"
    "sendBuzz\0loadPreviousMessages\0showSmileys\0"
    "appendSmiley\0characters\0resizeEvent\0"
    "QResizeEvent*\0playSmileys"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_IM_WindowObject[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      17,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    2,   99,    2, 0x06 /* Public */,
       5,    2,  104,    2, 0x06 /* Public */,
       7,    1,  109,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       8,    0,  112,    2, 0x0a /* Public */,
       9,    0,  113,    2, 0x0a /* Public */,
      10,    0,  114,    2, 0x0a /* Public */,
      11,    2,  115,    2, 0x0a /* Public */,
      13,    4,  120,    2, 0x0a /* Public */,
      16,    1,  129,    2, 0x0a /* Public */,
      19,    1,  132,    2, 0x0a /* Public */,
      21,    0,  135,    2, 0x08 /* Private */,
      22,    0,  136,    2, 0x08 /* Private */,
      23,    0,  137,    2, 0x08 /* Private */,
      24,    0,  138,    2, 0x08 /* Private */,
      25,    1,  139,    2, 0x08 /* Private */,
      27,    1,  142,    2, 0x08 /* Private */,
      29,    0,  145,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    3,    4,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    3,    6,
    QMetaType::Void, QMetaType::QString,    3,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    4,   12,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString,   14,   15,    4,   12,
    QMetaType::Void, 0x80000000 | 17,   18,
    QMetaType::Void, QMetaType::Bool,   20,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   26,
    QMetaType::Void, 0x80000000 | 28,   18,
    QMetaType::Void,

       0        // eod
};

void IM_WindowObject::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<IM_WindowObject *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->send_message((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 1: _t->get_prev_messages((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 2: _t->have_read((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->deelay(); break;
        case 4: _t->setMyAvatar(); break;
        case 5: _t->setPeerAvatar(); break;
        case 6: _t->append_message((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 7: _t->prepend_message((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4]))); break;
        case 8: _t->closeEvent((*reinterpret_cast< QCloseEvent*(*)>(_a[1]))); break;
        case 9: _t->showHideNotice((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 10: _t->sendMsg(); break;
        case 11: _t->sendBuzz(); break;
        case 12: _t->loadPreviousMessages(); break;
        case 13: _t->showSmileys(); break;
        case 14: _t->appendSmiley((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 15: _t->resizeEvent((*reinterpret_cast< QResizeEvent*(*)>(_a[1]))); break;
        case 16: _t->playSmileys(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (IM_WindowObject::*)(QString , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&IM_WindowObject::send_message)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (IM_WindowObject::*)(QString , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&IM_WindowObject::get_prev_messages)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (IM_WindowObject::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&IM_WindowObject::have_read)) {
                *result = 2;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject IM_WindowObject::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_IM_WindowObject.data,
    qt_meta_data_IM_WindowObject,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *IM_WindowObject::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *IM_WindowObject::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_IM_WindowObject.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int IM_WindowObject::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 17)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 17;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 17)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 17;
    }
    return _id;
}

// SIGNAL 0
void IM_WindowObject::send_message(QString _t1, QString _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void IM_WindowObject::get_prev_messages(QString _t1, QString _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void IM_WindowObject::have_read(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
