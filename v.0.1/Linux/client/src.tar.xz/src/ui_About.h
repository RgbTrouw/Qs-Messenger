/********************************************************************************
** Form generated from reading UI file 'About.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ABOUT_H
#define UI_ABOUT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_About
{
public:
    QVBoxLayout *verticalLayout;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout_2;
    QLabel *appName;
    QSpacerItem *verticalSpacer_3;
    QLabel *appVersion;
    QSpacerItem *verticalSpacer_2;
    QFrame *lineSeparator;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer_2;
    QLabel *yearLabel;
    QSpacerItem *horizontalSpacer;
    QLabel *developerLabel;
    QSpacerItem *horizontalSpacer_3;

    void setupUi(QWidget *About)
    {
        if (About->objectName().isEmpty())
            About->setObjectName(QString::fromUtf8("About"));
        About->resize(260, 100);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(About->sizePolicy().hasHeightForWidth());
        About->setSizePolicy(sizePolicy);
        About->setMinimumSize(QSize(260, 100));
        About->setMaximumSize(QSize(260, 100));
        QFont font;
        font.setPointSize(10);
        About->setFont(font);
        verticalLayout = new QVBoxLayout(About);
        verticalLayout->setSpacing(2);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(2, 2, 2, 2);
        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(4);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(-1, 0, -1, -1);
        appName = new QLabel(About);
        appName->setObjectName(QString::fromUtf8("appName"));
        QFont font1;
        font1.setPointSize(14);
        appName->setFont(font1);
        appName->setStyleSheet(QString::fromUtf8("color: rgb(52, 101, 164)"));
        appName->setAlignment(Qt::AlignCenter);

        horizontalLayout_2->addWidget(appName);


        verticalLayout->addLayout(horizontalLayout_2);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_3);

        appVersion = new QLabel(About);
        appVersion->setObjectName(QString::fromUtf8("appVersion"));
        appVersion->setFont(font);
        appVersion->setStyleSheet(QString::fromUtf8("color: rgb(46, 52, 54)"));
        appVersion->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(appVersion);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_2);

        lineSeparator = new QFrame(About);
        lineSeparator->setObjectName(QString::fromUtf8("lineSeparator"));
        lineSeparator->setFrameShape(QFrame::HLine);
        lineSeparator->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(lineSeparator);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(4);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(-1, 0, -1, -1);
        horizontalSpacer_2 = new QSpacerItem(10, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_2);

        yearLabel = new QLabel(About);
        yearLabel->setObjectName(QString::fromUtf8("yearLabel"));
        yearLabel->setFont(font);
        yearLabel->setStyleSheet(QString::fromUtf8("color: rgb(46, 52, 54);"));
        yearLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout->addWidget(yearLabel);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        developerLabel = new QLabel(About);
        developerLabel->setObjectName(QString::fromUtf8("developerLabel"));
        developerLabel->setFont(font);
        developerLabel->setStyleSheet(QString::fromUtf8("color: rgb(115, 210, 22);"));
        developerLabel->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        horizontalLayout->addWidget(developerLabel);

        horizontalSpacer_3 = new QSpacerItem(10, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_3);


        verticalLayout->addLayout(horizontalLayout);


        retranslateUi(About);

        QMetaObject::connectSlotsByName(About);
    } // setupUi

    void retranslateUi(QWidget *About)
    {
        About->setWindowTitle(QCoreApplication::translate("About", "About", nullptr));
        appName->setText(QCoreApplication::translate("About", "Qs Messenger", nullptr));
        appVersion->setText(QCoreApplication::translate("About", "v 0.0.1", nullptr));
        yearLabel->setText(QCoreApplication::translate("About", "\302\251 2023 - 2025 ", nullptr));
        developerLabel->setText(QCoreApplication::translate("About", "Rgb.Trust@gmail.com", nullptr));
    } // retranslateUi

};

namespace Ui {
    class About: public Ui_About {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ABOUT_H
