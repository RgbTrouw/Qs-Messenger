/********************************************************************************
** Form generated from reading UI file 'IM_WindowObject.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_IM_WINDOWOBJECT_H
#define UI_IM_WINDOWOBJECT_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_IM_WindowObject
{
public:
    QAction *actionLoad_Previous_Messages;
    QVBoxLayout *verticalLayout_3;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *notificationLayout;
    QSpacerItem *notificationSpacer;
    QLabel *offlineIcon;
    QLabel *noticeLabel;
    QHBoxLayout *horizontalLayout;
    QTextEdit *conversationTextBox;
    QSpacerItem *horizontalSpacer_4;
    QVBoxLayout *verticalLayout_2;
    QLabel *peerAvatar;
    QSpacerItem *verticalSpacer;
    QLabel *myAvatar;
    QHBoxLayout *horizontalLayout_4;
    QPushButton *smileysButton;
    QPushButton *imagesButton;
    QPushButton *sendFileButton;
    QPushButton *webcamButton;
    QPushButton *buzzButton;
    QSpacerItem *horizontalSpacer_2;
    QHBoxLayout *horizontalLayout_2;
    QTextEdit *sendMessageBox;
    QSpacerItem *horizontalSpacer_5;
    QPushButton *sendMsgButton;
    QLabel *notification_label;

    void setupUi(QWidget *IM_WindowObject)
    {
        if (IM_WindowObject->objectName().isEmpty())
            IM_WindowObject->setObjectName(QString::fromUtf8("IM_WindowObject"));
        IM_WindowObject->resize(788, 505);
        IM_WindowObject->setMinimumSize(QSize(407, 0));
        actionLoad_Previous_Messages = new QAction(IM_WindowObject);
        actionLoad_Previous_Messages->setObjectName(QString::fromUtf8("actionLoad_Previous_Messages"));
        verticalLayout_3 = new QVBoxLayout(IM_WindowObject);
        verticalLayout_3->setSpacing(0);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(-1, 2, -1, 4);
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(4);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(-1, -1, -1, 0);
        notificationLayout = new QHBoxLayout();
        notificationLayout->setSpacing(0);
        notificationLayout->setObjectName(QString::fromUtf8("notificationLayout"));
        notificationLayout->setContentsMargins(-1, 0, -1, -1);
        notificationSpacer = new QSpacerItem(4, 2, QSizePolicy::Fixed, QSizePolicy::Minimum);

        notificationLayout->addItem(notificationSpacer);

        offlineIcon = new QLabel(IM_WindowObject);
        offlineIcon->setObjectName(QString::fromUtf8("offlineIcon"));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(offlineIcon->sizePolicy().hasHeightForWidth());
        offlineIcon->setSizePolicy(sizePolicy);
        offlineIcon->setMinimumSize(QSize(16, 16));
        offlineIcon->setMaximumSize(QSize(16, 16));
        offlineIcon->setScaledContents(true);

        notificationLayout->addWidget(offlineIcon);

        noticeLabel = new QLabel(IM_WindowObject);
        noticeLabel->setObjectName(QString::fromUtf8("noticeLabel"));
        noticeLabel->setMinimumSize(QSize(0, 24));
        noticeLabel->setMaximumSize(QSize(16777215, 24));
        QFont font;
        font.setPointSize(10);
        font.setItalic(false);
        noticeLabel->setFont(font);
        noticeLabel->setStyleSheet(QString::fromUtf8("color:rgb(52, 101, 164)"));
        noticeLabel->setScaledContents(true);

        notificationLayout->addWidget(noticeLabel);


        verticalLayout->addLayout(notificationLayout);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(-1, -1, -1, 0);
        conversationTextBox = new QTextEdit(IM_WindowObject);
        conversationTextBox->setObjectName(QString::fromUtf8("conversationTextBox"));
        conversationTextBox->setEnabled(true);
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(conversationTextBox->sizePolicy().hasHeightForWidth());
        conversationTextBox->setSizePolicy(sizePolicy1);
        conversationTextBox->setMinimumSize(QSize(0, 24));
        conversationTextBox->setMaximumSize(QSize(16777215, 16777215));
        QFont font1;
        font1.setPointSize(10);
        conversationTextBox->setFont(font1);
        conversationTextBox->setStyleSheet(QString::fromUtf8(""));
        conversationTextBox->setOverwriteMode(false);
        conversationTextBox->setTextInteractionFlags(Qt::LinksAccessibleByMouse|Qt::TextSelectableByMouse);

        horizontalLayout->addWidget(conversationTextBox);

        horizontalSpacer_4 = new QSpacerItem(4, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_4);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, -1, -1, 0);
        peerAvatar = new QLabel(IM_WindowObject);
        peerAvatar->setObjectName(QString::fromUtf8("peerAvatar"));
        sizePolicy.setHeightForWidth(peerAvatar->sizePolicy().hasHeightForWidth());
        peerAvatar->setSizePolicy(sizePolicy);
        peerAvatar->setMinimumSize(QSize(80, 80));
        peerAvatar->setMaximumSize(QSize(80, 80));
        QFont font2;
        font2.setPointSize(19);
        peerAvatar->setFont(font2);
        peerAvatar->setPixmap(QPixmap(QString::fromUtf8(":/icons/icons/avatar.png")));
        peerAvatar->setScaledContents(true);

        verticalLayout_2->addWidget(peerAvatar);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer);

        myAvatar = new QLabel(IM_WindowObject);
        myAvatar->setObjectName(QString::fromUtf8("myAvatar"));
        sizePolicy.setHeightForWidth(myAvatar->sizePolicy().hasHeightForWidth());
        myAvatar->setSizePolicy(sizePolicy);
        myAvatar->setMinimumSize(QSize(80, 80));
        myAvatar->setMaximumSize(QSize(80, 80));
        myAvatar->setPixmap(QPixmap(QString::fromUtf8(":/icons/icons/avatar.png")));
        myAvatar->setScaledContents(true);

        verticalLayout_2->addWidget(myAvatar);


        horizontalLayout->addLayout(verticalLayout_2);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(-1, -1, -1, 0);
        smileysButton = new QPushButton(IM_WindowObject);
        smileysButton->setObjectName(QString::fromUtf8("smileysButton"));
        smileysButton->setMinimumSize(QSize(0, 24));
        smileysButton->setMaximumSize(QSize(28, 24));
        smileysButton->setFont(font1);
        QIcon icon;
        icon.addFile(QString::fromUtf8("../../../../Resources/icons/smiley.png"), QSize(), QIcon::Normal, QIcon::On);
        smileysButton->setIcon(icon);
        smileysButton->setIconSize(QSize(15, 15));

        horizontalLayout_4->addWidget(smileysButton);

        imagesButton = new QPushButton(IM_WindowObject);
        imagesButton->setObjectName(QString::fromUtf8("imagesButton"));
        sizePolicy.setHeightForWidth(imagesButton->sizePolicy().hasHeightForWidth());
        imagesButton->setSizePolicy(sizePolicy);
        imagesButton->setMinimumSize(QSize(34, 24));
        imagesButton->setMaximumSize(QSize(34, 24));
        imagesButton->setFont(font1);
        imagesButton->setIconSize(QSize(17, 17));

        horizontalLayout_4->addWidget(imagesButton);

        sendFileButton = new QPushButton(IM_WindowObject);
        sendFileButton->setObjectName(QString::fromUtf8("sendFileButton"));
        sizePolicy.setHeightForWidth(sendFileButton->sizePolicy().hasHeightForWidth());
        sendFileButton->setSizePolicy(sizePolicy);
        sendFileButton->setMinimumSize(QSize(34, 24));
        sendFileButton->setMaximumSize(QSize(34, 24));
        sendFileButton->setFont(font1);
        QIcon icon1;
        icon1.addFile(QString::fromUtf8("../../../../Resources/icons/paperclip.png"), QSize(), QIcon::Normal, QIcon::On);
        sendFileButton->setIcon(icon1);
        sendFileButton->setIconSize(QSize(14, 14));

        horizontalLayout_4->addWidget(sendFileButton);

        webcamButton = new QPushButton(IM_WindowObject);
        webcamButton->setObjectName(QString::fromUtf8("webcamButton"));
        webcamButton->setMinimumSize(QSize(34, 24));
        webcamButton->setMaximumSize(QSize(34, 24));
        webcamButton->setFont(font1);
        webcamButton->setIconSize(QSize(15, 15));

        horizontalLayout_4->addWidget(webcamButton);

        buzzButton = new QPushButton(IM_WindowObject);
        buzzButton->setObjectName(QString::fromUtf8("buzzButton"));
        buzzButton->setMinimumSize(QSize(74, 24));
        buzzButton->setMaximumSize(QSize(74, 24));
        buzzButton->setFont(font1);
        QIcon icon2;
        icon2.addFile(QString::fromUtf8("../../../../Resources/icons/buzz.png"), QSize(), QIcon::Normal, QIcon::On);
        buzzButton->setIcon(icon2);
        buzzButton->setIconSize(QSize(16, 16));

        horizontalLayout_4->addWidget(buzzButton);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_2);


        verticalLayout->addLayout(horizontalLayout_4);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(-1, -1, -1, 0);
        sendMessageBox = new QTextEdit(IM_WindowObject);
        sendMessageBox->setObjectName(QString::fromUtf8("sendMessageBox"));
        sendMessageBox->setMaximumSize(QSize(1900, 70));
        sendMessageBox->setFont(font1);

        horizontalLayout_2->addWidget(sendMessageBox);

        horizontalSpacer_5 = new QSpacerItem(4, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_5);

        sendMsgButton = new QPushButton(IM_WindowObject);
        sendMsgButton->setObjectName(QString::fromUtf8("sendMsgButton"));
        sendMsgButton->setMaximumSize(QSize(80, 70));
        sendMsgButton->setFont(font1);
        sendMsgButton->setStyleSheet(QString::fromUtf8("color:rgb(85, 87, 83)"));

        horizontalLayout_2->addWidget(sendMsgButton);


        verticalLayout->addLayout(horizontalLayout_2);


        verticalLayout_3->addLayout(verticalLayout);

        notification_label = new QLabel(IM_WindowObject);
        notification_label->setObjectName(QString::fromUtf8("notification_label"));
        notification_label->setMinimumSize(QSize(0, 20));
        notification_label->setMaximumSize(QSize(16777215, 20));
        notification_label->setFont(font1);
        notification_label->setStyleSheet(QString::fromUtf8("color:rgb(136, 138, 133)"));

        verticalLayout_3->addWidget(notification_label);


        retranslateUi(IM_WindowObject);

        QMetaObject::connectSlotsByName(IM_WindowObject);
    } // setupUi

    void retranslateUi(QWidget *IM_WindowObject)
    {
        IM_WindowObject->setWindowTitle(QCoreApplication::translate("IM_WindowObject", "im window", nullptr));
        actionLoad_Previous_Messages->setText(QCoreApplication::translate("IM_WindowObject", "Load Previous Messages", nullptr));
        offlineIcon->setText(QString());
        noticeLabel->setText(QCoreApplication::translate("IM_WindowObject", " You appear offline to this contact... !", nullptr));
        conversationTextBox->setHtml(QCoreApplication::translate("IM_WindowObject", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:x-large; font-weight:600;\"><br /></p></body></html>", nullptr));
        peerAvatar->setText(QString());
        myAvatar->setText(QString());
#if QT_CONFIG(tooltip)
        smileysButton->setToolTip(QCoreApplication::translate("IM_WindowObject", "smileys", nullptr));
#endif // QT_CONFIG(tooltip)
        smileysButton->setText(QString());
#if QT_CONFIG(tooltip)
        imagesButton->setToolTip(QCoreApplication::translate("IM_WindowObject", "send image", nullptr));
#endif // QT_CONFIG(tooltip)
        imagesButton->setText(QString());
#if QT_CONFIG(tooltip)
        sendFileButton->setToolTip(QCoreApplication::translate("IM_WindowObject", "send file", nullptr));
#endif // QT_CONFIG(tooltip)
        sendFileButton->setText(QString());
#if QT_CONFIG(tooltip)
        webcamButton->setToolTip(QCoreApplication::translate("IM_WindowObject", "webcam", nullptr));
#endif // QT_CONFIG(tooltip)
        webcamButton->setText(QString());
#if QT_CONFIG(tooltip)
        buzzButton->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        buzzButton->setText(QCoreApplication::translate("IM_WindowObject", "BUZZ", nullptr));
        sendMessageBox->setHtml(QCoreApplication::translate("IM_WindowObject", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>", nullptr));
        sendMsgButton->setText(QCoreApplication::translate("IM_WindowObject", "send", nullptr));
        notification_label->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class IM_WindowObject: public Ui_IM_WindowObject {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_IM_WINDOWOBJECT_H
