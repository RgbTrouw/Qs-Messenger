/********************************************************************************
** Form generated from reading UI file 'HostAddress.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HOSTADDRESS_H
#define UI_HOSTADDRESS_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_HostAddress
{
public:
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QHBoxLayout *horizontalLayout;
    QLineEdit *lineEdit;
    QPushButton *saveButton;

    void setupUi(QWidget *HostAddress)
    {
        if (HostAddress->objectName().isEmpty())
            HostAddress->setObjectName(QString::fromUtf8("HostAddress"));
        HostAddress->resize(407, 68);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(HostAddress->sizePolicy().hasHeightForWidth());
        HostAddress->setSizePolicy(sizePolicy);
        HostAddress->setMinimumSize(QSize(407, 68));
        HostAddress->setMaximumSize(QSize(407, 68));
        verticalLayout = new QVBoxLayout(HostAddress);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label = new QLabel(HostAddress);
        label->setObjectName(QString::fromUtf8("label"));
        QFont font;
        font.setPointSize(10);
        label->setFont(font);
        label->setStyleSheet(QString::fromUtf8("color: rgb(52, 101, 164);"));

        verticalLayout->addWidget(label);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(4);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        lineEdit = new QLineEdit(HostAddress);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setFont(font);

        horizontalLayout->addWidget(lineEdit);

        saveButton = new QPushButton(HostAddress);
        saveButton->setObjectName(QString::fromUtf8("saveButton"));
        saveButton->setFont(font);
        QIcon icon;
        icon.addFile(QString::fromUtf8("../../../../Resources/icons/server.png"), QSize(), QIcon::Normal, QIcon::On);
        saveButton->setIcon(icon);
        saveButton->setIconSize(QSize(12, 12));

        horizontalLayout->addWidget(saveButton);


        verticalLayout->addLayout(horizontalLayout);


        retranslateUi(HostAddress);

        QMetaObject::connectSlotsByName(HostAddress);
    } // setupUi

    void retranslateUi(QWidget *HostAddress)
    {
        HostAddress->setWindowTitle(QCoreApplication::translate("HostAddress", "Server Address", nullptr));
        label->setText(QCoreApplication::translate("HostAddress", "Set host address and port...", nullptr));
        lineEdit->setPlaceholderText(QCoreApplication::translate("HostAddress", "hostname:port", nullptr));
        saveButton->setText(QCoreApplication::translate("HostAddress", "Connect", nullptr));
    } // retranslateUi

};

namespace Ui {
    class HostAddress: public Ui_HostAddress {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HOSTADDRESS_H
