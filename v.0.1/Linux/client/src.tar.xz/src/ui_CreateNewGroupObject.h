/********************************************************************************
** Form generated from reading UI file 'CreateNewGroupObject.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CREATENEWGROUPOBJECT_H
#define UI_CREATENEWGROUPOBJECT_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_CreateNewGroupObject
{
public:
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QHBoxLayout *horizontalLayout;
    QLineEdit *groupNameText;
    QPushButton *addButton;
    QLabel *serverMessage;

    void setupUi(QWidget *CreateNewGroupObject)
    {
        if (CreateNewGroupObject->objectName().isEmpty())
            CreateNewGroupObject->setObjectName(QString::fromUtf8("CreateNewGroupObject"));
        CreateNewGroupObject->resize(380, 81);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(CreateNewGroupObject->sizePolicy().hasHeightForWidth());
        CreateNewGroupObject->setSizePolicy(sizePolicy);
        CreateNewGroupObject->setMinimumSize(QSize(380, 81));
        CreateNewGroupObject->setMaximumSize(QSize(380, 81));
        QFont font;
        font.setPointSize(10);
        CreateNewGroupObject->setFont(font);
        verticalLayout = new QVBoxLayout(CreateNewGroupObject);
        verticalLayout->setSpacing(4);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(4, 4, 4, 4);
        label = new QLabel(CreateNewGroupObject);
        label->setObjectName(QString::fromUtf8("label"));
        label->setFont(font);
        label->setStyleSheet(QString::fromUtf8("color: rgb(32, 74, 135);"));

        verticalLayout->addWidget(label);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        groupNameText = new QLineEdit(CreateNewGroupObject);
        groupNameText->setObjectName(QString::fromUtf8("groupNameText"));
        groupNameText->setMinimumSize(QSize(0, 25));
        groupNameText->setMaximumSize(QSize(16777215, 25));

        horizontalLayout->addWidget(groupNameText);

        addButton = new QPushButton(CreateNewGroupObject);
        addButton->setObjectName(QString::fromUtf8("addButton"));
        addButton->setMinimumSize(QSize(80, 25));
        addButton->setMaximumSize(QSize(80, 25));
        QIcon icon;
        icon.addFile(QString::fromUtf8("../../../../../build-Qs Messenger Client-Desktop-Debug/Resources/icons/addGroup.png"), QSize(), QIcon::Normal, QIcon::On);
        addButton->setIcon(icon);

        horizontalLayout->addWidget(addButton);


        verticalLayout->addLayout(horizontalLayout);

        serverMessage = new QLabel(CreateNewGroupObject);
        serverMessage->setObjectName(QString::fromUtf8("serverMessage"));
        QFont font1;
        font1.setPointSize(9);
        serverMessage->setFont(font1);
        serverMessage->setStyleSheet(QString::fromUtf8("color: rgb(60, 150, 0);"));

        verticalLayout->addWidget(serverMessage);


        retranslateUi(CreateNewGroupObject);

        QMetaObject::connectSlotsByName(CreateNewGroupObject);
    } // setupUi

    void retranslateUi(QWidget *CreateNewGroupObject)
    {
        CreateNewGroupObject->setWindowTitle(QCoreApplication::translate("CreateNewGroupObject", "Create New Group", nullptr));
        label->setText(QCoreApplication::translate("CreateNewGroupObject", "Please insert new group name...", nullptr));
        groupNameText->setPlaceholderText(QCoreApplication::translate("CreateNewGroupObject", "Group Name: 3 to 16 characters, no spaces", nullptr));
        addButton->setText(QCoreApplication::translate("CreateNewGroupObject", "Add", nullptr));
        serverMessage->setText(QCoreApplication::translate("CreateNewGroupObject", "...", nullptr));
    } // retranslateUi

};

namespace Ui {
    class CreateNewGroupObject: public Ui_CreateNewGroupObject {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CREATENEWGROUPOBJECT_H
