/****************************************************************************
** Meta object code from reading C++ file 'GroupWidget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "Source/Windows/FriendsList/Headers/GroupWidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'GroupWidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_GroupWidget_t {
    QByteArrayData data[26];
    char stringdata0[310];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_GroupWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_GroupWidget_t qt_meta_stringdata_GroupWidget = {
    {
QT_MOC_LITERAL(0, 0, 11), // "GroupWidget"
QT_MOC_LITERAL(1, 12, 16), // "addToGroupSignal"
QT_MOC_LITERAL(2, 29, 0), // ""
QT_MOC_LITERAL(3, 30, 9), // "groupName"
QT_MOC_LITERAL(4, 40, 17), // "addNewGroupSignal"
QT_MOC_LITERAL(5, 58, 17), // "removeGroupSignal"
QT_MOC_LITERAL(6, 76, 14), // "set_group_name"
QT_MOC_LITERAL(7, 91, 4), // "name"
QT_MOC_LITERAL(8, 96, 14), // "set_plain_data"
QT_MOC_LITERAL(9, 111, 4), // "data"
QT_MOC_LITERAL(10, 116, 17), // "clearPeersDisplay"
QT_MOC_LITERAL(11, 134, 18), // "changePeersDisplay"
QT_MOC_LITERAL(12, 153, 11), // "currentType"
QT_MOC_LITERAL(13, 165, 17), // "updateUsersOnline"
QT_MOC_LITERAL(14, 183, 14), // "get_group_name"
QT_MOC_LITERAL(15, 198, 16), // "usersOnlineCount"
QT_MOC_LITERAL(16, 215, 10), // "addNewUser"
QT_MOC_LITERAL(17, 226, 11), // "addNewGroup"
QT_MOC_LITERAL(18, 238, 11), // "removeGroup"
QT_MOC_LITERAL(19, 250, 14), // "appendLastPeer"
QT_MOC_LITERAL(20, 265, 5), // "hover"
QT_MOC_LITERAL(21, 271, 5), // "value"
QT_MOC_LITERAL(22, 277, 11), // "eventFilter"
QT_MOC_LITERAL(23, 289, 6), // "object"
QT_MOC_LITERAL(24, 296, 7), // "QEvent*"
QT_MOC_LITERAL(25, 304, 5) // "event"

    },
    "GroupWidget\0addToGroupSignal\0\0groupName\0"
    "addNewGroupSignal\0removeGroupSignal\0"
    "set_group_name\0name\0set_plain_data\0"
    "data\0clearPeersDisplay\0changePeersDisplay\0"
    "currentType\0updateUsersOnline\0"
    "get_group_name\0usersOnlineCount\0"
    "addNewUser\0addNewGroup\0removeGroup\0"
    "appendLastPeer\0hover\0value\0eventFilter\0"
    "object\0QEvent*\0event"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_GroupWidget[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      16,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   94,    2, 0x06 /* Public */,
       4,    0,   97,    2, 0x06 /* Public */,
       5,    1,   98,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       6,    1,  101,    2, 0x0a /* Public */,
       8,    1,  104,    2, 0x0a /* Public */,
      10,    0,  107,    2, 0x0a /* Public */,
      11,    1,  108,    2, 0x0a /* Public */,
      13,    0,  111,    2, 0x0a /* Public */,
      14,    0,  112,    2, 0x0a /* Public */,
      15,    0,  113,    2, 0x0a /* Public */,
      16,    0,  114,    2, 0x0a /* Public */,
      17,    0,  115,    2, 0x0a /* Public */,
      18,    0,  116,    2, 0x0a /* Public */,
      19,    0,  117,    2, 0x0a /* Public */,
      20,    1,  118,    2, 0x0a /* Public */,
      22,    2,  121,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    3,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,    7,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   12,
    QMetaType::Void,
    QMetaType::QString,
    QMetaType::Int,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   21,
    QMetaType::Bool, QMetaType::QObjectStar, 0x80000000 | 24,   23,   25,

       0        // eod
};

void GroupWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<GroupWidget *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->addToGroupSignal((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->addNewGroupSignal(); break;
        case 2: _t->removeGroupSignal((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->set_group_name((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 4: _t->set_plain_data((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 5: _t->clearPeersDisplay(); break;
        case 6: _t->changePeersDisplay((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 7: _t->updateUsersOnline(); break;
        case 8: { QString _r = _t->get_group_name();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 9: { int _r = _t->usersOnlineCount();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 10: _t->addNewUser(); break;
        case 11: _t->addNewGroup(); break;
        case 12: _t->removeGroup(); break;
        case 13: _t->appendLastPeer(); break;
        case 14: _t->hover((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 15: { bool _r = _t->eventFilter((*reinterpret_cast< QObject*(*)>(_a[1])),(*reinterpret_cast< QEvent*(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (GroupWidget::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GroupWidget::addToGroupSignal)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (GroupWidget::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GroupWidget::addNewGroupSignal)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (GroupWidget::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GroupWidget::removeGroupSignal)) {
                *result = 2;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject GroupWidget::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_GroupWidget.data,
    qt_meta_data_GroupWidget,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *GroupWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *GroupWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_GroupWidget.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int GroupWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 16)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 16)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 16;
    }
    return _id;
}

// SIGNAL 0
void GroupWidget::addToGroupSignal(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void GroupWidget::addNewGroupSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void GroupWidget::removeGroupSignal(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
