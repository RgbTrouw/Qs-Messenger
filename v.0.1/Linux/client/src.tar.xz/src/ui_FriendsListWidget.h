/********************************************************************************
** Form generated from reading UI file 'FriendsListWidget.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FRIENDSLISTWIDGET_H
#define UI_FRIENDSLISTWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_FriendsListWidget
{
public:
    QVBoxLayout *verticalLayout;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QVBoxLayout *verticalLayout_2;

    void setupUi(QWidget *FriendsListWidget)
    {
        if (FriendsListWidget->objectName().isEmpty())
            FriendsListWidget->setObjectName(QString::fromUtf8("FriendsListWidget"));
        FriendsListWidget->resize(260, 821);
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(FriendsListWidget->sizePolicy().hasHeightForWidth());
        FriendsListWidget->setSizePolicy(sizePolicy);
        FriendsListWidget->setMinimumSize(QSize(260, 821));
        FriendsListWidget->setMaximumSize(QSize(260, 821));
        QFont font;
        font.setPointSize(10);
        FriendsListWidget->setFont(font);
        FriendsListWidget->setAutoFillBackground(false);
        FriendsListWidget->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        verticalLayout = new QVBoxLayout(FriendsListWidget);
        verticalLayout->setSpacing(0);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        scrollArea = new QScrollArea(FriendsListWidget);
        scrollArea->setObjectName(QString::fromUtf8("scrollArea"));
        sizePolicy.setHeightForWidth(scrollArea->sizePolicy().hasHeightForWidth());
        scrollArea->setSizePolicy(sizePolicy);
        scrollArea->setMinimumSize(QSize(0, 821));
        scrollArea->setMaximumSize(QSize(16777215, 821));
        scrollArea->setFont(font);
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QString::fromUtf8("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 258, 819));
        sizePolicy.setHeightForWidth(scrollAreaWidgetContents->sizePolicy().hasHeightForWidth());
        scrollAreaWidgetContents->setSizePolicy(sizePolicy);
        scrollAreaWidgetContents->setMinimumSize(QSize(0, 500));
        verticalLayout_2 = new QVBoxLayout(scrollAreaWidgetContents);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        scrollArea->setWidget(scrollAreaWidgetContents);

        verticalLayout->addWidget(scrollArea);


        retranslateUi(FriendsListWidget);

        QMetaObject::connectSlotsByName(FriendsListWidget);
    } // setupUi

    void retranslateUi(QWidget *FriendsListWidget)
    {
        FriendsListWidget->setWindowTitle(QCoreApplication::translate("FriendsListWidget", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class FriendsListWidget: public Ui_FriendsListWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FRIENDSLISTWIDGET_H
